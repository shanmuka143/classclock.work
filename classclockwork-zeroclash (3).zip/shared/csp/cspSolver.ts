import { validateTimetable } from './conflictDetector.ts';
import type {
  CspAllocation,
  CspDomainValue,
  CspFaculty,
  CspProgress,
  CspRoom,
  CspSolverInput,
  CspSolverResult,
  CspVariable,
  UnscheduledMeeting,
} from './types.ts';
import { DAYS_OF_WEEK } from './types.ts';

interface SolverCallbacks {
  onProgress?: (progress: CspProgress) => void;
  shouldCancel?: () => boolean;
}

export function solveTimetableCsp(
  input: CspSolverInput,
  callbacks: SolverCallbacks = {}
): CspSolverResult {
  const startTime = Date.now();
  const opts = {
    maxNodes: input.options?.maxNodes ?? 150000,
    timeoutMs: input.options?.timeoutMs ?? 15000,
    enableForwardChecking: input.options?.enableForwardChecking ?? true,
    enableLcv: input.options?.enableLcv ?? true,
    enableMrv: input.options?.enableMrv ?? true,
    allowPartialFallback: input.options?.allowPartialFallback ?? true,
  };

  const logs: Array<{ level: 'info' | 'warn' | 'error'; message: string }> = [];
  const facultyMap = new Map<number, CspFaculty>(input.faculty.map((f) => [f.id, f]));
  const roomMap = new Map<number, CspRoom>(input.rooms.map((r) => [r.id, r]));
  const lunchSet = new Set<number>(
    input.timeSlots.filter((s) => s.isLunchBreak).map((s) => s.periodNumber)
  );
  const maxPeriod = input.timeSlots.reduce((m, s) => Math.max(m, s.periodNumber), 0);

  // 1. Expand subjects into CSP Variables (one variable per required weekly meeting)
  const variables: CspVariable[] = [];
  const preUnscheduled: UnscheduledMeeting[] = [];
  const locked = input.lockedAllocations ?? [];
  const lockedKeys = new Set<string>(locked.map((a) => `${a.subjectId}_${a.sessionIndex}`));

  const sortedSubjects = [...input.subjects].sort((a, b) => {
    // Deterministic ordering: longer duration & larger strength first
    if (b.sessionDuration !== a.sessionDuration) return b.sessionDuration - a.sessionDuration;
    if (b.studentCount !== a.studentCount) return b.studentCount - a.studentCount;
    return a.id - b.id;
  });

  for (const subject of sortedSubjects) {
    for (let sIdx = 1; sIdx <= subject.weeklySessions; sIdx++) {
      if (lockedKeys.has(`${subject.id}_${sIdx}`)) {
        continue;
      }
      if (subject.facultyId === null || !facultyMap.has(subject.facultyId)) {
        preUnscheduled.push({
          variableId: `sub_${subject.id}_s${sIdx}`,
          subjectId: subject.id,
          subjectCode: subject.subjectCode,
          subjectName: subject.name,
          batchId: subject.batchId,
          facultyId: subject.facultyId,
          sessionIndex: sIdx,
          duration: subject.sessionDuration,
          reason: 'No faculty member assigned to this subject.',
        });
        continue;
      }

      variables.push({
        variableId: `sub_${subject.id}_s${sIdx}`,
        subjectId: subject.id,
        subjectCode: subject.subjectCode,
        subjectName: subject.name,
        facultyId: subject.facultyId,
        batchId: subject.batchId,
        duration: subject.sessionDuration,
        studentCount: subject.studentCount,
        requiredRoomType: subject.requiredRoomType,
        requiredEquipment: subject.requiredEquipment,
        sessionIndex: sIdx,
      });
    }
  }

  const totalMeetings = variables.length + preUnscheduled.length + locked.length;
  logs.push({
    level: 'info',
    message: `Initialized ${variables.length} scheduling variables (${locked.length} locked, ${preUnscheduled.length} missing faculty).`,
  });

  // 2. Build unary-pruned initial domains for each variable
  const initialDomains = new Map<string, CspDomainValue[]>();
  const emptyDomainVars: Array<{ variable: CspVariable; reason: string }> = [];

  for (const variable of variables) {
    const faculty = facultyMap.get(variable.facultyId)!;
    const compatibleRooms = input.rooms
      .filter((r) => {
        if (!r.isAvailable) return false;
        if (r.roomType !== variable.requiredRoomType) return false;
        if (r.capacity < variable.studentCount) return false;
        if (variable.requiredEquipment.length > 0) {
          const eqSet = new Set(r.equipment.map((e) => e.trim().toLowerCase()));
          for (const req of variable.requiredEquipment) {
            if (!eqSet.has(req.trim().toLowerCase())) return false;
          }
        }
        return true;
      })
      .sort((a, b) => a.capacity - b.capacity || a.id - b.id);

    if (compatibleRooms.length === 0) {
      emptyDomainVars.push({
        variable,
        reason: `No available '${variable.requiredRoomType}' room meets capacity (${variable.studentCount}) and equipment (${variable.requiredEquipment.join(', ') || 'none'}).`,
      });
      initialDomains.set(variable.variableId, []);
      continue;
    }

    const domain: CspDomainValue[] = [];
    for (let dayIdx = 0; dayIdx < DAYS_OF_WEEK.length; dayIdx++) {
      const day = DAYS_OF_WEEK[dayIdx];
      if (!faculty.availableDays.includes(day)) continue;

      for (let startP = 1; startP <= maxPeriod - variable.duration + 1; startP++) {
        let slotValid = true;
        for (let off = 0; off < variable.duration; off++) {
          const p = startP + off;
          if (lunchSet.has(p)) {
            slotValid = false;
            break;
          }
          const isUnavail = faculty.unavailableSlots.some((u) => u.day === day && u.periodNumber === p);
          if (isUnavail) {
            slotValid = false;
            break;
          }
        }
        if (!slotValid) continue;

        for (const room of compatibleRooms) {
          domain.push({
            day,
            dayIndex: dayIdx,
            startPeriod: startP,
            roomId: room.id,
          });
        }
      }
    }

    if (domain.length === 0) {
      emptyDomainVars.push({
        variable,
        reason: `Faculty (${faculty.fullName}) availability and lunch periods leave zero valid ${variable.duration}-period slots.`,
      });
    }
    initialDomains.set(variable.variableId, domain);
  }

  // Filter out variables with empty initial domain from backtracking so we can still schedule the rest cleanly
  const solvableVars = variables.filter((v) => (initialDomains.get(v.variableId)?.length ?? 0) > 0);
  const unsolvableReasonMap = new Map<string, string>(
    emptyDomainVars.map((item) => [item.variable.variableId, item.reason])
  );

  // Build conflict adjacency graph (variables sharing faculty, batch, or overlapping compatible rooms)
  const varRooms = new Map<string, Set<number>>();
  for (const v of solvableVars) {
    varRooms.set(
      v.variableId,
      new Set((initialDomains.get(v.variableId) ?? []).map((d) => d.roomId))
    );
  }
  const neighbors = new Map<string, Set<string>>();
  for (const v of solvableVars) neighbors.set(v.variableId, new Set());
  for (let i = 0; i < solvableVars.length; i++) {
    for (let j = i + 1; j < solvableVars.length; j++) {
      const a = solvableVars[i];
      const b = solvableVars[j];
      const sameFac = a.facultyId === b.facultyId;
      const sameBatch = a.batchId === b.batchId;
      let shareRoom = false;
      if (!sameFac && !sameBatch) {
        const ra = varRooms.get(a.variableId)!;
        const rb = varRooms.get(b.variableId)!;
        for (const rId of ra) {
          if (rb.has(rId)) {
            shareRoom = true;
            break;
          }
        }
      }
      if (sameFac || sameBatch || shareRoom) {
        neighbors.get(a.variableId)!.add(b.variableId);
        neighbors.get(b.variableId)!.add(a.variableId);
      }
    }
  }

  // Mutable solver state
  const facultyBusy = new Map<string, boolean>();
  const roomBusy = new Map<string, boolean>();
  const batchBusy = new Map<string, boolean>();
  const facultyHours = new Map<number, number>();
  const subjectDayCount = new Map<string, number>();
  const batchDayCount = new Map<string, number>();

  // Apply locked allocations into state
  for (const alloc of locked) {
    markOccupancy(alloc, 1);
  }

  function markOccupancy(alloc: CspAllocation, delta: 1 | -1) {
    const busyVal = delta === 1;
    for (let off = 0; off < alloc.durationPeriods; off++) {
      const p = alloc.startPeriod + off;
      facultyBusy.set(`${alloc.facultyId}_${alloc.day}_${p}`, busyVal);
      roomBusy.set(`${alloc.roomId}_${alloc.day}_${p}`, busyVal);
      batchBusy.set(`${alloc.batchId}_${alloc.day}_${p}`, busyVal);
    }
    facultyHours.set(
      alloc.facultyId,
      (facultyHours.get(alloc.facultyId) ?? 0) + delta * alloc.durationPeriods
    );
    const sdKey = `${alloc.subjectId}_${alloc.day}`;
    subjectDayCount.set(sdKey, (subjectDayCount.get(sdKey) ?? 0) + delta);
    const bdKey = `${alloc.batchId}_${alloc.day}`;
    batchDayCount.set(bdKey, (batchDayCount.get(bdKey) ?? 0) + delta * alloc.durationPeriods);
  }

  function isConsistent(v: CspVariable, val: CspDomainValue): boolean {
    const fac = facultyMap.get(v.facultyId)!;
    const usedHours = facultyHours.get(v.facultyId) ?? 0;
    if (usedHours + v.duration > fac.maxWeeklyHours) return false;

    for (let off = 0; off < v.duration; off++) {
      const p = val.startPeriod + off;
      if (facultyBusy.get(`${v.facultyId}_${val.day}_${p}`)) return false;
      if (roomBusy.get(`${val.roomId}_${val.day}_${p}`)) return false;
      if (batchBusy.get(`${v.batchId}_${val.day}_${p}`)) return false;
    }
    return true;
  }

  function countValidDomain(v: CspVariable): { count: number; soleValue: CspDomainValue | null } {
    const dom = initialDomains.get(v.variableId)!;
    let count = 0;
    let soleValue: CspDomainValue | null = null;
    for (let i = 0; i < dom.length; i++) {
      if (isConsistent(v, dom[i])) {
        count++;
        if (count === 1) {
          soleValue = dom[i];
        } else {
          soleValue = null;
        }
      }
    }
    return { count, soleValue };
  }

  function scoreValueSoft(v: CspVariable, val: CspDomainValue): number {
    const fac = facultyMap.get(v.facultyId)!;
    const room = roomMap.get(val.roomId);
    let score = 0;

    // Prefer spreading sessions of the same subject across different days
    const sameSubjectToday = subjectDayCount.get(`${v.subjectId}_${val.day}`) ?? 0;
    score += sameSubjectToday === 0 ? 30 : -25 * sameSubjectToday;

    // Prefer faculty preferred hours
    const matchesPref = fac.preferredHours.some(
      (ph) => ph.day === val.day && ph.periodNumber >= val.startPeriod && ph.periodNumber < val.startPeriod + v.duration
    );
    if (matchesPref) score += 20;

    // Balance daily load for batch
    const batchLoad = batchDayCount.get(`${v.batchId}_${val.day}`) ?? 0;
    score -= batchLoad * 2;

    // Prefer adjacent to existing batch class (avoid gaps)
    const hasPrev = val.startPeriod > 1 && batchBusy.get(`${v.batchId}_${val.day}_${val.startPeriod - 1}`);
    const hasNext = val.startPeriod + v.duration <= maxPeriod && batchBusy.get(`${v.batchId}_${val.day}_${val.startPeriod + v.duration}`);
    if (hasPrev || hasNext) score += 8;

    // Penalize >2 consecutive teaching periods
    const facPrev1 = val.startPeriod > 1 && facultyBusy.get(`${v.facultyId}_${val.day}_${val.startPeriod - 1}`);
    const facPrev2 = val.startPeriod > 2 && facultyBusy.get(`${v.facultyId}_${val.day}_${val.startPeriod - 2}`);
    if (facPrev1 && facPrev2) score -= 12;

    // Prefer tighter room capacity fit (save oversized halls for larger cohorts)
    if (room && room.capacity > 0) {
      score += Math.round((v.studentCount / room.capacity) * 6);
    }

    return score;
  }

  const assigned = new Map<string, CspAllocation>();
  let bestAssignment: CspAllocation[] = [];
  let bestCount = 0;
  let nodesExplored = 0;
  let backtracksCount = 0;
  let abortedReason: 'timeout' | 'budget' | 'cancelled' | null = null;
  const unassignedSet = new Set<string>(solvableVars.map((v) => v.variableId));
  const varById = new Map<string, CspVariable>(solvableVars.map((v) => [v.variableId, v]));

  callbacks.onProgress?.({
    nodesExplored: 0,
    assignedCount: 0,
    totalVariables: solvableVars.length,
    bestAssignedCount: 0,
    elapsedMs: Date.now() - startTime,
    phase: 'searching',
  });

  function selectUnassignedVariable(): CspVariable | null {
    if (unassignedSet.size === 0) return null;
    if (!opts.enableMrv) {
      const firstId = unassignedSet.values().next().value as string;
      return varById.get(firstId) ?? null;
    }

    let bestVar: CspVariable | null = null;
    let minRemaining = Infinity;
    let maxDegree = -1;

    for (const varId of unassignedSet) {
      const v = varById.get(varId)!;
      const { count: rem } = countValidDomain(v);
      const deg = neighbors.get(varId)?.size ?? 0;
      if (
        rem < minRemaining ||
        (rem === minRemaining && deg > maxDegree) ||
        (rem === minRemaining && deg === maxDegree && bestVar !== null && v.variableId < bestVar.variableId)
      ) {
        minRemaining = rem;
        maxDegree = deg;
        bestVar = v;
      }
      if (rem === 0) break;
    }
    return bestVar;
  }

  function orderDomainValues(v: CspVariable): CspDomainValue[] {
    const dom = initialDomains.get(v.variableId)!;
    const valid = dom.filter((val) => isConsistent(v, val));
    if (valid.length <= 1) return valid;

    if (!opts.enableLcv) {
      return valid.sort((a, b) => scoreValueSoft(v, b) - scoreValueSoft(v, a));
    }

    // LCV: count constraints imposed on unassigned neighbors + soft score tie-breaker
    const neighborList = Array.from(neighbors.get(v.variableId) ?? []).filter((nId) =>
      unassignedSet.has(nId)
    );

    const scored = valid.map((val) => {
      let eliminated = 0;
      if (neighborList.length > 0) {
        for (const nId of neighborList) {
          const nv = varById.get(nId)!;
          const nDom = initialDomains.get(nId)!;
          for (let i = 0; i < nDom.length; i++) {
            const nVal = nDom[i];
            if (nVal.dayIndex !== val.dayIndex) continue;
            const overlapsPeriod =
              val.startPeriod < nVal.startPeriod + nv.duration &&
              nVal.startPeriod < val.startPeriod + v.duration;
            if (!overlapsPeriod) continue;
            if (
              nv.facultyId === v.facultyId ||
              nv.batchId === v.batchId ||
              nVal.roomId === val.roomId
            ) {
              eliminated++;
            }
          }
        }
      }
      return {
        val,
        eliminated,
        soft: scoreValueSoft(v, val),
      };
    });

    scored.sort((a, b) => {
      if (a.eliminated !== b.eliminated) return a.eliminated - b.eliminated;
      if (b.soft !== a.soft) return b.soft - a.soft;
      if (a.val.dayIndex !== b.val.dayIndex) return a.val.dayIndex - b.val.dayIndex;
      if (a.val.startPeriod !== b.val.startPeriod) return a.val.startPeriod - b.val.startPeriod;
      return a.val.roomId - b.val.roomId;
    });

    return scored.map((s) => s.val);
  }

  /**
   * Forward checking + bounded AC-3 singleton constraint propagation lookahead.
   * Detects both immediate 1-hop domain wipeouts and 2-hop cascading singleton dead-ends,
   * while cleanly rolling back temporary lookahead marks before returning.
   */
  function forwardCheckAndPropagate(assignedVar: CspVariable): boolean {
    if (!opts.enableForwardChecking) return true;

    const tempPropagated: CspAllocation[] = [];
    const tempAssignedIds = new Set<string>();
    const queue: string[] = [assignedVar.variableId];

    try {
      let steps = 0;
      const MAX_PROPAGATION_STEPS = 48;

      while (queue.length > 0 && steps < MAX_PROPAGATION_STEPS) {
        steps++;
        const currentId = queue.shift()!;
        const neighborList = neighbors.get(currentId);
        if (!neighborList) continue;

        for (const nId of neighborList) {
          if (!unassignedSet.has(nId) || tempAssignedIds.has(nId)) continue;
          const nv = varById.get(nId)!;
          const { count, soleValue } = countValidDomain(nv);
          if (count === 0) {
            return false;
          }
          if (count === 1 && soleValue !== null) {
            const forcedAlloc: CspAllocation = {
              subjectId: nv.subjectId,
              facultyId: nv.facultyId,
              batchId: nv.batchId,
              roomId: soleValue.roomId,
              day: soleValue.day,
              startPeriod: soleValue.startPeriod,
              durationPeriods: nv.duration,
              sessionIndex: nv.sessionIndex,
            };
            markOccupancy(forcedAlloc, 1);
            tempPropagated.push(forcedAlloc);
            tempAssignedIds.add(nId);
            queue.push(nId);
          }
        }
      }
      return true;
    } finally {
      for (let i = tempPropagated.length - 1; i >= 0; i--) {
        markOccupancy(tempPropagated[i], -1);
      }
    }
  }

  function backtrack(): boolean {
    if (callbacks.shouldCancel?.()) {
      abortedReason = 'cancelled';
      return false;
    }
    if (nodesExplored >= opts.maxNodes) {
      abortedReason = 'budget';
      return false;
    }
    if (Date.now() - startTime >= opts.timeoutMs) {
      abortedReason = 'timeout';
      return false;
    }

    if (unassignedSet.size === 0) {
      bestAssignment = Array.from(assigned.values());
      bestCount = bestAssignment.length;
      return true;
    }

    const variable = selectUnassignedVariable();
    if (!variable) return false;

    const candidates = orderDomainValues(variable);
    if (candidates.length === 0) {
      backtracksCount++;
      return false;
    }

    unassignedSet.delete(variable.variableId);

    for (const val of candidates) {
      if (callbacks.shouldCancel?.()) {
        abortedReason = 'cancelled';
        unassignedSet.add(variable.variableId);
        return false;
      }
      if (nodesExplored >= opts.maxNodes) {
        abortedReason = 'budget';
        unassignedSet.add(variable.variableId);
        return false;
      }
      if (Date.now() - startTime >= opts.timeoutMs) {
        abortedReason = 'timeout';
        unassignedSet.add(variable.variableId);
        return false;
      }

      nodesExplored++;
      if (nodesExplored % 50 === 0) {
        callbacks.onProgress?.({
          nodesExplored,
          assignedCount: assigned.size,
          totalVariables: solvableVars.length,
          bestAssignedCount: bestCount,
          elapsedMs: Date.now() - startTime,
          phase: 'searching',
        });
      }

      const alloc: CspAllocation = {
        subjectId: variable.subjectId,
        facultyId: variable.facultyId,
        batchId: variable.batchId,
        roomId: val.roomId,
        day: val.day,
        startPeriod: val.startPeriod,
        durationPeriods: variable.duration,
        sessionIndex: variable.sessionIndex,
      };

      markOccupancy(alloc, 1);
      assigned.set(variable.variableId, alloc);

      if (assigned.size > bestCount) {
        bestCount = assigned.size;
        bestAssignment = Array.from(assigned.values());
      }

      if (forwardCheckAndPropagate(variable)) {
        if (backtrack()) {
          return true;
        }
      }

      backtracksCount++;
      assigned.delete(variable.variableId);
      markOccupancy(alloc, -1);

      if (abortedReason !== null) {
        unassignedSet.add(variable.variableId);
        return false;
      }
    }

    unassignedSet.add(variable.variableId);
    return false;
  }

  const solvedAllSolvable = solvableVars.length > 0 ? backtrack() : true;
  const getAbortedReason = (): 'timeout' | 'budget' | 'cancelled' | null => abortedReason;

  // Greedy conflict-free completion pass when full backtracking couldn't assign every variable
  if (!solvedAllSolvable && opts.allowPartialFallback && getAbortedReason() !== 'cancelled') {
    const assignedVarIds = new Set<string>();
    for (const alloc of bestAssignment) {
      const vid = `sub_${alloc.subjectId}_s${alloc.sessionIndex}`;
      assignedVarIds.add(vid);
      markOccupancy(alloc, 1);
      assigned.set(vid, alloc);
    }

    const remaining = solvableVars
      .filter((v) => !assignedVarIds.has(v.variableId))
      .sort((a, b) => (initialDomains.get(a.variableId)?.length ?? 0) - (initialDomains.get(b.variableId)?.length ?? 0));

    for (const remVar of remaining) {
      if (callbacks.shouldCancel?.()) {
        abortedReason = 'cancelled';
        break;
      }
      const candidates = orderDomainValues(remVar);
      if (candidates.length > 0) {
        const chosen = candidates[0];
        const alloc: CspAllocation = {
          subjectId: remVar.subjectId,
          facultyId: remVar.facultyId,
          batchId: remVar.batchId,
          roomId: chosen.roomId,
          day: chosen.day,
          startPeriod: chosen.startPeriod,
          durationPeriods: remVar.duration,
          sessionIndex: remVar.sessionIndex,
        };
        markOccupancy(alloc, 1);
        assigned.set(remVar.variableId, alloc);
      }
    }
    bestAssignment = Array.from(assigned.values());
    bestCount = bestAssignment.length;
  }

  const finalAllocations = [...locked, ...bestAssignment];
  const scheduledVarIds = new Set(
    finalAllocations.map((a) => `sub_${a.subjectId}_s${a.sessionIndex}`)
  );
  const finalAbortedReason = getAbortedReason();

  // Build detailed unscheduled list with diagnostics
  const unscheduledMeetings: UnscheduledMeeting[] = [...preUnscheduled];
  for (const v of variables) {
    if (!scheduledVarIds.has(v.variableId)) {
      const explicitReason = unsolvableReasonMap.get(v.variableId);
      let reason = explicitReason ?? 'Could not satisfy simultaneous faculty, batch, room, and weekly hour constraints.';
      if (!explicitReason) {
        const fac = facultyMap.get(v.facultyId);
        const used = finalAllocations
          .filter((a) => a.facultyId === v.facultyId)
          .reduce((acc, a) => acc + a.durationPeriods, 0);
        if (fac && used + v.duration > fac.maxWeeklyHours) {
          reason = `Faculty ${fac.fullName} weekly workload limit (${fac.maxWeeklyHours}h) would be exceeded (already scheduled ${used}h).`;
        } else if (finalAbortedReason === 'timeout') {
          reason = 'Search timeout reached before finding a conflict-free placement for this meeting.';
        } else if (finalAbortedReason === 'budget') {
          reason = 'Search node budget reached before placing this meeting.';
        } else if (finalAbortedReason === 'cancelled') {
          reason = 'Scheduling search was cancelled by the user before placing this meeting.';
        }
      }
      unscheduledMeetings.push({
        variableId: v.variableId,
        subjectId: v.subjectId,
        subjectCode: v.subjectCode,
        subjectName: v.subjectName,
        batchId: v.batchId,
        facultyId: v.facultyId,
        sessionIndex: v.sessionIndex,
        duration: v.duration,
        reason,
      });
    }
  }

  callbacks.onProgress?.({
    nodesExplored,
    assignedCount: bestAssignment.length,
    totalVariables: solvableVars.length,
    bestAssignedCount: bestCount,
    elapsedMs: Date.now() - startTime,
    phase: 'validating',
  });

  // Always verify final schedule with the independent validator
  const validation = validateTimetable({
    allocations: finalAllocations,
    subjects: input.subjects,
    faculty: input.faculty,
    batches: input.batches,
    rooms: input.rooms,
    timeSlots: input.timeSlots,
  });

  const durationMs = Date.now() - startTime;
  let status: CspSolverResult['status'];
  if (finalAbortedReason === 'cancelled') {
    status = 'cancelled';
  } else if (finalAbortedReason === 'timeout' && unscheduledMeetings.length > 0) {
    status = 'timeout';
  } else if (
    unscheduledMeetings.length === 0 &&
    finalAllocations.length === totalMeetings &&
    validation.isValid
  ) {
    status = validation.softMetrics.overallScore >= 75 ? 'optimal' : 'feasible';
  } else if (finalAllocations.length > 0) {
    status = 'partial';
  } else {
    status = 'infeasible';
  }

  logs.push({
    level: unscheduledMeetings.length === 0 && validation.isValid ? 'info' : 'warn',
    message: `CSP completed (${status}): ${finalAllocations.length}/${totalMeetings} meetings scheduled in ${durationMs}ms (${nodesExplored} nodes, ${backtracksCount} backtracks, score ${validation.softMetrics.overallScore}/100).`,
  });

  return {
    status,
    allocations: finalAllocations,
    totalMeetings,
    scheduledMeetings: finalAllocations.length,
    unscheduledMeetings,
    nodesExplored,
    backtracksCount,
    durationMs,
    validation,
    optimizationScore: validation.softMetrics.overallScore,
    logs,
  };
}
