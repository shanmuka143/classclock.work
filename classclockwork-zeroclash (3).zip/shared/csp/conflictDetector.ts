import type {
  CspAllocation,
  CspBatch,
  CspFaculty,
  CspRoom,
  CspSubject,
  CspTimeSlot,
  DayOfWeek,
  HardViolation,
  SoftConstraintMetrics,
  ValidationReport,
} from './types.ts';
import { DAYS_OF_WEEK } from './types.ts';

export interface AllocationWithId extends CspAllocation {
  id?: number;
}

export interface ValidationInput {
  allocations: AllocationWithId[];
  subjects: CspSubject[];
  faculty: CspFaculty[];
  batches: CspBatch[];
  rooms: CspRoom[];
  timeSlots: CspTimeSlot[];
}

export function validateTimetable(input: ValidationInput): ValidationReport {
  const hardViolations: HardViolation[] = [];

  const subjectMap = new Map<number, CspSubject>(input.subjects.map((s) => [s.id, s]));
  const facultyMap = new Map<number, CspFaculty>(input.faculty.map((f) => [f.id, f]));
  const batchMap = new Map<number, CspBatch>(input.batches.map((b) => [b.id, b]));
  const roomMap = new Map<number, CspRoom>(input.rooms.map((r) => [r.id, r]));
  const slotMap = new Map<number, CspTimeSlot>(input.timeSlots.map((t) => [t.periodNumber, t]));
  const maxPeriod = input.timeSlots.reduce((acc, s) => Math.max(acc, s.periodNumber), 0);

  // Occupancy maps: key = `${entityId}_${day}_${period}` -> AllocationWithId[]
  const facultyBuckets = new Map<string, AllocationWithId[]>();
  const roomBuckets = new Map<string, AllocationWithId[]>();
  const batchBuckets = new Map<string, AllocationWithId[]>();
  const sessionBuckets = new Map<string, AllocationWithId[]>();
  const facultyWeeklyHours = new Map<number, number>();

  for (const alloc of input.allocations) {
    const subject = subjectMap.get(alloc.subjectId);
    const faculty = facultyMap.get(alloc.facultyId);
    const room = roomMap.get(alloc.roomId);
    const batch = batchMap.get(alloc.batchId);

    const sessionKey = `${alloc.subjectId}_${alloc.sessionIndex}`;
    const sList = sessionBuckets.get(sessionKey) ?? [];
    sList.push(alloc);
    sessionBuckets.set(sessionKey, sList);

    if (!faculty || (subject && subject.facultyId === null)) {
      hardViolations.push({
        type: 'MISSING_FACULTY',
        message: `${subject ? subject.subjectCode : `Subject #${alloc.subjectId}`} does not have an assigned active faculty member.`,
        day: alloc.day,
        periodNumber: alloc.startPeriod,
        allocationIds: alloc.id !== undefined ? [alloc.id] : undefined,
        subjectId: alloc.subjectId,
        facultyId: alloc.facultyId,
      });
    }

    // 1. Duration & slot bounds + lunch break check
    if (alloc.durationPeriods < 1 || alloc.startPeriod < 1 || alloc.startPeriod + alloc.durationPeriods - 1 > maxPeriod) {
      hardViolations.push({
        type: 'INVALID_DURATION',
        message: `${subject ? subject.subjectCode : `Subject #${alloc.subjectId}`} (${alloc.day} P${alloc.startPeriod}, duration ${alloc.durationPeriods}) exceeds configured academic periods (1–${maxPeriod}).`,
        day: alloc.day,
        periodNumber: alloc.startPeriod,
        allocationIds: alloc.id !== undefined ? [alloc.id] : undefined,
        subjectId: alloc.subjectId,
        facultyId: alloc.facultyId,
        roomId: alloc.roomId,
        batchId: alloc.batchId,
      });
    }

    for (let offset = 0; offset < alloc.durationPeriods; offset++) {
      const p = alloc.startPeriod + offset;
      const slot = slotMap.get(p);
      if (!slot) {
        hardViolations.push({
          type: 'INVALID_DURATION',
          message: `Period ${p} on ${alloc.day} does not exist in configured time slots.`,
          day: alloc.day,
          periodNumber: p,
          allocationIds: alloc.id !== undefined ? [alloc.id] : undefined,
          subjectId: alloc.subjectId,
        });
        continue;
      }

      if (slot.isLunchBreak) {
        hardViolations.push({
          type: 'LUNCH_BREAK_VIOLATION',
          message: `${subject ? subject.subjectCode : `Subject #${alloc.subjectId}`} cannot be scheduled during protected lunch period (${slot.label}, ${alloc.day} P${p}).`,
          day: alloc.day,
          periodNumber: p,
          allocationIds: alloc.id !== undefined ? [alloc.id] : undefined,
          subjectId: alloc.subjectId,
          batchId: alloc.batchId,
        });
      }

      const fKey = `${alloc.facultyId}_${alloc.day}_${p}`;
      const rKey = `${alloc.roomId}_${alloc.day}_${p}`;
      const bKey = `${alloc.batchId}_${alloc.day}_${p}`;

      const fList = facultyBuckets.get(fKey) ?? [];
      fList.push(alloc);
      facultyBuckets.set(fKey, fList);

      const rList = roomBuckets.get(rKey) ?? [];
      rList.push(alloc);
      roomBuckets.set(rKey, rList);

      const bList = batchBuckets.get(bKey) ?? [];
      bList.push(alloc);
      batchBuckets.set(bKey, bList);
    }

    // 2. Room constraints
    if (room) {
      if (!room.isAvailable) {
        hardViolations.push({
          type: 'ROOM_UNAVAILABLE',
          message: `Room ${room.name} (${room.roomCode}) is marked unavailable.`,
          day: alloc.day,
          periodNumber: alloc.startPeriod,
          allocationIds: alloc.id !== undefined ? [alloc.id] : undefined,
          roomId: room.id,
          subjectId: alloc.subjectId,
        });
      }

      const requiredStrength = subject ? subject.studentCount : batch?.studentStrength ?? 0;
      if (room.capacity < requiredStrength) {
        hardViolations.push({
          type: 'CAPACITY_VIOLATION',
          message: `Room ${room.name} capacity (${room.capacity}) is smaller than class enrollment (${requiredStrength}) for ${subject?.subjectCode ?? `Subject #${alloc.subjectId}`}.`,
          day: alloc.day,
          periodNumber: alloc.startPeriod,
          allocationIds: alloc.id !== undefined ? [alloc.id] : undefined,
          roomId: room.id,
          subjectId: alloc.subjectId,
        });
      }

      if (subject && room.roomType !== subject.requiredRoomType) {
        hardViolations.push({
          type: 'ROOM_TYPE_MISMATCH',
          message: `${subject.subjectCode} requires a '${subject.requiredRoomType}' room, but ${room.name} is '${room.roomType}'.`,
          day: alloc.day,
          periodNumber: alloc.startPeriod,
          allocationIds: alloc.id !== undefined ? [alloc.id] : undefined,
          roomId: room.id,
          subjectId: subject.id,
        });
      }

      if (subject && subject.requiredEquipment.length > 0) {
        const roomEquipSet = new Set(room.equipment.map((e) => e.trim().toLowerCase()));
        const missing = subject.requiredEquipment.filter((req) => !roomEquipSet.has(req.trim().toLowerCase()));
        if (missing.length > 0) {
          hardViolations.push({
            type: 'EQUIPMENT_MISSING',
            message: `Room ${room.name} is missing required equipment (${missing.join(', ')}) for ${subject.subjectCode}.`,
            day: alloc.day,
            periodNumber: alloc.startPeriod,
            allocationIds: alloc.id !== undefined ? [alloc.id] : undefined,
            roomId: room.id,
            subjectId: subject.id,
          });
        }
      }
    }

    // 3. Faculty availability & weekly workload accumulation
    if (faculty) {
      if (!faculty.availableDays.includes(alloc.day)) {
        hardViolations.push({
          type: 'FACULTY_UNAVAILABLE',
          message: `${faculty.fullName} is not available on ${alloc.day} for ${subject?.subjectCode ?? `Subject #${alloc.subjectId}`}.`,
          day: alloc.day,
          periodNumber: alloc.startPeriod,
          allocationIds: alloc.id !== undefined ? [alloc.id] : undefined,
          facultyId: faculty.id,
          subjectId: alloc.subjectId,
        });
      }

      for (let offset = 0; offset < alloc.durationPeriods; offset++) {
        const p = alloc.startPeriod + offset;
        const isUnavail = faculty.unavailableSlots.some((u) => u.day === alloc.day && u.periodNumber === p);
        if (isUnavail) {
          hardViolations.push({
            type: 'FACULTY_UNAVAILABLE',
            message: `${faculty.fullName} has an unavailable slot on ${alloc.day} Period ${p}.`,
            day: alloc.day,
            periodNumber: p,
            allocationIds: alloc.id !== undefined ? [alloc.id] : undefined,
            facultyId: faculty.id,
            subjectId: alloc.subjectId,
          });
        }
      }

      facultyWeeklyHours.set(faculty.id, (facultyWeeklyHours.get(faculty.id) ?? 0) + alloc.durationPeriods);
    }
  }

  // 4. Duplicate session check
  for (const [, list] of sessionBuckets.entries()) {
    if (list.length > 1) {
      const sample = list[0];
      const sub = subjectMap.get(sample.subjectId);
      hardViolations.push({
        type: 'DUPLICATE_SESSION',
        message: `${sub?.subjectCode ?? `Subject #${sample.subjectId}`} session #${sample.sessionIndex} is scheduled ${list.length} times.`,
        subjectId: sample.subjectId,
        allocationIds: list.map((a) => a.id).filter((id): id is number => id !== undefined),
      });
    }
  }

  // 5. Collision buckets (Faculty, Room, Batch)
  const reportedFacultyPairs = new Set<string>();
  for (const [key, list] of facultyBuckets.entries()) {
    if (list.length > 1) {
      const [facIdStr, day, periodStr] = key.split('_');
      const facId = Number(facIdStr);
      const period = Number(periodStr);
      const fac = facultyMap.get(facId);
      const sig = `F_${facId}_${day}_${period}`;
      if (!reportedFacultyPairs.has(sig)) {
        reportedFacultyPairs.add(sig);
        const subjLabels = list.map((a) => subjectMap.get(a.subjectId)?.subjectCode ?? `#${a.subjectId}`).join(' & ');
        hardViolations.push({
          type: 'FACULTY_CLASH',
          message: `Faculty clash: ${fac?.fullName ?? `Faculty #${facId}`} is double-booked on ${day} Period ${period} (${subjLabels}).`,
          day: day as DayOfWeek,
          periodNumber: period,
          facultyId: facId,
          allocationIds: list.map((a) => a.id).filter((id): id is number => id !== undefined),
        });
      }
    }
  }

  const reportedRoomPairs = new Set<string>();
  for (const [key, list] of roomBuckets.entries()) {
    if (list.length > 1) {
      const [roomIdStr, day, periodStr] = key.split('_');
      const roomId = Number(roomIdStr);
      const period = Number(periodStr);
      const room = roomMap.get(roomId);
      const sig = `R_${roomId}_${day}_${period}`;
      if (!reportedRoomPairs.has(sig)) {
        reportedRoomPairs.add(sig);
        const subjLabels = list.map((a) => subjectMap.get(a.subjectId)?.subjectCode ?? `#${a.subjectId}`).join(' & ');
        hardViolations.push({
          type: 'ROOM_CLASH',
          message: `Room clash: ${room?.name ?? `Room #${roomId}`} is double-booked on ${day} Period ${period} (${subjLabels}).`,
          day: day as DayOfWeek,
          periodNumber: period,
          roomId,
          allocationIds: list.map((a) => a.id).filter((id): id is number => id !== undefined),
        });
      }
    }
  }

  const reportedBatchPairs = new Set<string>();
  for (const [key, list] of batchBuckets.entries()) {
    if (list.length > 1) {
      const [batchIdStr, day, periodStr] = key.split('_');
      const batchId = Number(batchIdStr);
      const period = Number(periodStr);
      const batch = batchMap.get(batchId);
      const sig = `B_${batchId}_${day}_${period}`;
      if (!reportedBatchPairs.has(sig)) {
        reportedBatchPairs.add(sig);
        const subjLabels = list.map((a) => subjectMap.get(a.subjectId)?.subjectCode ?? `#${a.subjectId}`).join(' & ');
        hardViolations.push({
          type: 'BATCH_CLASH',
          message: `Batch clash: ${batch?.name ?? `Batch #${batchId}`} has overlapping classes on ${day} Period ${period} (${subjLabels}).`,
          day: day as DayOfWeek,
          periodNumber: period,
          batchId,
          allocationIds: list.map((a) => a.id).filter((id): id is number => id !== undefined),
        });
      }
    }
  }

  // 6. Faculty weekly workload limit
  for (const [facId, totalHours] of facultyWeeklyHours.entries()) {
    const fac = facultyMap.get(facId);
    if (fac && totalHours > fac.maxWeeklyHours) {
      hardViolations.push({
        type: 'WORKLOAD_EXCEEDED',
        message: `Workload violation: ${fac.fullName} is assigned ${totalHours} weekly hours, exceeding maximum limit of ${fac.maxWeeklyHours}h.`,
        facultyId: facId,
      });
    }
  }

  // 7. Soft constraint metrics calculation
  const softMetrics = computeSoftMetrics(input, facultyMap, subjectMap, roomMap);

  return {
    isValid: hardViolations.length === 0,
    hardViolations,
    softMetrics,
  };
}

function computeSoftMetrics(
  input: ValidationInput,
  facultyMap: Map<number, CspFaculty>,
  subjectMap: Map<number, CspSubject>,
  roomMap: Map<number, CspRoom>
): SoftConstraintMetrics {
  const allocations = input.allocations;
  if (allocations.length === 0) {
    return {
      preferenceMatchRate: 0,
      subjectSpreadRate: 0,
      consecutivePenaltyCount: 0,
      batchGapCount: 0,
      dailyBalanceScore: 0,
      roomFitScore: 0,
      overallScore: 0,
    };
  }

  // A. Faculty preference match rate
  let prefApplicable = 0;
  let prefMatched = 0;
  for (const alloc of allocations) {
    const fac = facultyMap.get(alloc.facultyId);
    if (fac && fac.preferredHours.length > 0) {
      prefApplicable++;
      const hits = fac.preferredHours.some(
        (ph) => ph.day === alloc.day && ph.periodNumber >= alloc.startPeriod && ph.periodNumber < alloc.startPeriod + alloc.durationPeriods
      );
      if (hits) prefMatched++;
    }
  }
  const preferenceMatchRate = prefApplicable === 0 ? 1 : prefMatched / prefApplicable;

  // B. Subject spread across distinct days
  const subjectDays = new Map<number, { total: number; days: Set<DayOfWeek> }>();
  for (const alloc of allocations) {
    const entry = subjectDays.get(alloc.subjectId) ?? { total: 0, days: new Set<DayOfWeek>() };
    entry.total++;
    entry.days.add(alloc.day);
    subjectDays.set(alloc.subjectId, entry);
  }
  let spreadSum = 0;
  let spreadCount = 0;
  for (const { total, days } of subjectDays.values()) {
    const maxDistinct = Math.min(total, DAYS_OF_WEEK.length);
    spreadSum += days.size / maxDistinct;
    spreadCount++;
  }
  const subjectSpreadRate = spreadCount === 0 ? 1 : spreadSum / spreadCount;

  // C. Consecutive teaching hours (>2 consecutive periods without a break)
  const lunchPeriods = new Set(input.timeSlots.filter((t) => t.isLunchBreak).map((t) => t.periodNumber));
  let consecutivePenaltyCount = 0;
  const facDayPeriods = new Map<string, number[]>();
  for (const alloc of allocations) {
    const key = `${alloc.facultyId}_${alloc.day}`;
    const arr = facDayPeriods.get(key) ?? [];
    for (let p = alloc.startPeriod; p < alloc.startPeriod + alloc.durationPeriods; p++) {
      arr.push(p);
    }
    facDayPeriods.set(key, arr);
  }
  for (const periods of facDayPeriods.values()) {
    const sorted = Array.from(new Set(periods)).sort((a, b) => a - b);
    let streak = 1;
    for (let i = 1; i < sorted.length; i++) {
      const prev = sorted[i - 1];
      const curr = sorted[i];
      let hasLunchBetween = false;
      for (let mid = prev + 1; mid < curr; mid++) {
        if (lunchPeriods.has(mid)) hasLunchBetween = true;
      }
      if (curr === prev + 1 && !hasLunchBetween) {
        streak++;
        if (streak > 2) consecutivePenaltyCount++;
      } else {
        streak = 1;
      }
    }
  }

  // D. Batch idle gaps between first and last class of the day (excluding lunch)
  let batchGapCount = 0;
  const batchDayPeriods = new Map<string, number[]>();
  for (const alloc of allocations) {
    const key = `${alloc.batchId}_${alloc.day}`;
    const arr = batchDayPeriods.get(key) ?? [];
    for (let p = alloc.startPeriod; p < alloc.startPeriod + alloc.durationPeriods; p++) {
      arr.push(p);
    }
    batchDayPeriods.set(key, arr);
  }
  for (const periods of batchDayPeriods.values()) {
    const unique = new Set(periods);
    const sorted = Array.from(unique).sort((a, b) => a - b);
    if (sorted.length < 2) continue;
    for (let p = sorted[0]; p <= sorted[sorted.length - 1]; p++) {
      if (!unique.has(p) && !lunchPeriods.has(p)) {
        batchGapCount++;
      }
    }
  }

  // E. Daily balance across Mon-Fri
  const dayCounts = new Map<DayOfWeek, number>(DAYS_OF_WEEK.map((d) => [d, 0]));
  for (const alloc of allocations) {
    dayCounts.set(alloc.day, (dayCounts.get(alloc.day) ?? 0) + alloc.durationPeriods);
  }
  const counts = Array.from(dayCounts.values());
  const mean = counts.reduce((a, b) => a + b, 0) / counts.length;
  const variance = mean === 0 ? 0 : counts.reduce((acc, c) => acc + (c - mean) ** 2, 0) / counts.length;
  const cv = mean === 0 ? 0 : Math.sqrt(variance) / mean;
  const dailyBalanceScore = Math.max(0, Math.min(1, 1 - cv));

  // F. Room capacity fit efficiency (avoid wasting large halls on small seminars)
  let roomFitSum = 0;
  let roomFitCount = 0;
  for (const alloc of allocations) {
    const sub = subjectMap.get(alloc.subjectId);
    const room = roomMap.get(alloc.roomId);
    if (sub && room && room.capacity > 0) {
      const ratio = Math.min(1, sub.studentCount / room.capacity);
      // Scale gently so >= 0.75 fill scores 1.0, avoiding harsh penalties on standard halls
      roomFitSum += Math.min(1, ratio / 0.75);
      roomFitCount++;
    }
  }
  const roomFitScore = roomFitCount === 0 ? 1 : roomFitSum / roomFitCount;

  const penaltyFactor = Math.max(
    0,
    1 - (consecutivePenaltyCount * 0.04 + batchGapCount * 0.015)
  );
  const rawScore =
    (preferenceMatchRate * 0.22 +
      subjectSpreadRate * 0.33 +
      dailyBalanceScore * 0.22 +
      roomFitScore * 0.1 +
      penaltyFactor * 0.13) *
    100;

  return {
    preferenceMatchRate: Number((preferenceMatchRate * 100).toFixed(1)),
    subjectSpreadRate: Number((subjectSpreadRate * 100).toFixed(1)),
    consecutivePenaltyCount,
    batchGapCount,
    dailyBalanceScore: Number((dailyBalanceScore * 100).toFixed(1)),
    roomFitScore: Number((roomFitScore * 100).toFixed(1)),
    overallScore: Number(Math.max(0, Math.min(100, rawScore)).toFixed(1)),
  };
}
