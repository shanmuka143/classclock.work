export type DayOfWeek = 'Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri';

export const DAYS_OF_WEEK: readonly DayOfWeek[] = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'] as const;

export type RoomType = 'lecture' | 'lab' | 'seminar';

export interface CspTimeSlot {
  periodNumber: number;
  label: string;
  startTime: string;
  endTime: string;
  isLunchBreak: boolean;
}

export interface CspFacultyAvailability {
  day: DayOfWeek;
  periodNumber: number;
  status: 'unavailable' | 'preferred';
}

export interface CspFaculty {
  id: number;
  facultyCode: string;
  fullName: string;
  departmentId: number;
  maxWeeklyHours: number;
  availableDays: DayOfWeek[];
  preferredHours: Array<{ day: DayOfWeek; periodNumber: number }>;
  unavailableSlots: Array<{ day: DayOfWeek; periodNumber: number }>;
}

export interface CspRoom {
  id: number;
  roomCode: string;
  name: string;
  roomType: RoomType;
  capacity: number;
  equipment: string[];
  isAvailable: boolean;
}

export interface CspBatch {
  id: number;
  batchCode: string;
  name: string;
  departmentId: number;
  semester: number;
  studentStrength: number;
}

export interface CspSubject {
  id: number;
  subjectCode: string;
  name: string;
  departmentId: number;
  semester: number;
  batchId: number;
  facultyId: number | null;
  weeklySessions: number;
  sessionDuration: number;
  studentCount: number;
  requiredRoomType: RoomType;
  requiredEquipment: string[];
  credits: number;
  colorHex: string;
}

export interface CspVariable {
  variableId: string;
  subjectId: number;
  subjectCode: string;
  subjectName: string;
  facultyId: number;
  batchId: number;
  duration: number;
  studentCount: number;
  requiredRoomType: RoomType;
  requiredEquipment: string[];
  sessionIndex: number;
}

export interface CspDomainValue {
  day: DayOfWeek;
  dayIndex: number;
  startPeriod: number;
  roomId: number;
}

export interface CspAllocation {
  subjectId: number;
  facultyId: number;
  batchId: number;
  roomId: number;
  day: DayOfWeek;
  startPeriod: number;
  durationPeriods: number;
  sessionIndex: number;
}

export interface UnscheduledMeeting {
  variableId: string;
  subjectId: number;
  subjectCode: string;
  subjectName: string;
  batchId: number;
  facultyId: number | null;
  sessionIndex: number;
  duration: number;
  reason: string;
}

export type HardViolationType =
  | 'FACULTY_CLASH'
  | 'ROOM_CLASH'
  | 'BATCH_CLASH'
  | 'CAPACITY_VIOLATION'
  | 'ROOM_TYPE_MISMATCH'
  | 'EQUIPMENT_MISSING'
  | 'ROOM_UNAVAILABLE'
  | 'FACULTY_UNAVAILABLE'
  | 'LUNCH_BREAK_VIOLATION'
  | 'INVALID_DURATION'
  | 'WORKLOAD_EXCEEDED'
  | 'MISSING_FACULTY'
  | 'DUPLICATE_SESSION';

export interface HardViolation {
  type: HardViolationType;
  message: string;
  day?: DayOfWeek;
  periodNumber?: number;
  allocationIds?: number[];
  subjectId?: number;
  facultyId?: number;
  roomId?: number;
  batchId?: number;
}

export interface SoftConstraintMetrics {
  preferenceMatchRate: number;
  subjectSpreadRate: number;
  consecutivePenaltyCount: number;
  batchGapCount: number;
  dailyBalanceScore: number;
  roomFitScore: number;
  overallScore: number;
}

export interface ValidationReport {
  isValid: boolean;
  hardViolations: HardViolation[];
  softMetrics: SoftConstraintMetrics;
}

export interface CspSolverInput {
  subjects: CspSubject[];
  faculty: CspFaculty[];
  batches: CspBatch[];
  rooms: CspRoom[];
  timeSlots: CspTimeSlot[];
  lockedAllocations?: CspAllocation[];
  options?: {
    maxNodes?: number;
    timeoutMs?: number;
    enableForwardChecking?: boolean;
    enableLcv?: boolean;
    enableMrv?: boolean;
    allowPartialFallback?: boolean;
  };
}

export interface CspProgress {
  nodesExplored: number;
  assignedCount: number;
  totalVariables: number;
  bestAssignedCount: number;
  elapsedMs: number;
  phase: 'initializing' | 'searching' | 'optimizing' | 'validating';
}

export interface CspSolverResult {
  status: 'optimal' | 'feasible' | 'partial' | 'infeasible' | 'timeout' | 'cancelled';
  allocations: CspAllocation[];
  totalMeetings: number;
  scheduledMeetings: number;
  unscheduledMeetings: UnscheduledMeeting[];
  nodesExplored: number;
  backtracksCount: number;
  durationMs: number;
  validation: ValidationReport;
  optimizationScore: number;
  logs: Array<{ level: 'info' | 'warn' | 'error'; message: string }>;
}
