import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import { createApp } from './server/src/app.ts';
import { config } from './server/src/config/env.ts';
import { logger } from './server/src/config/logger.ts';
import { closeDb, getDb } from './server/src/database/connection.ts';
import { runMigrations } from './server/src/database/migrations/runner.ts';
import { seedDatabase } from './server/src/database/seeds/seedData.ts';

async function bootstrap() {
  const db = getDb();
  runMigrations(db);
  seedDatabase(db);

  const app = createApp(db);

  if (config.nodeEnv !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (req, res, next) => {
      if (req.path.startsWith('/api')) {
        next();
        return;
      }
      const indexHtml = path.join(distDir, 'index.html');
      if (fs.existsSync(indexHtml)) {
        res.sendFile(indexHtml);
      } else {
        res.status(404).send('Production build not found. Run npm run build.');
      }
    });
  }

  const server = app.listen(config.port, '0.0.0.0', () => {
    logger.info('ClassClockwork ZeroClash server running', {
      port: config.port,
      env: config.nodeEnv,
      dbPath: config.dbPath,
    });
  });

  const shutdown = () => {
    logger.info('Shutting down server...');
    server.close(() => {
      closeDb();
      process.exit(0);
    });
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

bootstrap().catch((err) => {
  logger.error('Failed to start server', {
    error: err instanceof Error ? err.message : String(err),
  });
  process.exit(1);
});
