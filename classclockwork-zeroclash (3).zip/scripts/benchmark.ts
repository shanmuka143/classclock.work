import { performance } from 'node:perf_hooks';
import request from 'supertest';
import { createApp } from '../server/src/app.ts';
import { createDatabase } from '../server/src/database/connection.ts';
import { runMigrations } from '../server/src/database/migrations/runner.ts';
import { seedDatabase } from '../server/src/database/seeds/seedData.ts';
import { solveTimetableCsp } from '../shared/csp/cspSolver.ts';
import type {
  CspBatch,
  CspFaculty,
  CspRoom,
  CspSubject,
  CspTimeSlot,
  DayOfWeek,
} from '../shared/csp/types.ts';

function buildSlots(): CspTimeSlot[] {
  return [
    { periodNumber: 1, label: 'P1', startTime: '08:30', endTime: '09:30', isLunchBreak: false },
    { periodNumber: 2, label: 'P2', startTime: '09:30', endTime: '10:30', isLunchBreak: false },
    { periodNumber: 3, label: 'P3', startTime: '10:45', endTime: '11:45', isLunchBreak: false },
    { periodNumber: 4, label: 'Lunch', startTime: '11:45', endTime: '12:45', isLunchBreak: true },
    { periodNumber: 5, label: 'P5', startTime: '12:45', endTime: '13:45', isLunchBreak: false },
    { periodNumber: 6, label: 'P6', startTime: '13:45', endTime: '14:45', isLunchBreak: false },
    { periodNumber: 7, label: 'P7', startTime: '15:00', endTime: '16:00', isLunchBreak: false },
    { periodNumber: 8, label: 'P8', startTime: '16:00', endTime: '17:00', isLunchBreak: false },
  ];
}

function buildSyntheticDataset(batchCount: number, subjectsPerBatch: number) {
  const days: DayOfWeek[] = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
  const batches: CspBatch[] = Array.from({ length: batchCount }, (_, idx) => ({
    id: idx + 1,
    batchCode: `B-${idx + 1}`,
    name: `Cohort ${idx + 1}`,
    departmentId: 1,
    semester: (idx % 4) + 1,
    studentStrength: 50,
  }));

  const facultyCount = batchCount * 2;
  const faculty: CspFaculty[] = Array.from({ length: facultyCount }, (_, idx) => ({
    id: idx + 1,
    facultyCode: `FAC-${idx + 1}`,
    fullName: `Faculty Member ${idx + 1}`,
    departmentId: 1,
    maxWeeklyHours: 22,
    availableDays: days,
    preferredHours: [{ day: days[idx % days.length], periodNumber: 1 }],
    unavailableSlots: [{ day: days[(idx + 2) % days.length], periodNumber: 8 }],
  }));

  const rooms: CspRoom[] = [
    ...Array.from({ length: Math.max(4, Math.ceil(batchCount * 1.2)) }, (_, idx) => ({
      id: idx + 1,
      roomCode: `LH-${idx + 1}`,
      name: `Lecture Hall ${idx + 1}`,
      roomType: 'lecture' as const,
      capacity: 70,
      equipment: ['Projector'],
      isAvailable: true,
    })),
    ...Array.from({ length: Math.max(2, Math.ceil(batchCount * 0.6)) }, (_, idx) => ({
      id: 100 + idx + 1,
      roomCode: `LAB-${idx + 1}`,
      name: `Laboratory ${idx + 1}`,
      roomType: 'lab' as const,
      capacity: 60,
      equipment: ['Workstations', 'Projector'],
      isAvailable: true,
    })),
  ];

  const subjects: CspSubject[] = [];
  let subId = 1;
  for (let b = 0; b < batchCount; b++) {
    for (let s = 0; s < subjectsPerBatch; s++) {
      const isLab = s === subjectsPerBatch - 1;
      const facId = ((b * 2 + (s % 2)) % facultyCount) + 1;
      subjects.push({
        id: subId,
        subjectCode: `SUB-${subId}`,
        name: `Course ${subId}`,
        departmentId: 1,
        semester: batches[b].semester,
        batchId: batches[b].id,
        facultyId: facId,
        weeklySessions: isLab ? 1 : 3,
        sessionDuration: isLab ? 2 : 1,
        studentCount: 50,
        requiredRoomType: isLab ? 'lab' : 'lecture',
        requiredEquipment: isLab ? ['Workstations'] : ['Projector'],
        credits: isLab ? 2 : 3,
        colorHex: '#1d4ed8',
      });
      subId++;
    }
  }

  return { batches, faculty, rooms, subjects, timeSlots: buildSlots() };
}

async function runBenchmarks() {
  console.log('=== ClassClockwork ZeroClash — Real Performance Benchmarks ===\n');

  const scenarios = [
    { label: 'Small (2 batches, ~14 meetings)', dataset: buildSyntheticDataset(2, 3) },
    { label: 'Medium (4 batches, ~40 meetings)', dataset: buildSyntheticDataset(4, 4) },
    { label: 'Large (8 batches, ~80 meetings)', dataset: buildSyntheticDataset(8, 4) },
  ];

  for (const s of scenarios) {
    const start = performance.now();
    const res = solveTimetableCsp({
      ...s.dataset,
      options: {
        enableMrv: true,
        enableLcv: true,
        enableForwardChecking: true,
        maxNodes: 200000,
        timeoutMs: 15000,
      },
    });
    const elapsed = Number((performance.now() - start).toFixed(2));
    console.log(
      `[CSP] ${s.label}: status=${res.status}, scheduled=${res.scheduledMeetings}/${res.totalMeetings}, nodes=${res.nodesExplored}, backtracks=${res.backtracksCount}, valid=${res.validation.isValid}, score=${res.optimizationScore}, wallMs=${elapsed}`
    );
  }

  // Cancellation latency benchmark
  const large = buildSyntheticDataset(8, 4);
  let calls = 0;
  const cancelStart = performance.now();
  const cancelRes = solveTimetableCsp(large, {
    shouldCancel: () => {
      calls++;
      return calls >= 2;
    },
  });
  const cancelElapsed = Number((performance.now() - cancelStart).toFixed(2));
  console.log(
    `[CSP Cancel] status=${cancelRes.status}, nodesBeforeStop=${cancelRes.nodesExplored}, cancelLatencyMs=${cancelElapsed}`
  );

  // API Response Time Benchmark against real in-memory SQLite + Express
  process.env.NODE_ENV = 'test';
  const db = createDatabase(':memory:');
  runMigrations(db);
  seedDatabase(db);
  const app = createApp(db);
  const agent = request.agent(app);
  await agent.post('/api/auth/login').send({ username: 'admin', password: 'Admin@2026' });

  const endpoints = [
    '/api/health',
    '/api/faculty',
    '/api/subjects',
    '/api/timetable',
    '/api/dashboard/stats',
    '/api/analytics/scheduling',
    '/api/openapi.json',
  ];

  console.log('\n[API Latency] (5-request mean per endpoint)');
  for (const ep of endpoints) {
    const times: number[] = [];
    for (let i = 0; i < 5; i++) {
      const t0 = performance.now();
      const res = await agent.get(ep);
      const t1 = performance.now();
      if (res.status !== 200) {
        throw new Error(`Endpoint ${ep} returned HTTP ${res.status}`);
      }
      times.push(t1 - t0);
    }
    const avg = (times.reduce((a, b) => a + b, 0) / times.length).toFixed(2);
    const max = Math.max(...times).toFixed(2);
    console.log(`  GET ${ep.padEnd(28)} avg=${avg}ms  max=${max}ms`);
  }

  db.close();
}

runBenchmarks().catch((err) => {
  console.error(err);
  process.exit(1);
});
