import type Database from 'better-sqlite3';
import { Router } from 'express';
import { createAuthController } from '../controllers/authController.ts';
import { requireAuth } from '../middleware/authMiddleware.ts';
import { authRateLimiter } from '../middleware/rateLimiter.ts';

export function createAuthRouter(db: Database.Database): Router {
  const router = Router();
  const ctrl = createAuthController(db);

  router.post('/login', authRateLimiter, ctrl.login);
  router.post('/logout', requireAuth, ctrl.logout);
  router.get('/me', requireAuth, ctrl.me);

  return router;
}
