import type Database from 'better-sqlite3';
import { Router } from 'express';
import { createAnalyticsController } from '../controllers/analyticsController.ts';
import { requireAuth } from '../middleware/authMiddleware.ts';

export function createAnalyticsRouter(db: Database.Database): Router {
  const router = Router();
  const ctrl = createAnalyticsController(db);

  router.use(requireAuth);
  router.get('/workload', ctrl.workload);
  router.get('/room-utilization', ctrl.roomUtilization);
  router.get('/scheduling', ctrl.scheduling);

  return router;
}
