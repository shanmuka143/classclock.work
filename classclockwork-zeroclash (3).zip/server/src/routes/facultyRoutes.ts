import type Database from 'better-sqlite3';
import { Router } from 'express';
import { createFacultyController } from '../controllers/facultyController.ts';
import { requireAuth, requireRole } from '../middleware/authMiddleware.ts';

export function createFacultyRouter(db: Database.Database): Router {
  const router = Router();
  const ctrl = createFacultyController(db);

  router.use(requireAuth);
  router.get('/', ctrl.list);
  router.get('/:id', ctrl.getById);
  router.post('/', requireRole('admin', 'coordinator', 'evaluator'), ctrl.create);
  router.put('/:id', requireRole('admin', 'coordinator', 'evaluator'), ctrl.update);
  router.delete('/:id', requireRole('admin', 'coordinator', 'evaluator'), ctrl.remove);

  return router;
}
