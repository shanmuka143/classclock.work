import type Database from 'better-sqlite3';
import { Router } from 'express';
import { createTimetableController } from '../controllers/timetableController.ts';
import { requireAuth, requireRole } from '../middleware/authMiddleware.ts';
import { solverRateLimiter } from '../middleware/rateLimiter.ts';

export function createTimetableRouter(db: Database.Database): Router {
  const router = Router();
  const ctrl = createTimetableController(db);

  router.use(requireAuth);
  router.get('/', ctrl.getTimetable);
  router.get('/solver-payload', ctrl.getSolverPayload);
  router.post('/generate', solverRateLimiter, requireRole('admin', 'coordinator', 'evaluator'), ctrl.generate);
  router.post('/save-generated', solverRateLimiter, requireRole('admin', 'coordinator', 'evaluator'), ctrl.saveWorkerResult);
  router.post('/validate', ctrl.validate);
  router.post('/publish', requireRole('admin', 'coordinator', 'evaluator'), ctrl.publish);
  router.put('/:id', requireRole('admin', 'coordinator', 'evaluator'), ctrl.updateAllocation);
  router.delete('/:id', requireRole('admin', 'coordinator', 'evaluator'), ctrl.deleteAllocation);

  return router;
}
