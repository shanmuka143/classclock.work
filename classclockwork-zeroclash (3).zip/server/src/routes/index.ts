import type Database from 'better-sqlite3';
import { Router } from 'express';
import { createDashboardController } from '../controllers/dashboardController.ts';
import { createSettingsController } from '../controllers/settingsController.ts';
import { createSystemController } from '../controllers/systemController.ts';
import { getOpenApiSpec, renderOpenApiHtml } from '../docs/openapi.ts';
import { requireAuth, requireRole } from '../middleware/authMiddleware.ts';
import { createAnalyticsRouter } from './analyticsRoutes.ts';
import { createAuthRouter } from './authRoutes.ts';
import { createBatchRouter } from './batchRoutes.ts';
import { createFacultyRouter } from './facultyRoutes.ts';
import { createRoomRouter } from './roomRoutes.ts';
import { createSubjectRouter } from './subjectRoutes.ts';
import { createTimetableRouter } from './timetableRoutes.ts';

export function createApiRouter(db: Database.Database): Router {
  const api = Router();
  const dashCtrl = createDashboardController(db);
  const settingsCtrl = createSettingsController(db);
  const systemCtrl = createSystemController(db);

  api.use((req, _res, next) => {
    if (!req.app.locals.db) {
      req.app.locals.db = db;
    }
    next();
  });

  api.get('/health', (_req, res) => {
    try {
      const row = db.prepare('SELECT 1 AS ok').get() as { ok: number };
      res.status(200).json({
        ok: true,
        data: {
          status: 'healthy',
          database: row.ok === 1 ? 'connected' : 'error',
          timestamp: new Date().toISOString(),
        },
      });
    } catch {
      res.status(503).json({
        ok: false,
        error: { code: 'DB_UNAVAILABLE', message: 'SQLite health check failed.' },
      });
    }
  });

  api.get('/openapi.json', (req, res) => {
    const host = req.get('host');
    const origin = host ? `${req.protocol}://${host}` : undefined;
    res.status(200).json(getOpenApiSpec(origin));
  });

  api.get('/docs', (_req, res) => {
    res.status(200).type('html').send(renderOpenApiHtml('/api/openapi.json'));
  });

  api.use('/auth', createAuthRouter(db));
  api.get('/dashboard/stats', requireAuth, dashCtrl.getStats);

  api.get('/departments', requireAuth, settingsCtrl.listDepartments);
  api.post('/departments', requireAuth, requireRole('admin'), settingsCtrl.createDepartment);

  api.get('/settings', requireAuth, settingsCtrl.getSettings);
  api.put('/settings', requireAuth, requireRole('admin'), settingsCtrl.updateSettings);
  api.put('/settings/time-slots', requireAuth, requireRole('admin'), settingsCtrl.updateTimeSlots);

  api.get('/audit-logs', requireAuth, requireRole('admin'), systemCtrl.listAuditLogs);
  api.get('/system/integrity', requireAuth, requireRole('admin'), systemCtrl.checkIntegrity);
  api.post('/system/backup', requireAuth, requireRole('admin'), systemCtrl.createBackup);

  api.use('/faculty', createFacultyRouter(db));
  api.use('/subjects', createSubjectRouter(db));
  api.use('/batches', createBatchRouter(db));
  api.use('/rooms', createRoomRouter(db));
  api.use('/timetable', createTimetableRouter(db));
  api.use('/analytics', createAnalyticsRouter(db));

  return api;
}
