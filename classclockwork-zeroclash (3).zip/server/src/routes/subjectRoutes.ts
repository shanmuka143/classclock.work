import type Database from 'better-sqlite3';
import { Router } from 'express';
import { createSubjectController } from '../controllers/subjectController.ts';
import { requireAuth, requireRole } from '../middleware/authMiddleware.ts';

export function createSubjectRouter(db: Database.Database): Router {
  const router = Router();
  const ctrl = createSubjectController(db);

  router.use(requireAuth);
  router.get('/', ctrl.list);
  router.post('/', requireRole('admin', 'coordinator', 'evaluator'), ctrl.create);
  router.put('/:id', requireRole('admin', 'coordinator', 'evaluator'), ctrl.update);
  router.delete('/:id', requireRole('admin', 'coordinator', 'evaluator'), ctrl.remove);

  return router;
}
