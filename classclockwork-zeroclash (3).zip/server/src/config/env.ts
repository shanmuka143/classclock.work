import crypto from 'node:crypto';
import path from 'node:path';
import dotenv from 'dotenv';
import { z } from 'zod';

dotenv.config();

const fallbackDevSecret = crypto.randomBytes(32).toString('hex');

const INSECURE_SECRET_VALUES = new Set([
  'replace_with_secure_random_secret_at_least_32_chars',
  'secret',
  'changeme',
  'dev-secret',
  'default-secret',
  'jwt_secret',
  '12345678901234567890123456789012',
]);

const emptyToUndefined = <T extends z.ZodTypeAny>(schema: T) =>
  z.preprocess((val) => (typeof val === 'string' && val.trim() === '' ? undefined : val), schema);

const envSchema = z.object({
  NODE_ENV: emptyToUndefined(z.enum(['development', 'production', 'test']).default('development')),
  PORT: emptyToUndefined(z.coerce.number().int().min(1).max(65535).default(3000)),
  NGINX_PORT: emptyToUndefined(z.coerce.number().int().min(1).max(65535).optional()),
  DEFAULT_APP_PORT: emptyToUndefined(z.coerce.number().int().min(1).max(65535).default(3000)),
  DB_PATH: emptyToUndefined(z.string().trim().min(1).optional()),
  BACKUP_DIR: emptyToUndefined(z.string().trim().min(1).optional()),
  JWT_SECRET: emptyToUndefined(z.string().trim().optional()),
  JWT_EXPIRES_IN: emptyToUndefined(
    z
      .string()
      .trim()
      .regex(/^\d+[smhd]$/, 'JWT_EXPIRES_IN must be a duration such as 12h, 30m, or 7d')
      .default('12h')
  ),
  CORS_ORIGIN: emptyToUndefined(z.string().trim().optional()),
  APP_URL: emptyToUndefined(z.string().trim().optional()),
  COOKIE_SECURE: emptyToUndefined(z.enum(['auto', 'true', 'false']).default('auto')),
  BOOTSTRAP_ADMIN_USERNAME: emptyToUndefined(z.string().trim().optional()),
  BOOTSTRAP_ADMIN_EMAIL: emptyToUndefined(z.string().trim().optional()),
  BOOTSTRAP_ADMIN_NAME: emptyToUndefined(z.string().trim().optional()),
  BOOTSTRAP_ADMIN_PASSWORD: emptyToUndefined(z.string().optional()),
  BOOTSTRAP_COORDINATOR_USERNAME: emptyToUndefined(z.string().trim().optional()),
  BOOTSTRAP_COORDINATOR_EMAIL: emptyToUndefined(z.string().trim().optional()),
  BOOTSTRAP_COORDINATOR_PASSWORD: emptyToUndefined(z.string().optional()),
  BOOTSTRAP_EVALUATOR_USERNAME: emptyToUndefined(z.string().trim().optional()),
  BOOTSTRAP_EVALUATOR_EMAIL: emptyToUndefined(z.string().trim().optional()),
  BOOTSTRAP_EVALUATOR_NAME: emptyToUndefined(z.string().trim().optional()),
  BOOTSTRAP_EVALUATOR_PASSWORD: emptyToUndefined(z.string().optional()),
});

export interface AppConfig {
  nodeEnv: 'development' | 'production' | 'test';
  port: number;
  dbPath: string;
  backupDir: string;
  jwtSecret: string;
  jwtExpiresIn: string;
  jwtExpiresInMs: number;
  corsOrigin: string;
  corsOrigins: string[];
  appUrl: string | null;
  cookieSecure: 'auto' | 'true' | 'false';
  usingEphemeralDevSecret: boolean;
}

export function parseDurationToMs(duration: string): number {
  const match = /^(\d+)([smhd])$/.exec(duration.trim());
  if (!match) return 12 * 60 * 60 * 1000;
  const amount = Number(match[1]);
  const unit = match[2];
  switch (unit) {
    case 's':
      return amount * 1000;
    case 'm':
      return amount * 60 * 1000;
    case 'h':
      return amount * 60 * 60 * 1000;
    case 'd':
      return amount * 24 * 60 * 60 * 1000;
    default:
      return 12 * 60 * 60 * 1000;
  }
}

export function loadConfig(rawEnv: Record<string, string | undefined> = process.env): AppConfig {
  const parsed = envSchema.safeParse(rawEnv);
  if (!parsed.success) {
    const details = parsed.error.issues
      .map((i) => `${i.path.join('.') || 'env'}: ${i.message}`)
      .join('; ');
    throw new Error(`Invalid environment configuration: ${details}`);
  }

  const env = parsed.data;
  const isProd = env.NODE_ENV === 'production';

  const dbPath =
    env.DB_PATH && env.DB_PATH.length > 0
      ? env.DB_PATH
      : path.resolve(process.cwd(), 'data', 'classclockwork.sqlite');
  const backupDir =
    env.BACKUP_DIR && env.BACKUP_DIR.length > 0
      ? env.BACKUP_DIR
      : path.resolve(process.cwd(), 'data', 'backups');

  let jwtSecret = env.JWT_SECRET ?? '';
  let usingEphemeralDevSecret = false;

  if (isProd) {
    if (!jwtSecret || jwtSecret.length < 32) {
      throw new Error(
        'Production security error: JWT_SECRET must be explicitly set and at least 32 characters long.'
      );
    }
    if (INSECURE_SECRET_VALUES.has(jwtSecret.toLowerCase())) {
      throw new Error(
        'Production security error: JWT_SECRET uses a forbidden placeholder/weak value. Provide a cryptographically random secret.'
      );
    }
  } else {
    if (!jwtSecret || jwtSecret.length < 32 || INSECURE_SECRET_VALUES.has(jwtSecret.toLowerCase())) {
      jwtSecret = fallbackDevSecret;
      usingEphemeralDevSecret = true;
    }
  }

  const rawCors = env.CORS_ORIGIN ?? '';
  if (isProd) {
    if (!rawCors || rawCors === '*') {
      throw new Error(
        'Production security error: CORS_ORIGIN must specify explicit allowed origin(s) and must not be "*" or empty.'
      );
    }
  }

  const defaultDevOrigins = ['http://localhost:3000', 'http://127.0.0.1:3000'];
  const corsOrigins =
    rawCors && rawCors !== '*'
      ? rawCors
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean)
      : defaultDevOrigins;

  let appUrl: string | null = null;
  if (env.APP_URL && env.APP_URL !== 'MY_APP_URL') {
    try {
      const u = new URL(env.APP_URL);
      appUrl = u.origin;
      if (!corsOrigins.includes(u.origin)) {
        corsOrigins.push(u.origin);
      }
    } catch {
      // Ignore malformed placeholder APP_URL
    }
  }

  if (isProd) {
    for (const origin of corsOrigins) {
      try {
        const u = new URL(origin);
        if (u.protocol !== 'http:' && u.protocol !== 'https:') {
          throw new Error(`Invalid protocol for CORS origin: ${origin}`);
        }
      } catch {
        throw new Error(`Production security error: Invalid CORS_ORIGIN URL "${origin}".`);
      }
    }
  }

  const effectivePort =
    env.NGINX_PORT && env.PORT === env.NGINX_PORT ? env.DEFAULT_APP_PORT : env.PORT;

  return {
    nodeEnv: env.NODE_ENV,
    port: effectivePort,
    dbPath,
    backupDir,
    jwtSecret,
    jwtExpiresIn: env.JWT_EXPIRES_IN,
    jwtExpiresInMs: parseDurationToMs(env.JWT_EXPIRES_IN),
    corsOrigin: rawCors || corsOrigins.join(','),
    corsOrigins,
    appUrl,
    cookieSecure: env.COOKIE_SECURE,
    usingEphemeralDevSecret,
  };
}

export const config: AppConfig = loadConfig();
