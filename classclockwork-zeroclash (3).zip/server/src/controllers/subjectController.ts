import type Database from 'better-sqlite3';
import type { NextFunction, Request, Response } from 'express';
import type { AuthenticatedRequest } from '../middleware/authMiddleware.ts';
import { AppError } from '../middleware/errorHandler.ts';
import { AuditService } from '../services/auditService.ts';
import { SubjectService } from '../services/subjectService.ts';
import { sendListOrPaginated } from '../utils/pagination.ts';
import { createSubjectSchema, updateSubjectSchema } from '../validators/schemas.ts';

export function createSubjectController(db: Database.Database) {
  const service = new SubjectService(db);
  const audit = new AuditService(db);

  return {
    list(req: Request, res: Response, next: NextFunction): void {
      try {
        const departmentId = req.query.departmentId ? Number(req.query.departmentId) : undefined;
        const semester = req.query.semester ? Number(req.query.semester) : undefined;
        const batchId = req.query.batchId ? Number(req.query.batchId) : undefined;
        const search = typeof req.query.search === 'string' ? req.query.search : undefined;
        const items = service.list({ departmentId, semester, batchId, search });
        sendListOrPaginated(req, res, items);
      } catch (err) {
        next(err);
      }
    },

    create(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const input = createSubjectSchema.parse(req.body);
        const created = service.create(input);
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'SUBJECT_CREATE',
          entityType: 'subject',
          entityId: created.id,
          status: 'success',
          details: { subjectCode: created.subjectCode, name: created.name },
          ipAddress: req.ip ?? null,
        });
        res.status(201).json({ ok: true, data: created });
      } catch (err) {
        next(err);
      }
    },

    update(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const id = Number(req.params.id);
        if (!Number.isInteger(id) || id <= 0) throw new AppError(400, 'INVALID_ID', 'Invalid subject ID.');
        const input = updateSubjectSchema.parse(req.body);
        const updated = service.update(id, input);
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'SUBJECT_UPDATE',
          entityType: 'subject',
          entityId: id,
          status: 'success',
          details: { subjectCode: updated.subjectCode },
          ipAddress: req.ip ?? null,
        });
        res.status(200).json({ ok: true, data: updated });
      } catch (err) {
        next(err);
      }
    },

    remove(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const id = Number(req.params.id);
        if (!Number.isInteger(id) || id <= 0) throw new AppError(400, 'INVALID_ID', 'Invalid subject ID.');
        const result = service.delete(id);
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'SUBJECT_DELETE',
          entityType: 'subject',
          entityId: id,
          status: 'success',
          ipAddress: req.ip ?? null,
        });
        res.status(200).json({ ok: true, data: result });
      } catch (err) {
        next(err);
      }
    },
  };
}
