import type Database from 'better-sqlite3';
import type { NextFunction, Request, Response } from 'express';
import type { AuthenticatedRequest } from '../middleware/authMiddleware.ts';
import { AppError } from '../middleware/errorHandler.ts';
import { AuditService } from '../services/auditService.ts';
import { RoomService } from '../services/roomService.ts';
import { sendListOrPaginated } from '../utils/pagination.ts';
import { createRoomSchema, updateRoomSchema } from '../validators/schemas.ts';

export function createRoomController(db: Database.Database) {
  const service = new RoomService(db);
  const audit = new AuditService(db);

  return {
    list(req: Request, res: Response, next: NextFunction): void {
      try {
        const roomType = typeof req.query.roomType === 'string' ? req.query.roomType : undefined;
        const search = typeof req.query.search === 'string' ? req.query.search : undefined;
        const items = service.list({ roomType, search });
        sendListOrPaginated(req, res, items);
      } catch (err) {
        next(err);
      }
    },

    create(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const input = createRoomSchema.parse(req.body);
        const created = service.create(input);
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'ROOM_CREATE',
          entityType: 'room',
          entityId: created.id,
          status: 'success',
          details: { roomCode: created.roomCode, roomType: created.roomType },
          ipAddress: req.ip ?? null,
        });
        res.status(201).json({ ok: true, data: created });
      } catch (err) {
        next(err);
      }
    },

    update(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const id = Number(req.params.id);
        if (!Number.isInteger(id) || id <= 0) throw new AppError(400, 'INVALID_ID', 'Invalid room ID.');
        const input = updateRoomSchema.parse(req.body);
        const updated = service.update(id, input);
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'ROOM_UPDATE',
          entityType: 'room',
          entityId: id,
          status: 'success',
          details: { roomCode: updated.roomCode },
          ipAddress: req.ip ?? null,
        });
        res.status(200).json({ ok: true, data: updated });
      } catch (err) {
        next(err);
      }
    },

    remove(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const id = Number(req.params.id);
        if (!Number.isInteger(id) || id <= 0) throw new AppError(400, 'INVALID_ID', 'Invalid room ID.');
        const result = service.delete(id);
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'ROOM_DELETE',
          entityType: 'room',
          entityId: id,
          status: 'success',
          ipAddress: req.ip ?? null,
        });
        res.status(200).json({ ok: true, data: result });
      } catch (err) {
        next(err);
      }
    },
  };
}
