import type Database from 'better-sqlite3';
import type { NextFunction, Request, Response } from 'express';
import { DepartmentRepository } from '../database/repositories/departmentRepository.ts';
import { SettingsRepository } from '../database/repositories/settingsRepository.ts';
import { TimeSlotRepository } from '../database/repositories/timeSlotRepository.ts';
import type { AuthenticatedRequest } from '../middleware/authMiddleware.ts';
import { AppError } from '../middleware/errorHandler.ts';
import { AuditService } from '../services/auditService.ts';
import {
  createDepartmentSchema,
  updateSettingsSchema,
  updateTimeSlotsSchema,
} from '../validators/schemas.ts';

export function createSettingsController(db: Database.Database) {
  const settingsRepo = new SettingsRepository(db);
  const slotRepo = new TimeSlotRepository(db);
  const deptRepo = new DepartmentRepository(db);
  const audit = new AuditService(db);

  return {
    getSettings(_req: Request, res: Response, next: NextFunction): void {
      try {
        res.status(200).json({
          ok: true,
          data: {
            academicTerm: settingsRepo.getAcademicTerm(),
            timeSlots: slotRepo.findAll(),
            departments: deptRepo.findAll(),
          },
        });
      } catch (err) {
        next(err);
      }
    },

    updateSettings(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const input = updateSettingsSchema.parse(req.body);
        const updated = settingsRepo.updateAcademicTerm(input);
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'SETTINGS_UPDATE',
          entityType: 'institution_settings',
          entityId: 'academic_term',
          status: 'success',
          details: input,
          ipAddress: req.ip ?? null,
        });
        res.status(200).json({ ok: true, data: updated });
      } catch (err) {
        next(err);
      }
    },

    updateTimeSlots(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const { slots } = updateTimeSlotsSchema.parse(req.body);
        const sorted = [...slots].sort((a, b) => a.periodNumber - b.periodNumber);
        const seen = new Set<number>();
        for (const s of sorted) {
          if (seen.has(s.periodNumber)) {
            throw new AppError(400, 'DUPLICATE_PERIOD', `Duplicate period number ${s.periodNumber}.`);
          }
          seen.add(s.periodNumber);
        }
        const replaced = slotRepo.replaceAll(sorted);
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'TIME_SLOTS_UPDATE',
          entityType: 'time_slots',
          status: 'success',
          details: { count: replaced.length },
          ipAddress: req.ip ?? null,
        });
        res.status(200).json({ ok: true, data: replaced });
      } catch (err) {
        next(err);
      }
    },

    listDepartments(_req: Request, res: Response, next: NextFunction): void {
      try {
        res.status(200).json({ ok: true, data: deptRepo.findAll() });
      } catch (err) {
        next(err);
      }
    },

    createDepartment(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const input = createDepartmentSchema.parse(req.body);
        const created = deptRepo.create(input);
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'DEPARTMENT_CREATE',
          entityType: 'department',
          entityId: created.id,
          status: 'success',
          details: { code: created.code, name: created.name },
          ipAddress: req.ip ?? null,
        });
        res.status(201).json({ ok: true, data: created });
      } catch (err) {
        next(err);
      }
    },
  };
}
