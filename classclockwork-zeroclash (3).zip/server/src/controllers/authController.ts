import type Database from 'better-sqlite3';
import type { NextFunction, Request, Response } from 'express';
import { config } from '../config/env.ts';
import {
  type AuthenticatedRequest,
  CSRF_COOKIE_NAME,
  SESSION_COOKIE_NAME,
} from '../middleware/authMiddleware.ts';
import { AuditService } from '../services/auditService.ts';
import { AuthService } from '../services/authService.ts';
import { loginSchema } from '../validators/schemas.ts';

function isSecureCookieRequest(req: Request): boolean {
  if (config.cookieSecure === 'true') return true;
  if (config.cookieSecure === 'false') return false;
  const proto = req.headers['x-forwarded-proto'];
  return req.secure || (typeof proto === 'string' && proto.split(',')[0].trim() === 'https');
}

export function createAuthController(db: Database.Database) {
  const service = new AuthService(db);
  const audit = new AuditService(db);

  return {
    login(req: Request, res: Response, next: NextFunction): void {
      try {
        const parsed = loginSchema.parse(req.body);
        const result = service.login(parsed.username, parsed.password, {
          userAgent: req.headers['user-agent'] ?? null,
          ipAddress: req.ip ?? null,
        });

        const secure = isSecureCookieRequest(req);

        res.cookie(SESSION_COOKIE_NAME, result.token, {
          httpOnly: true,
          sameSite: 'lax',
          secure,
          maxAge: result.expiresInMs,
          path: '/',
        });

        res.cookie(CSRF_COOKIE_NAME, result.csrfToken, {
          httpOnly: false,
          sameSite: 'lax',
          secure,
          maxAge: result.expiresInMs,
          path: '/',
        });

        audit.log({
          actorUserId: result.user.id,
          actorUsername: result.user.username,
          action: 'AUTH_LOGIN',
          entityType: 'session',
          entityId: result.jti,
          status: 'success',
          details: { role: result.user.role },
          ipAddress: req.ip ?? null,
        });

        // Do not expose raw JWT in response body to prevent XSS token harvesting
        res.status(200).json({
          ok: true,
          data: {
            user: {
              id: result.user.id,
              username: result.user.username,
              email: result.user.email,
              fullName: result.user.fullName,
              role: result.user.role,
            },
            expiresIn: result.expiresIn,
            csrfToken: result.csrfToken,
          },
        });
      } catch (err) {
        const attemptedUser = typeof req.body?.username === 'string' ? req.body.username.trim().slice(0, 80) : null;
        audit.log({
          actorUserId: null,
          actorUsername: attemptedUser,
          action: 'AUTH_LOGIN_FAILED',
          entityType: 'session',
          status: 'failure',
          details: { reason: err instanceof Error ? err.message : 'Login failed' },
          ipAddress: req.ip ?? null,
        });
        next(err);
      }
    },

    logout(req: AuthenticatedRequest, res: Response): void {
      const revoked = service.logout(req.user?.jti);
      const secure = isSecureCookieRequest(req);

      res.clearCookie(SESSION_COOKIE_NAME, {
        httpOnly: true,
        sameSite: 'lax',
        secure,
        path: '/',
      });
      res.clearCookie(CSRF_COOKIE_NAME, {
        httpOnly: false,
        sameSite: 'lax',
        secure,
        path: '/',
      });

      if (req.user) {
        audit.log({
          actorUserId: req.user.id,
          actorUsername: req.user.username,
          action: 'AUTH_LOGOUT',
          entityType: 'session',
          entityId: req.user.jti ?? null,
          status: 'success',
          details: { revoked: revoked.revoked },
          ipAddress: req.ip ?? null,
        });
      }

      res.status(200).json({ ok: true, data: { loggedOut: true, revoked: revoked.revoked } });
    },

    me(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const profile = service.getProfile(req.user!.id);
        res.status(200).json({ ok: true, data: { user: profile } });
      } catch (err) {
        next(err);
      }
    },
  };
}
