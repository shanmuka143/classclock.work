import type Database from 'better-sqlite3';
import type { NextFunction, Request, Response } from 'express';
import type { AuthenticatedRequest } from '../middleware/authMiddleware.ts';
import { AppError } from '../middleware/errorHandler.ts';
import { AuditService } from '../services/auditService.ts';
import { FacultyService } from '../services/facultyService.ts';
import { sendListOrPaginated } from '../utils/pagination.ts';
import { createFacultySchema, updateFacultySchema } from '../validators/schemas.ts';

export function createFacultyController(db: Database.Database) {
  const service = new FacultyService(db);
  const audit = new AuditService(db);

  return {
    list(req: Request, res: Response, next: NextFunction): void {
      try {
        const departmentId = req.query.departmentId ? Number(req.query.departmentId) : undefined;
        const search = typeof req.query.search === 'string' ? req.query.search : undefined;
        const items = service.list({ departmentId, search });
        sendListOrPaginated(req, res, items);
      } catch (err) {
        next(err);
      }
    },

    getById(req: Request, res: Response, next: NextFunction): void {
      try {
        const id = Number(req.params.id);
        if (!Number.isInteger(id) || id <= 0) throw new AppError(400, 'INVALID_ID', 'Invalid faculty ID.');
        res.status(200).json({ ok: true, data: service.getById(id) });
      } catch (err) {
        next(err);
      }
    },

    create(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const input = createFacultySchema.parse(req.body);
        const created = service.create(input);
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'FACULTY_CREATE',
          entityType: 'faculty',
          entityId: created.id,
          status: 'success',
          details: { facultyCode: created.facultyCode, fullName: created.fullName },
          ipAddress: req.ip ?? null,
        });
        res.status(201).json({ ok: true, data: created });
      } catch (err) {
        next(err);
      }
    },

    update(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const id = Number(req.params.id);
        if (!Number.isInteger(id) || id <= 0) throw new AppError(400, 'INVALID_ID', 'Invalid faculty ID.');
        const input = updateFacultySchema.parse(req.body);
        const updated = service.update(id, input);
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'FACULTY_UPDATE',
          entityType: 'faculty',
          entityId: id,
          status: 'success',
          details: { facultyCode: updated.facultyCode },
          ipAddress: req.ip ?? null,
        });
        res.status(200).json({ ok: true, data: updated });
      } catch (err) {
        next(err);
      }
    },

    remove(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const id = Number(req.params.id);
        if (!Number.isInteger(id) || id <= 0) throw new AppError(400, 'INVALID_ID', 'Invalid faculty ID.');
        let reassignToId: number | null | undefined = undefined;
        if (req.query.reassignTo === 'null') {
          reassignToId = null;
        } else if (req.query.reassignTo !== undefined) {
          const parsed = Number(req.query.reassignTo);
          if (!Number.isInteger(parsed) || parsed <= 0) {
            throw new AppError(400, 'INVALID_REASSIGN_ID', 'Invalid reassignment faculty ID.');
          }
          reassignToId = parsed;
        }
        const result = service.delete(id, reassignToId);
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'FACULTY_DELETE',
          entityType: 'faculty',
          entityId: id,
          status: 'success',
          details: { reassignToId: reassignToId ?? null },
          ipAddress: req.ip ?? null,
        });
        res.status(200).json({ ok: true, data: result });
      } catch (err) {
        next(err);
      }
    },
  };
}
