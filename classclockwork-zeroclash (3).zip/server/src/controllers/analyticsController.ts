import type Database from 'better-sqlite3';
import type { NextFunction, Request, Response } from 'express';
import { AnalyticsService } from '../services/analyticsService.ts';

export function createAnalyticsController(db: Database.Database) {
  const service = new AnalyticsService(db);

  return {
    workload(_req: Request, res: Response, next: NextFunction): void {
      try {
        res.status(200).json({ ok: true, data: service.getWorkloadAnalytics() });
      } catch (err) {
        next(err);
      }
    },

    roomUtilization(_req: Request, res: Response, next: NextFunction): void {
      try {
        res.status(200).json({ ok: true, data: service.getRoomUtilizationAnalytics() });
      } catch (err) {
        next(err);
      }
    },

    scheduling(_req: Request, res: Response, next: NextFunction): void {
      try {
        res.status(200).json({ ok: true, data: service.getSchedulingAnalytics() });
      } catch (err) {
        next(err);
      }
    },
  };
}
