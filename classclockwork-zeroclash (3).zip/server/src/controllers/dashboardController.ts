import type Database from 'better-sqlite3';
import type { NextFunction, Request, Response } from 'express';
import { DashboardService } from '../services/dashboardService.ts';

export function createDashboardController(db: Database.Database) {
  const service = new DashboardService(db);

  return {
    getStats(_req: Request, res: Response, next: NextFunction): void {
      try {
        const stats = service.getStats();
        res.status(200).json({ ok: true, data: stats });
      } catch (err) {
        next(err);
      }
    },
  };
}
