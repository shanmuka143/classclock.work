import path from 'node:path';
import type Database from 'better-sqlite3';
import type { NextFunction, Response } from 'express';
import type { AuthenticatedRequest } from '../middleware/authMiddleware.ts';
import { AuditService } from '../services/auditService.ts';
import { DatabaseMaintenanceService } from '../services/databaseMaintenanceService.ts';

export function createSystemController(db: Database.Database) {
  const audit = new AuditService(db);
  const maintenance = new DatabaseMaintenanceService(db);

  return {
    listAuditLogs(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const action = typeof req.query.action === 'string' ? req.query.action : undefined;
        const status = typeof req.query.status === 'string' ? req.query.status : undefined;
        const page = req.query.page ? Number(req.query.page) : 1;
        const limit = req.query.limit ? Number(req.query.limit) : 25;

        const data = audit.list({
          action,
          status,
          page: Number.isFinite(page) ? page : 1,
          limit: Number.isFinite(limit) ? limit : 25,
        });

        res.status(200).json({ ok: true, data });
      } catch (err) {
        next(err);
      }
    },

    checkIntegrity(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const report = maintenance.checkIntegrity();
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'SYSTEM_INTEGRITY_CHECK',
          entityType: 'database',
          status: report.integrityOk ? 'success' : 'failure',
          details: {
            foreignKeyViolationsCount: report.foreignKeyViolationsCount,
            journalMode: report.journalMode,
          },
          ipAddress: req.ip ?? null,
        });
        res.status(200).json({ ok: true, data: report });
      } catch (err) {
        next(err);
      }
    },

    async createBackup(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
      try {
        const result = await maintenance.createBackup();
        const fileName = path.basename(result.backupPath);
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'SYSTEM_DATABASE_BACKUP',
          entityType: 'database',
          entityId: fileName,
          status: result.integrityOk ? 'success' : 'failure',
          details: {
            fileName,
            sizeBytes: result.sizeBytes,
            integrityOk: result.integrityOk,
          },
          ipAddress: req.ip ?? null,
        });
        res.status(201).json({
          ok: true,
          data: {
            fileName,
            sizeBytes: result.sizeBytes,
            integrityOk: result.integrityOk,
            createdAt: result.createdAt,
          },
        });
      } catch (err) {
        next(err);
      }
    },
  };
}
