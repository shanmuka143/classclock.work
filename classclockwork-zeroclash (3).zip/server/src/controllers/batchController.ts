import type Database from 'better-sqlite3';
import type { NextFunction, Request, Response } from 'express';
import type { AuthenticatedRequest } from '../middleware/authMiddleware.ts';
import { AppError } from '../middleware/errorHandler.ts';
import { AuditService } from '../services/auditService.ts';
import { BatchService } from '../services/batchService.ts';
import { sendListOrPaginated } from '../utils/pagination.ts';
import { createBatchSchema, updateBatchSchema } from '../validators/schemas.ts';

export function createBatchController(db: Database.Database) {
  const service = new BatchService(db);
  const audit = new AuditService(db);

  return {
    list(req: Request, res: Response, next: NextFunction): void {
      try {
        const departmentId = req.query.departmentId ? Number(req.query.departmentId) : undefined;
        const search = typeof req.query.search === 'string' ? req.query.search : undefined;
        const items = service.list({ departmentId, search });
        sendListOrPaginated(req, res, items);
      } catch (err) {
        next(err);
      }
    },

    create(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const input = createBatchSchema.parse(req.body);
        const created = service.create(input);
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'BATCH_CREATE',
          entityType: 'batch',
          entityId: created.id,
          status: 'success',
          details: { batchCode: created.batchCode, name: created.name },
          ipAddress: req.ip ?? null,
        });
        res.status(201).json({ ok: true, data: created });
      } catch (err) {
        next(err);
      }
    },

    update(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const id = Number(req.params.id);
        if (!Number.isInteger(id) || id <= 0) throw new AppError(400, 'INVALID_ID', 'Invalid batch ID.');
        const input = updateBatchSchema.parse(req.body);
        const updated = service.update(id, input);
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'BATCH_UPDATE',
          entityType: 'batch',
          entityId: id,
          status: 'success',
          details: { batchCode: updated.batchCode },
          ipAddress: req.ip ?? null,
        });
        res.status(200).json({ ok: true, data: updated });
      } catch (err) {
        next(err);
      }
    },

    remove(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const id = Number(req.params.id);
        if (!Number.isInteger(id) || id <= 0) throw new AppError(400, 'INVALID_ID', 'Invalid batch ID.');
        const result = service.delete(id);
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'BATCH_DELETE',
          entityType: 'batch',
          entityId: id,
          status: 'success',
          ipAddress: req.ip ?? null,
        });
        res.status(200).json({ ok: true, data: result });
      } catch (err) {
        next(err);
      }
    },
  };
}
