import type Database from 'better-sqlite3';
import type { NextFunction, Request, Response } from 'express';
import type { AuthenticatedRequest } from '../middleware/authMiddleware.ts';
import { AppError } from '../middleware/errorHandler.ts';
import { AuditService } from '../services/auditService.ts';
import { TimetableService } from '../services/timetableService.ts';
import {
  generateTimetableSchema,
  publishRunSchema,
  saveWorkerResultSchema,
  updateAllocationSchema,
  validateAllocationChangeSchema,
} from '../validators/schemas.ts';

export function createTimetableController(db: Database.Database) {
  const service = new TimetableService(db);
  const audit = new AuditService(db);

  return {
    getTimetable(req: Request, res: Response, next: NextFunction): void {
      try {
        const runId = req.query.runId ? Number(req.query.runId) : undefined;
        const batchId = req.query.batchId ? Number(req.query.batchId) : undefined;
        const facultyId = req.query.facultyId ? Number(req.query.facultyId) : undefined;
        const roomId = req.query.roomId ? Number(req.query.roomId) : undefined;
        const subjectId = req.query.subjectId ? Number(req.query.subjectId) : undefined;
        const search = typeof req.query.search === 'string' ? req.query.search : undefined;
        res.status(200).json({
          ok: true,
          data: service.getTimetable({ runId, batchId, facultyId, roomId, subjectId, search }),
        });
      } catch (err) {
        next(err);
      }
    },

    getSolverPayload(req: Request, res: Response, next: NextFunction): void {
      try {
        const preserveLocked = req.query.preserveLocked === 'true';
        res.status(200).json({ ok: true, data: service.getSolverInput(preserveLocked) });
      } catch (err) {
        next(err);
      }
    },

    generate(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const options = generateTimetableSchema.parse(req.body ?? {});
        const outcome = service.generateOnServer(options, req.user?.id ?? null);
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'TIMETABLE_GENERATE_SERVER',
          entityType: 'scheduling_run',
          entityId: outcome.run.id,
          status: 'success',
          details: {
            runStatus: outcome.run.status,
            scheduledMeetings: outcome.run.scheduledMeetings,
            totalMeetings: outcome.run.totalMeetings,
            optimizationScore: outcome.run.optimizationScore,
          },
          ipAddress: req.ip ?? null,
        });
        res.status(201).json({ ok: true, data: outcome });
      } catch (err) {
        next(err);
      }
    },

    saveWorkerResult(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const payload = saveWorkerResultSchema.parse(req.body);
        const outcome = service.saveWorkerGeneratedRun(payload, req.user?.id ?? null);
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'TIMETABLE_SAVE_WORKER',
          entityType: 'scheduling_run',
          entityId: outcome.run.id,
          status: 'success',
          details: {
            runStatus: outcome.run.status,
            scheduledMeetings: outcome.run.scheduledMeetings,
            totalMeetings: outcome.run.totalMeetings,
            optimizationScore: outcome.run.optimizationScore,
          },
          ipAddress: req.ip ?? null,
        });
        res.status(201).json({ ok: true, data: outcome });
      } catch (err) {
        next(err);
      }
    },

    updateAllocation(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const id = Number(req.params.id);
        if (!Number.isInteger(id) || id <= 0) throw new AppError(400, 'INVALID_ID', 'Invalid allocation ID.');
        const patch = updateAllocationSchema.parse(req.body);
        const result = service.updateAllocation(id, patch);
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'ALLOCATION_UPDATE',
          entityType: 'timetable_allocation',
          entityId: id,
          status: 'success',
          details: patch,
          ipAddress: req.ip ?? null,
        });
        res.status(200).json({ ok: true, data: result });
      } catch (err) {
        next(err);
      }
    },

    deleteAllocation(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const id = Number(req.params.id);
        if (!Number.isInteger(id) || id <= 0) throw new AppError(400, 'INVALID_ID', 'Invalid allocation ID.');
        const result = service.deleteAllocation(id);
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'ALLOCATION_DELETE',
          entityType: 'timetable_allocation',
          entityId: id,
          status: 'success',
          ipAddress: req.ip ?? null,
        });
        res.status(200).json({ ok: true, data: result });
      } catch (err) {
        next(err);
      }
    },

    validate(req: Request, res: Response, next: NextFunction): void {
      try {
        const params = validateAllocationChangeSchema.parse(req.body ?? {});
        const report = service.validateProposal(params);
        res.status(200).json({ ok: true, data: report });
      } catch (err) {
        next(err);
      }
    },

    publish(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
      try {
        const { runId } = publishRunSchema.parse(req.body);
        const run = service.publishRun(runId);
        audit.log({
          actorUserId: req.user?.id ?? null,
          actorUsername: req.user?.username ?? null,
          action: 'TIMETABLE_PUBLISH',
          entityType: 'scheduling_run',
          entityId: run.id,
          status: 'success',
          ipAddress: req.ip ?? null,
        });
        res.status(200).json({ ok: true, data: run });
      } catch (err) {
        next(err);
      }
    },
  };
}
