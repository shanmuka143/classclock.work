import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';
import type Database from 'better-sqlite3';
import jwt from 'jsonwebtoken';
import { config } from '../config/env.ts';
import { SessionRepository } from '../database/repositories/sessionRepository.ts';
import { UserRepository } from '../database/repositories/userRepository.ts';
import type { AuthUser } from '../middleware/authMiddleware.ts';
import { AppError } from '../middleware/errorHandler.ts';

export class AuthService {
  private users: UserRepository;
  private sessions: SessionRepository;

  constructor(db: Database.Database) {
    this.users = new UserRepository(db);
    this.sessions = new SessionRepository(db);
  }

  login(
    usernameOrEmail: string,
    password: string,
    meta?: { userAgent?: string | null; ipAddress?: string | null }
  ): {
    token: string;
    csrfToken: string;
    expiresIn: string;
    expiresInMs: number;
    jti: string;
    user: AuthUser;
  } {
    const userRow = this.users.findByUsernameOrEmail(usernameOrEmail.trim());
    if (!userRow) {
      throw new AppError(401, 'INVALID_CREDENTIALS', 'Invalid username or password.');
    }

    const valid = bcrypt.compareSync(password, userRow.password_hash);
    if (!valid) {
      throw new AppError(401, 'INVALID_CREDENTIALS', 'Invalid username or password.');
    }

    // Periodically clean up expired session rows
    this.sessions.purgeExpired();

    const jti = crypto.randomUUID();
    const csrfToken = crypto.randomBytes(32).toString('hex');
    const user: AuthUser = {
      id: userRow.id,
      username: userRow.username,
      email: userRow.email,
      fullName: userRow.full_name,
      role: userRow.role,
      jti,
    };

    const token = jwt.sign(
      {
        id: user.id,
        username: user.username,
        email: user.email,
        fullName: user.fullName,
        role: user.role,
        jti,
      },
      config.jwtSecret,
      {
        expiresIn: config.jwtExpiresIn as jwt.SignOptions['expiresIn'],
      }
    );

    const expiresAtIso = new Date(Date.now() + config.jwtExpiresInMs).toISOString();
    this.sessions.create({
      jti,
      userId: user.id,
      expiresAtIso,
      userAgent: meta?.userAgent ?? null,
      ipAddress: meta?.ipAddress ?? null,
    });

    return {
      token,
      csrfToken,
      expiresIn: config.jwtExpiresIn,
      expiresInMs: config.jwtExpiresInMs,
      jti,
      user,
    };
  }

  logout(jti?: string): { revoked: boolean } {
    if (!jti) return { revoked: false };
    return { revoked: this.sessions.revoke(jti) };
  }

  getProfile(userId: number): AuthUser {
    const row = this.users.findById(userId);
    if (!row) {
      throw new AppError(404, 'USER_NOT_FOUND', 'User account was not found.');
    }
    return {
      id: row.id,
      username: row.username,
      email: row.email,
      fullName: row.full_name,
      role: row.role,
    };
  }
}
