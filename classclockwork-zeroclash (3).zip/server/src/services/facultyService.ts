import type Database from 'better-sqlite3';
import { DepartmentRepository } from '../database/repositories/departmentRepository.ts';
import {
  type CreateFacultyInput,
  type FacultyRecord,
  FacultyRepository,
} from '../database/repositories/facultyRepository.ts';
import { AppError } from '../middleware/errorHandler.ts';

export class FacultyService {
  private repo: FacultyRepository;
  private deptRepo: DepartmentRepository;

  constructor(db: Database.Database) {
    this.repo = new FacultyRepository(db);
    this.deptRepo = new DepartmentRepository(db);
  }

  list(filters?: { departmentId?: number; search?: string }): FacultyRecord[] {
    let items = this.repo.findAll();
    if (filters?.departmentId) {
      items = items.filter((f) => f.departmentId === filters.departmentId);
    }
    if (filters?.search) {
      const q = filters.search.toLowerCase();
      items = items.filter(
        (f) =>
          f.fullName.toLowerCase().includes(q) ||
          f.facultyCode.toLowerCase().includes(q) ||
          f.email.toLowerCase().includes(q) ||
          f.departmentName.toLowerCase().includes(q)
      );
    }
    return items;
  }

  getById(id: number): FacultyRecord {
    const found = this.repo.findById(id);
    if (!found) {
      throw new AppError(404, 'FACULTY_NOT_FOUND', `Faculty member #${id} was not found.`);
    }
    return found;
  }

  create(input: CreateFacultyInput): FacultyRecord {
    const dept = this.deptRepo.findById(input.departmentId);
    if (!dept) {
      throw new AppError(400, 'INVALID_DEPARTMENT', `Department #${input.departmentId} does not exist.`);
    }
    return this.repo.create(input);
  }

  update(id: number, input: Partial<CreateFacultyInput>): FacultyRecord {
    if (input.departmentId !== undefined) {
      const dept = this.deptRepo.findById(input.departmentId);
      if (!dept) {
        throw new AppError(400, 'INVALID_DEPARTMENT', `Department #${input.departmentId} does not exist.`);
      }
    }
    const updated = this.repo.update(id, input);
    if (!updated) {
      throw new AppError(404, 'FACULTY_NOT_FOUND', `Faculty member #${id} was not found.`);
    }
    return updated;
  }

  delete(id: number, reassignToId?: number | null): { deleted: boolean } {
    this.getById(id);
    const deps = this.repo.countDependencies(id);

    if ((deps.subjects > 0 || deps.allocations > 0) && reassignToId === undefined) {
      throw new AppError(
        409,
        'FACULTY_HAS_DEPENDENCIES',
        `Cannot delete faculty member because they are assigned to ${deps.subjects} subject(s) and ${deps.allocations} timetable allocation(s). Reassign or unassign subjects first.`,
        deps
      );
    }

    if (reassignToId !== undefined && reassignToId !== null) {
      if (reassignToId === id) {
        throw new AppError(400, 'INVALID_REASSIGNMENT', 'Cannot reassign subjects to the same faculty member being deleted.');
      }
      this.getById(reassignToId);
    }

    const ok = this.repo.delete(id, reassignToId);
    return { deleted: ok };
  }
}
