import type Database from 'better-sqlite3';
import {
  type BatchRecord,
  BatchRepository,
  type CreateBatchInput,
} from '../database/repositories/batchRepository.ts';
import { DepartmentRepository } from '../database/repositories/departmentRepository.ts';
import { AppError } from '../middleware/errorHandler.ts';

export class BatchService {
  private repo: BatchRepository;
  private deptRepo: DepartmentRepository;

  constructor(db: Database.Database) {
    this.repo = new BatchRepository(db);
    this.deptRepo = new DepartmentRepository(db);
  }

  list(filters?: { departmentId?: number; search?: string }): BatchRecord[] {
    let items = this.repo.findAll();
    if (filters?.departmentId) items = items.filter((b) => b.departmentId === filters.departmentId);
    if (filters?.search) {
      const q = filters.search.toLowerCase();
      items = items.filter(
        (b) =>
          b.batchCode.toLowerCase().includes(q) ||
          b.name.toLowerCase().includes(q) ||
          b.departmentName.toLowerCase().includes(q)
      );
    }
    return items;
  }

  getById(id: number): BatchRecord {
    const found = this.repo.findById(id);
    if (!found) throw new AppError(404, 'BATCH_NOT_FOUND', `Batch #${id} was not found.`);
    return found;
  }

  create(input: CreateBatchInput): BatchRecord {
    if (!this.deptRepo.findById(input.departmentId)) {
      throw new AppError(400, 'INVALID_DEPARTMENT', `Department #${input.departmentId} does not exist.`);
    }
    return this.repo.create(input);
  }

  update(id: number, input: Partial<CreateBatchInput>): BatchRecord {
    if (input.departmentId !== undefined && !this.deptRepo.findById(input.departmentId)) {
      throw new AppError(400, 'INVALID_DEPARTMENT', `Department #${input.departmentId} does not exist.`);
    }
    const updated = this.repo.update(id, input);
    if (!updated) throw new AppError(404, 'BATCH_NOT_FOUND', `Batch #${id} was not found.`);
    return updated;
  }

  delete(id: number): { deleted: boolean } {
    this.getById(id);
    const deps = this.repo.countDependencies(id);
    if (deps.subjects > 0) {
      throw new AppError(
        409,
        'BATCH_HAS_DEPENDENCIES',
        `Cannot delete batch because ${deps.subjects} subject(s) are assigned to it.`,
        deps
      );
    }
    return { deleted: this.repo.delete(id) };
  }
}
