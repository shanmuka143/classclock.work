import type Database from 'better-sqlite3';
import { logger } from '../config/logger.ts';
import {
  AuditRepository,
  type AuditLogRecord,
  type CreateAuditLogInput,
} from '../database/repositories/auditRepository.ts';

export class AuditService {
  private repo: AuditRepository;

  constructor(db: Database.Database) {
    this.repo = new AuditRepository(db);
  }

  log(input: CreateAuditLogInput): void {
    try {
      this.repo.record(input);
    } catch (err) {
      logger.warn('Failed to persist audit log entry', {
        action: input.action,
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }

  list(filters?: {
    action?: string;
    status?: string;
    page?: number;
    limit?: number;
  }): { items: AuditLogRecord[]; total: number; page: number; limit: number } {
    return this.repo.list(filters);
  }
}
