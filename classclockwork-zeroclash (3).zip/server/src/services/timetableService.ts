import type Database from 'better-sqlite3';
import { validateTimetable } from '../../../shared/csp/conflictDetector.ts';
import { solveTimetableCsp } from '../../../shared/csp/cspSolver.ts';
import type { CspAllocation, DayOfWeek, UnscheduledMeeting } from '../../../shared/csp/types.ts';
import { BatchRepository } from '../database/repositories/batchRepository.ts';
import { FacultyRepository } from '../database/repositories/facultyRepository.ts';
import { RoomRepository } from '../database/repositories/roomRepository.ts';
import { SubjectRepository } from '../database/repositories/subjectRepository.ts';
import { TimeSlotRepository } from '../database/repositories/timeSlotRepository.ts';
import {
  type SchedulingRunRecord,
  type TimetableAllocationRecord,
  TimetableRepository,
} from '../database/repositories/timetableRepository.ts';
import { AppError } from '../middleware/errorHandler.ts';

export class TimetableService {
  private db: Database.Database;
  private repo: TimetableRepository;
  private subjects: SubjectRepository;
  private faculty: FacultyRepository;
  private batches: BatchRepository;
  private rooms: RoomRepository;
  private timeSlots: TimeSlotRepository;

  constructor(db: Database.Database) {
    this.db = db;
    this.repo = new TimetableRepository(db);
    this.subjects = new SubjectRepository(db);
    this.faculty = new FacultyRepository(db);
    this.batches = new BatchRepository(db);
    this.rooms = new RoomRepository(db);
    this.timeSlots = new TimeSlotRepository(db);
  }

  getSolverInput(preserveLocked = false) {
    const subjects = this.subjects.findAll();
    const faculty = this.faculty.findAll();
    const batches = this.batches.findAll();
    const rooms = this.rooms.findAll();
    const timeSlots = this.timeSlots.findAll();
    let lockedAllocations: CspAllocation[] = [];

    if (preserveLocked) {
      const latest = this.repo.getLatestRun();
      if (latest) {
        lockedAllocations = this.repo
          .getAllocationsByRun(latest.id)
          .filter((a) => a.isLocked)
          .map((a) => ({
            subjectId: a.subjectId,
            facultyId: a.facultyId,
            batchId: a.batchId,
            roomId: a.roomId,
            day: a.day,
            startPeriod: a.startPeriod,
            durationPeriods: a.durationPeriods,
            sessionIndex: a.sessionIndex,
          }));
      }
    }

    return { subjects, faculty, batches, rooms, timeSlots, lockedAllocations };
  }

  getTimetable(filters?: {
    runId?: number;
    batchId?: number;
    facultyId?: number;
    roomId?: number;
    subjectId?: number;
    search?: string;
  }) {
    const run = filters?.runId ? this.repo.getRunById(filters.runId) : this.repo.getLatestRun();
    const runsHistory = this.repo.listRuns(15);
    const timeSlots = this.timeSlots.findAll();

    if (!run) {
      return {
        run: null,
        runsHistory,
        timeSlots,
        allocations: [],
        allAllocationsCount: 0,
        validation: validateTimetable({
          allocations: [],
          subjects: this.subjects.findAll(),
          faculty: this.faculty.findAll(),
          batches: this.batches.findAll(),
          rooms: this.rooms.findAll(),
          timeSlots,
        }),
        logs: [],
      };
    }

    const allAllocations = this.repo.getAllocationsByRun(run.id);
    const validation = validateTimetable({
      allocations: allAllocations,
      subjects: this.subjects.findAll(),
      faculty: this.faculty.findAll(),
      batches: this.batches.findAll(),
      rooms: this.rooms.findAll(),
      timeSlots,
    });

    let filtered = allAllocations;
    if (filters?.batchId) filtered = filtered.filter((a) => a.batchId === filters.batchId);
    if (filters?.facultyId) filtered = filtered.filter((a) => a.facultyId === filters.facultyId);
    if (filters?.roomId) filtered = filtered.filter((a) => a.roomId === filters.roomId);
    if (filters?.subjectId) filtered = filtered.filter((a) => a.subjectId === filters.subjectId);
    if (filters?.search) {
      const q = filters.search.toLowerCase();
      filtered = filtered.filter(
        (a) =>
          a.subjectCode.toLowerCase().includes(q) ||
          a.subjectName.toLowerCase().includes(q) ||
          a.facultyName.toLowerCase().includes(q) ||
          a.batchCode.toLowerCase().includes(q) ||
          a.roomCode.toLowerCase().includes(q)
      );
    }

    return {
      run,
      runsHistory,
      timeSlots,
      allocations: filtered,
      allAllocationsCount: allAllocations.length,
      validation,
      logs: this.repo.getLogsForRun(run.id),
    };
  }

  generateOnServer(
    options: {
      maxNodes?: number;
      timeoutMs?: number;
      enableForwardChecking?: boolean;
      enableLcv?: boolean;
      enableMrv?: boolean;
      allowPartialFallback?: boolean;
      publishImmediately?: boolean;
      preserveLocked?: boolean;
    },
    userId: number | null
  ) {
    const input = this.getSolverInput(Boolean(options.preserveLocked));
    const result = solveTimetableCsp({
      subjects: input.subjects,
      faculty: input.faculty,
      batches: input.batches,
      rooms: input.rooms,
      timeSlots: input.timeSlots,
      lockedAllocations: input.lockedAllocations,
      options,
    });

    const savedRun = this.repo.saveGeneratedRun({
      status: result.status,
      publishImmediately: options.publishImmediately ?? true,
      totalMeetings: result.totalMeetings,
      scheduledMeetings: result.scheduledMeetings,
      unscheduledList: result.unscheduledMeetings,
      hardConflictsCount: result.validation.hardViolations.length,
      optimizationScore: result.optimizationScore,
      nodesExplored: result.nodesExplored,
      durationMs: result.durationMs,
      config: options,
      allocations: result.allocations,
      logs: result.logs,
      createdBy: userId,
    });

    return {
      run: savedRun,
      result,
      allocations: this.repo.getAllocationsByRun(savedRun.id),
    };
  }

  saveWorkerGeneratedRun(
    payload: {
      status: 'optimal' | 'feasible' | 'partial' | 'infeasible' | 'timeout' | 'cancelled';
      totalMeetings: number;
      scheduledMeetings: number;
      unscheduledMeetings: UnscheduledMeeting[];
      nodesExplored: number;
      durationMs: number;
      publishImmediately: boolean;
      config: Record<string, unknown>;
      allocations: CspAllocation[];
    },
    userId: number | null
  ) {
    // Independent server-side validation — never trust client allocations, totals, or status without verifying!
    const subjects = this.subjects.findAll();
    const faculty = this.faculty.findAll();
    const batches = this.batches.findAll();
    const rooms = this.rooms.findAll();
    const timeSlots = this.timeSlots.findAll();

    const subjectIds = new Set(subjects.map((s) => s.id));
    const facultyIds = new Set(faculty.map((f) => f.id));
    const batchIds = new Set(batches.map((b) => b.id));
    const roomIds = new Set(rooms.map((r) => r.id));

    for (const a of payload.allocations) {
      if (!subjectIds.has(a.subjectId) || !facultyIds.has(a.facultyId) || !batchIds.has(a.batchId) || !roomIds.has(a.roomId)) {
        throw new AppError(
          400,
          'INVALID_ENTITY_REFERENCE',
          `Submitted allocation references a non-existent subject, faculty, batch, or room.`
        );
      }
    }

    const validation = validateTimetable({
      allocations: payload.allocations,
      subjects,
      faculty,
      batches,
      rooms,
      timeSlots,
    });

    if (!validation.isValid) {
      throw new AppError(
        409,
        'GENERATED_SCHEDULE_INVALID',
        `Submitted timetable failed server-side validation (${validation.hardViolations.length} hard violation(s)).`,
        { hardViolations: validation.hardViolations }
      );
    }

    const actualTotalMeetings = subjects.reduce((acc, s) => acc + s.weeklySessions, 0);
    const scheduledKeys = new Set(payload.allocations.map((a) => `${a.subjectId}_${a.sessionIndex}`));
    const unscheduledMap = new Map(
      payload.unscheduledMeetings.map((u) => [`${u.subjectId}_${u.sessionIndex}`, u])
    );

    const serverUnscheduled: UnscheduledMeeting[] = [];
    for (const sub of subjects) {
      for (let sIdx = 1; sIdx <= sub.weeklySessions; sIdx++) {
        const key = `${sub.id}_${sIdx}`;
        if (!scheduledKeys.has(key)) {
          const clientDiag = unscheduledMap.get(key);
          serverUnscheduled.push({
            variableId: `sub_${sub.id}_s${sIdx}`,
            subjectId: sub.id,
            subjectCode: sub.subjectCode,
            subjectName: sub.name,
            batchId: sub.batchId,
            facultyId: sub.facultyId,
            sessionIndex: sIdx,
            duration: sub.sessionDuration,
            reason: clientDiag?.reason ?? 'Meeting not scheduled in submitted timetable.',
          });
        }
      }
    }

    let computedStatus: SchedulingRunRecord['status'];
    if (payload.status === 'cancelled') {
      computedStatus = 'cancelled';
    } else if (payload.status === 'timeout' && serverUnscheduled.length > 0) {
      computedStatus = 'timeout';
    } else if (serverUnscheduled.length === 0 && payload.allocations.length === actualTotalMeetings) {
      computedStatus = validation.softMetrics.overallScore >= 75 ? 'optimal' : 'feasible';
    } else if (payload.allocations.length > 0) {
      computedStatus = 'partial';
    } else {
      computedStatus = 'infeasible';
    }

    const savedRun = this.repo.saveGeneratedRun({
      status: computedStatus,
      publishImmediately: payload.publishImmediately,
      totalMeetings: actualTotalMeetings,
      scheduledMeetings: payload.allocations.length,
      unscheduledList: serverUnscheduled,
      hardConflictsCount: 0,
      optimizationScore: validation.softMetrics.overallScore,
      nodesExplored: payload.nodesExplored,
      durationMs: payload.durationMs,
      config: { ...payload.config, computedBy: 'web-worker' },
      allocations: payload.allocations,
      logs: [
        {
          level: serverUnscheduled.length === 0 ? 'info' : 'warn',
          message: `Worker CSP schedule verified server-side (${payload.allocations.length}/${actualTotalMeetings} scheduled, status ${computedStatus}, score ${validation.softMetrics.overallScore}/100).`,
        },
      ],
      createdBy: userId,
    });

    return {
      run: savedRun,
      validation,
      allocations: this.repo.getAllocationsByRun(savedRun.id),
    };
  }

  updateAllocation(
    id: number,
    patch: { day?: DayOfWeek; startPeriod?: number; roomId?: number; isLocked?: boolean }
  ): { allocation: TimetableAllocationRecord; validation: ReturnType<typeof validateTimetable> } {
    const existing = this.repo.getAllocationById(id);
    if (!existing) {
      throw new AppError(404, 'ALLOCATION_NOT_FOUND', `Timetable allocation #${id} was not found.`);
    }

    const subjects = this.subjects.findAll();
    const faculty = this.faculty.findAll();
    const batches = this.batches.findAll();
    const rooms = this.rooms.findAll();
    const timeSlots = this.timeSlots.findAll();

    if (patch.roomId !== undefined && !rooms.some((r) => r.id === patch.roomId)) {
      throw new AppError(400, 'INVALID_ROOM', `Room #${patch.roomId} does not exist.`);
    }

    const allInRun = this.repo.getAllocationsByRun(existing.runId);
    const candidateAllocations = allInRun.map((a) =>
      a.id === id
        ? {
            ...a,
            day: patch.day ?? a.day,
            startPeriod: patch.startPeriod ?? a.startPeriod,
            roomId: patch.roomId ?? a.roomId,
          }
        : a
    );

    const validation = validateTimetable({
      allocations: candidateAllocations,
      subjects,
      faculty,
      batches,
      rooms,
      timeSlots,
    });

    if (!validation.isValid) {
      throw new AppError(
        409,
        'SCHEDULE_CONFLICT',
        validation.hardViolations.map((v) => v.message).join(' | '),
        { hardViolations: validation.hardViolations }
      );
    }

    const tx = this.db.transaction(() => {
      const updated = this.repo.updateAllocation(id, patch)!;
      this.repo.updateRunStats(existing.runId, {
        hardConflictsCount: 0,
        optimizationScore: validation.softMetrics.overallScore,
        scheduledMeetings: allInRun.length,
      });
      return updated;
    });

    const updated = tx();
    return { allocation: updated, validation };
  }

  validateProposal(params: {
    runId?: number;
    allocationId?: number;
    day?: DayOfWeek;
    startPeriod?: number;
    roomId?: number;
  }) {
    const run = params.runId ? this.repo.getRunById(params.runId) : this.repo.getLatestRun();
    if (!run) {
      throw new AppError(404, 'RUN_NOT_FOUND', 'No scheduling run found to validate.');
    }

    const allInRun = this.repo.getAllocationsByRun(run.id);
    const candidate =
      params.allocationId !== undefined
        ? allInRun.map((a) =>
            a.id === params.allocationId
              ? {
                  ...a,
                  day: params.day ?? a.day,
                  startPeriod: params.startPeriod ?? a.startPeriod,
                  roomId: params.roomId ?? a.roomId,
                }
              : a
          )
        : allInRun;

    return validateTimetable({
      allocations: candidate,
      subjects: this.subjects.findAll(),
      faculty: this.faculty.findAll(),
      batches: this.batches.findAll(),
      rooms: this.rooms.findAll(),
      timeSlots: this.timeSlots.findAll(),
    });
  }

  deleteAllocation(id: number): { deleted: boolean } {
    const existing = this.repo.getAllocationById(id);
    if (!existing) {
      throw new AppError(404, 'ALLOCATION_NOT_FOUND', `Timetable allocation #${id} was not found.`);
    }

    const tx = this.db.transaction(() => {
      const deleted = this.repo.deleteAllocation(id);
      const remaining = this.repo.getAllocationsByRun(existing.runId);
      const validation = validateTimetable({
        allocations: remaining,
        subjects: this.subjects.findAll(),
        faculty: this.faculty.findAll(),
        batches: this.batches.findAll(),
        rooms: this.rooms.findAll(),
        timeSlots: this.timeSlots.findAll(),
      });
      this.repo.updateRunStats(existing.runId, {
        hardConflictsCount: validation.hardViolations.length,
        optimizationScore: validation.softMetrics.overallScore,
        scheduledMeetings: remaining.length,
      });
      return deleted;
    });

    return { deleted: tx() };
  }

  publishRun(runId: number): SchedulingRunRecord {
    const run = this.repo.getRunById(runId);
    if (!run) {
      throw new AppError(404, 'RUN_NOT_FOUND', `Scheduling run #${runId} was not found.`);
    }
    return this.repo.publishRun(runId)!;
  }
}
