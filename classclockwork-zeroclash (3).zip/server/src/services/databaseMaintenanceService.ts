import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import { config } from '../config/env.ts';

export interface IntegrityReport {
  integrityOk: boolean;
  integrityMessages: string[];
  foreignKeyViolationsCount: number;
  journalMode: string;
  tableCounts: Record<string, number>;
  checkedAt: string;
}

export interface BackupResult {
  backupPath: string;
  sizeBytes: number;
  integrityOk: boolean;
  createdAt: string;
}

const AUDITED_TABLES = [
  'users',
  'departments',
  'faculty',
  'batches',
  'rooms',
  'subjects',
  'time_slots',
  'scheduling_runs',
  'timetable_allocations',
  'user_sessions',
  'audit_logs',
] as const;

export class DatabaseMaintenanceService {
  private db: Database.Database;

  constructor(db: Database.Database) {
    this.db = db;
  }

  checkIntegrity(): IntegrityReport {
    const integrityRows = this.db.pragma('integrity_check') as Array<{ integrity_check: string }>;
    const messages = integrityRows.map((r) => String(r.integrity_check));
    const integrityOk = messages.length === 1 && messages[0].toLowerCase() === 'ok';

    const fkViolations = this.db.pragma('foreign_key_check') as unknown[];
    const journalRow = this.db.pragma('journal_mode') as Array<{ journal_mode: string }>;
    const journalMode = journalRow[0]?.journal_mode ?? 'unknown';

    const tableCounts: Record<string, number> = {};
    for (const tbl of AUDITED_TABLES) {
      const row = this.db.prepare(`SELECT COUNT(*) AS cnt FROM ${tbl}`).get() as { cnt: number };
      tableCounts[tbl] = row.cnt;
    }

    return {
      integrityOk: integrityOk && fkViolations.length === 0,
      integrityMessages: messages,
      foreignKeyViolationsCount: fkViolations.length,
      journalMode,
      tableCounts,
      checkedAt: new Date().toISOString(),
    };
  }

  async createBackup(customDir?: string): Promise<BackupResult> {
    const dir = customDir ?? config.backupDir;
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupPath = path.join(dir, `classclockwork-backup-${stamp}.sqlite`);
    await this.db.backup(backupPath);

    const stats = fs.statSync(backupPath);
    const verifyDb = new Database(backupPath, { readonly: true });
    try {
      const check = verifyDb.pragma('integrity_check') as Array<{ integrity_check: string }>;
      const integrityOk = check.length === 1 && check[0].integrity_check.toLowerCase() === 'ok';
      return {
        backupPath,
        sizeBytes: stats.size,
        integrityOk,
        createdAt: new Date().toISOString(),
      };
    } finally {
      verifyDb.close();
    }
  }
}
