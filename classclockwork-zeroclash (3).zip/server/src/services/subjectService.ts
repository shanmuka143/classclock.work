import type Database from 'better-sqlite3';
import { BatchRepository } from '../database/repositories/batchRepository.ts';
import { DepartmentRepository } from '../database/repositories/departmentRepository.ts';
import { FacultyRepository } from '../database/repositories/facultyRepository.ts';
import {
  type CreateSubjectInput,
  type SubjectRecord,
  SubjectRepository,
} from '../database/repositories/subjectRepository.ts';
import { AppError } from '../middleware/errorHandler.ts';

export class SubjectService {
  private repo: SubjectRepository;
  private deptRepo: DepartmentRepository;
  private batchRepo: BatchRepository;
  private facultyRepo: FacultyRepository;

  constructor(db: Database.Database) {
    this.repo = new SubjectRepository(db);
    this.deptRepo = new DepartmentRepository(db);
    this.batchRepo = new BatchRepository(db);
    this.facultyRepo = new FacultyRepository(db);
  }

  list(filters?: { departmentId?: number; semester?: number; batchId?: number; search?: string }): SubjectRecord[] {
    let items = this.repo.findAll();
    if (filters?.departmentId) items = items.filter((s) => s.departmentId === filters.departmentId);
    if (filters?.semester) items = items.filter((s) => s.semester === filters.semester);
    if (filters?.batchId) items = items.filter((s) => s.batchId === filters.batchId);
    if (filters?.search) {
      const q = filters.search.toLowerCase();
      items = items.filter(
        (s) =>
          s.subjectCode.toLowerCase().includes(q) ||
          s.name.toLowerCase().includes(q) ||
          (s.facultyName && s.facultyName.toLowerCase().includes(q)) ||
          s.batchCode.toLowerCase().includes(q)
      );
    }
    return items;
  }

  getById(id: number): SubjectRecord {
    const found = this.repo.findById(id);
    if (!found) {
      throw new AppError(404, 'SUBJECT_NOT_FOUND', `Subject #${id} was not found.`);
    }
    return found;
  }

  create(input: CreateSubjectInput): SubjectRecord {
    this.validateForeignKeys(input.departmentId, input.batchId, input.facultyId);
    return this.repo.create(input);
  }

  update(id: number, input: Partial<CreateSubjectInput>): SubjectRecord {
    const existing = this.getById(id);
    this.validateForeignKeys(
      input.departmentId ?? existing.departmentId,
      input.batchId ?? existing.batchId,
      input.facultyId !== undefined ? input.facultyId : existing.facultyId
    );
    const updated = this.repo.update(id, input);
    if (!updated) throw new AppError(404, 'SUBJECT_NOT_FOUND', `Subject #${id} was not found.`);
    return updated;
  }

  delete(id: number): { deleted: boolean } {
    this.getById(id);
    return { deleted: this.repo.delete(id) };
  }

  private validateForeignKeys(departmentId: number, batchId: number, facultyId: number | null): void {
    if (!this.deptRepo.findById(departmentId)) {
      throw new AppError(400, 'INVALID_DEPARTMENT', `Department #${departmentId} does not exist.`);
    }
    if (!this.batchRepo.findById(batchId)) {
      throw new AppError(400, 'INVALID_BATCH', `Student batch #${batchId} does not exist.`);
    }
    if (facultyId !== null && !this.facultyRepo.findById(facultyId)) {
      throw new AppError(400, 'INVALID_FACULTY', `Faculty member #${facultyId} does not exist.`);
    }
  }
}
