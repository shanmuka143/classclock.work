import type Database from 'better-sqlite3';
import { BatchRepository } from '../database/repositories/batchRepository.ts';
import { DepartmentRepository } from '../database/repositories/departmentRepository.ts';
import { FacultyRepository } from '../database/repositories/facultyRepository.ts';
import { RoomRepository } from '../database/repositories/roomRepository.ts';
import { SubjectRepository } from '../database/repositories/subjectRepository.ts';
import { TimetableRepository } from '../database/repositories/timetableRepository.ts';

export class DashboardService {
  private depts: DepartmentRepository;
  private faculty: FacultyRepository;
  private subjects: SubjectRepository;
  private batches: BatchRepository;
  private rooms: RoomRepository;
  private timetable: TimetableRepository;

  constructor(db: Database.Database) {
    this.depts = new DepartmentRepository(db);
    this.faculty = new FacultyRepository(db);
    this.subjects = new SubjectRepository(db);
    this.batches = new BatchRepository(db);
    this.rooms = new RoomRepository(db);
    this.timetable = new TimetableRepository(db);
  }

  getStats() {
    const departments = this.depts.findAll();
    const facultyList = this.faculty.findAll();
    const subjectList = this.subjects.findAll();
    const batchList = this.batches.findAll();
    const roomList = this.rooms.findAll();
    const latestRun = this.timetable.getLatestRun();
    const allocations = latestRun ? this.timetable.getAllocationsByRun(latestRun.id) : [];

    const totalRequiredMeetings = subjectList.reduce((acc, s) => acc + s.weeklySessions, 0);
    const scheduledClasses = latestRun ? latestRun.scheduledMeetings : 0;
    const unscheduledClasses = latestRun ? latestRun.unscheduledMeetings : totalRequiredMeetings;

    const facultyHoursMap = new Map<number, number>();
    for (const a of allocations) {
      facultyHoursMap.set(a.facultyId, (facultyHoursMap.get(a.facultyId) ?? 0) + a.durationPeriods);
    }

    const facultyWorkload = facultyList.map((f) => {
      const scheduledHours = facultyHoursMap.get(f.id) ?? 0;
      const utilizationPct = f.maxWeeklyHours > 0 ? Math.round((scheduledHours / f.maxWeeklyHours) * 100) : 0;
      return {
        id: f.id,
        facultyCode: f.facultyCode,
        fullName: f.fullName,
        departmentCode: f.departmentCode,
        scheduledHours,
        maxWeeklyHours: f.maxWeeklyHours,
        utilizationPct,
      };
    });

    return {
      counts: {
        departments: departments.length,
        faculty: facultyList.length,
        subjects: subjectList.length,
        batches: batchList.length,
        rooms: roomList.length,
        classrooms: roomList.filter((r) => r.roomType !== 'lab').length,
        labs: roomList.filter((r) => r.roomType === 'lab').length,
        scheduledClasses,
        unscheduledClasses,
        totalRequiredMeetings,
        detectedConflicts: latestRun ? latestRun.hardConflictsCount : 0,
      },
      latestRun: latestRun
        ? {
            id: latestRun.id,
            status: latestRun.status,
            isPublished: latestRun.isPublished,
            optimizationScore: latestRun.optimizationScore,
            nodesExplored: latestRun.nodesExplored,
            durationMs: latestRun.durationMs,
            createdAt: latestRun.createdAt,
          }
        : null,
      facultyWorkload,
      recentLogs: latestRun ? this.timetable.getLogsForRun(latestRun.id).slice(0, 8) : [],
    };
  }
}
