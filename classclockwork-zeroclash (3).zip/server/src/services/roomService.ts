import type Database from 'better-sqlite3';
import {
  type CreateRoomInput,
  type RoomRecord,
  RoomRepository,
} from '../database/repositories/roomRepository.ts';
import { AppError } from '../middleware/errorHandler.ts';

export class RoomService {
  private repo: RoomRepository;

  constructor(db: Database.Database) {
    this.repo = new RoomRepository(db);
  }

  list(filters?: { roomType?: string; search?: string }): RoomRecord[] {
    let items = this.repo.findAll();
    if (filters?.roomType && filters.roomType !== 'all') {
      items = items.filter((r) => r.roomType === filters.roomType);
    }
    if (filters?.search) {
      const q = filters.search.toLowerCase();
      items = items.filter(
        (r) =>
          r.roomCode.toLowerCase().includes(q) ||
          r.name.toLowerCase().includes(q) ||
          r.equipment.some((e) => e.toLowerCase().includes(q))
      );
    }
    return items;
  }

  getById(id: number): RoomRecord {
    const found = this.repo.findById(id);
    if (!found) throw new AppError(404, 'ROOM_NOT_FOUND', `Room #${id} was not found.`);
    return found;
  }

  create(input: CreateRoomInput): RoomRecord {
    return this.repo.create(input);
  }

  update(id: number, input: Partial<CreateRoomInput>): RoomRecord {
    const updated = this.repo.update(id, input);
    if (!updated) throw new AppError(404, 'ROOM_NOT_FOUND', `Room #${id} was not found.`);
    return updated;
  }

  delete(id: number): { deleted: boolean } {
    this.getById(id);
    const deps = this.repo.countDependencies(id);
    if (deps.allocations > 0) {
      throw new AppError(
        409,
        'ROOM_HAS_DEPENDENCIES',
        `Cannot delete room because it has ${deps.allocations} scheduled timetable allocation(s). Regenerate or reassign those classes first.`,
        deps
      );
    }
    return { deleted: this.repo.delete(id) };
  }
}
