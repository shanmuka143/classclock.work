import type Database from 'better-sqlite3';
import { validateTimetable } from '../../../shared/csp/conflictDetector.ts';
import { DAYS_OF_WEEK } from '../../../shared/csp/types.ts';
import { BatchRepository } from '../database/repositories/batchRepository.ts';
import { DepartmentRepository } from '../database/repositories/departmentRepository.ts';
import { FacultyRepository } from '../database/repositories/facultyRepository.ts';
import { RoomRepository } from '../database/repositories/roomRepository.ts';
import { SubjectRepository } from '../database/repositories/subjectRepository.ts';
import { TimeSlotRepository } from '../database/repositories/timeSlotRepository.ts';
import { TimetableRepository } from '../database/repositories/timetableRepository.ts';

export function computeFairnessScore(utilizations: number[]): number {
  if (utilizations.length === 0) return 100;
  const mean = utilizations.reduce((a, b) => a + b, 0) / utilizations.length;
  if (mean === 0) return 100;
  const variance = utilizations.reduce((acc, u) => acc + (u - mean) ** 2, 0) / utilizations.length;
  const stdDev = Math.sqrt(variance);
  const cv = stdDev / mean;
  return Number(Math.max(0, Math.min(100, (1 - cv) * 100)).toFixed(1));
}

export class AnalyticsService {
  private depts: DepartmentRepository;
  private faculty: FacultyRepository;
  private batches: BatchRepository;
  private subjects: SubjectRepository;
  private rooms: RoomRepository;
  private timeSlots: TimeSlotRepository;
  private timetable: TimetableRepository;

  constructor(db: Database.Database) {
    this.depts = new DepartmentRepository(db);
    this.faculty = new FacultyRepository(db);
    this.batches = new BatchRepository(db);
    this.subjects = new SubjectRepository(db);
    this.rooms = new RoomRepository(db);
    this.timeSlots = new TimeSlotRepository(db);
    this.timetable = new TimetableRepository(db);
  }

  getWorkloadAnalytics() {
    const latestRun = this.timetable.getLatestRun();
    const allocations = latestRun ? this.timetable.getAllocationsByRun(latestRun.id) : [];
    const facultyList = this.faculty.findAll();

    const hoursByFaculty = new Map<number, number>();
    const sessionsByFaculty = new Map<number, number>();
    for (const a of allocations) {
      hoursByFaculty.set(a.facultyId, (hoursByFaculty.get(a.facultyId) ?? 0) + a.durationPeriods);
      sessionsByFaculty.set(a.facultyId, (sessionsByFaculty.get(a.facultyId) ?? 0) + 1);
    }

    const distribution = facultyList.map((f) => {
      const assignedHours = hoursByFaculty.get(f.id) ?? 0;
      const sessions = sessionsByFaculty.get(f.id) ?? 0;
      const utilizationRate = f.maxWeeklyHours > 0 ? Number(((assignedHours / f.maxWeeklyHours) * 100).toFixed(1)) : 0;
      return {
        facultyId: f.id,
        facultyCode: f.facultyCode,
        fullName: f.fullName,
        departmentCode: f.departmentCode,
        assignedHours,
        maxWeeklyHours: f.maxWeeklyHours,
        sessions,
        utilizationRate,
        status:
          assignedHours > f.maxWeeklyHours
            ? 'overloaded'
            : utilizationRate >= 80
              ? 'high'
              : utilizationRate >= 40
                ? 'balanced'
                : 'light',
      };
    });

    const fairnessScore = computeFairnessScore(distribution.map((d) => d.utilizationRate));
    const avgUtilization =
      distribution.length === 0
        ? 0
        : Number(
            (distribution.reduce((acc, d) => acc + d.utilizationRate, 0) / distribution.length).toFixed(1)
          );

    return {
      fairnessScore,
      avgUtilization,
      distribution,
    };
  }

  getRoomUtilizationAnalytics() {
    const latestRun = this.timetable.getLatestRun();
    const allocations = latestRun ? this.timetable.getAllocationsByRun(latestRun.id) : [];
    const rooms = this.rooms.findAll();
    const slots = this.timeSlots.findAll();
    const teachableSlotsPerDay = slots.filter((s) => !s.isLunchBreak).length;
    const totalWeeklyAvailablePeriods = teachableSlotsPerDay * DAYS_OF_WEEK.length;

    const usedByRoom = new Map<number, number>();
    const sessionsByRoom = new Map<number, number>();
    for (const a of allocations) {
      usedByRoom.set(a.roomId, (usedByRoom.get(a.roomId) ?? 0) + a.durationPeriods);
      sessionsByRoom.set(a.roomId, (sessionsByRoom.get(a.roomId) ?? 0) + 1);
    }

    const roomStats = rooms.map((r) => {
      const usedPeriods = usedByRoom.get(r.id) ?? 0;
      const utilizationPct =
        totalWeeklyAvailablePeriods > 0
          ? Number(((usedPeriods / totalWeeklyAvailablePeriods) * 100).toFixed(1))
          : 0;
      return {
        roomId: r.id,
        roomCode: r.roomCode,
        name: r.name,
        roomType: r.roomType,
        capacity: r.capacity,
        isAvailable: r.isAvailable,
        usedPeriods,
        availablePeriods: totalWeeklyAvailablePeriods,
        sessionsCount: sessionsByRoom.get(r.id) ?? 0,
        utilizationPct,
      };
    });

    return {
      totalWeeklyAvailablePeriods,
      rooms: roomStats,
    };
  }

  getSchedulingAnalytics() {
    const latestRun = this.timetable.getLatestRun();
    const runsHistory = this.timetable.listRuns(12);
    const allocations = latestRun ? this.timetable.getAllocationsByRun(latestRun.id) : [];
    const subjects = this.subjects.findAll();
    const faculty = this.faculty.findAll();
    const batches = this.batches.findAll();
    const rooms = this.rooms.findAll();
    const slots = this.timeSlots.findAll();
    const departments = this.depts.findAll();

    const validation = validateTimetable({
      allocations,
      subjects,
      faculty,
      batches,
      rooms,
      timeSlots: slots,
    });

    const dailyDistribution = DAYS_OF_WEEK.map((day) => {
      const dayAllocs = allocations.filter((a) => a.day === day);
      return {
        day,
        meetings: dayAllocs.length,
        periods: dayAllocs.reduce((acc, a) => acc + a.durationPeriods, 0),
        labs: dayAllocs.filter((a) => a.requiredRoomType === 'lab').length,
      };
    });

    const departmentStats = departments.map((d) => {
      const deptSubjects = subjects.filter((s) => s.departmentId === d.id);
      const requiredMeetings = deptSubjects.reduce((acc, s) => acc + s.weeklySessions, 0);
      const scheduledMeetings = allocations.filter((a) => a.departmentCode === d.code).length;
      return {
        departmentId: d.id,
        code: d.code,
        name: d.name,
        subjectCount: deptSubjects.length,
        requiredMeetings,
        scheduledMeetings,
        completionPct:
          requiredMeetings > 0 ? Number(((scheduledMeetings / requiredMeetings) * 100).toFixed(1)) : 100,
      };
    });

    return {
      latestRun,
      runsHistory,
      validationSummary: {
        isHardValid: validation.isValid,
        hardViolationsCount: validation.hardViolations.length,
        hardViolations: validation.hardViolations,
        softMetrics: validation.softMetrics,
      },
      dailyDistribution,
      departmentStats,
    };
  }
}
