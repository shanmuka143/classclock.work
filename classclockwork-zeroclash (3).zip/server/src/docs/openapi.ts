export function getOpenApiSpec(serverOrigin?: string) {
  return {
    openapi: '3.0.3',
    info: {
      title: 'ClassClockwork — ZeroClash Intelligent Timetable API',
      version: '2.0.0',
      description:
        'Three-tier REST API for conflict-free academic timetable scheduling powered by Constraint Satisfaction Problem (CSP) algorithms, SQLite ACID persistence, HttpOnly cookie sessions with double-submit CSRF protection, and role-based access control.',
    },
    servers: [
      {
        url: serverOrigin ? `${serverOrigin}/api` : '/api',
        description: 'Primary API Endpoint',
      },
    ],
    tags: [
      { name: 'System', description: 'Health, OpenAPI specification, integrity checks, backups, and audit logs' },
      { name: 'Auth', description: 'Cookie/JWT authentication, session revocation, and CSRF protection' },
      { name: 'Academic', description: 'Departments, faculty, student batches, rooms, and subjects CRUD' },
      { name: 'Timetable', description: 'CSP solver payload, server/worker scheduling runs, conflict detection, and manual editing' },
      { name: 'Analytics', description: 'Faculty workload fairness, room utilization, and schedule constraint metrics' },
      { name: 'Settings', description: 'Academic term settings and daily period grid configuration' },
    ],
    components: {
      securitySchemes: {
        SessionCookieAuth: {
          type: 'apiKey',
          in: 'cookie',
          name: 'cc_session',
          description: 'HttpOnly SameSite=Lax JWT session cookie backed by server-side user_sessions revocation checks.',
        },
        CsrfTokenHeader: {
          type: 'apiKey',
          in: 'header',
          name: 'X-CSRF-Token',
          description: 'Double-submit CSRF token matching the cc_csrf cookie on state-changing requests.',
        },
        BearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
          description: 'Optional Bearer JWT authentication for programmatic API clients.',
        },
      },
      schemas: {
        ErrorResponse: {
          type: 'object',
          required: ['ok', 'error'],
          properties: {
            ok: { type: 'boolean', example: false },
            error: {
              type: 'object',
              required: ['code', 'message'],
              properties: {
                code: { type: 'string' },
                message: { type: 'string' },
                details: {},
              },
            },
          },
        },
        LoginRequest: {
          type: 'object',
          required: ['username', 'password'],
          properties: {
            username: { type: 'string', minLength: 1, maxLength: 120 },
            password: { type: 'string', minLength: 1, maxLength: 200 },
          },
        },
        AuthUser: {
          type: 'object',
          properties: {
            id: { type: 'integer' },
            username: { type: 'string' },
            email: { type: 'string', format: 'email' },
            fullName: { type: 'string' },
            role: { type: 'string', enum: ['admin', 'coordinator', 'evaluator', 'viewer'] },
          },
        },
        FacultyInput: {
          type: 'object',
          required: ['facultyCode', 'fullName', 'email', 'departmentId', 'maxWeeklyHours', 'availableDays'],
          properties: {
            facultyCode: { type: 'string', minLength: 2, maxLength: 20 },
            fullName: { type: 'string', minLength: 2, maxLength: 120 },
            email: { type: 'string', format: 'email' },
            departmentId: { type: 'integer' },
            maxWeeklyHours: { type: 'integer', minimum: 1, maximum: 45 },
            availableDays: { type: 'array', items: { type: 'string', enum: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'] } },
            preferredHours: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  day: { type: 'string', enum: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'] },
                  periodNumber: { type: 'integer', minimum: 1, maximum: 12 },
                },
              },
            },
            unavailableSlots: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  day: { type: 'string', enum: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'] },
                  periodNumber: { type: 'integer', minimum: 1, maximum: 12 },
                },
              },
            },
          },
        },
        GenerateOptions: {
          type: 'object',
          properties: {
            maxNodes: { type: 'integer', minimum: 100, maximum: 500000 },
            timeoutMs: { type: 'integer', minimum: 500, maximum: 60000 },
            enableForwardChecking: { type: 'boolean' },
            enableLcv: { type: 'boolean' },
            enableMrv: { type: 'boolean' },
            allowPartialFallback: { type: 'boolean' },
            publishImmediately: { type: 'boolean' },
            preserveLocked: { type: 'boolean' },
          },
        },
      },
    },
    security: [{ SessionCookieAuth: [], CsrfTokenHeader: [] }, { BearerAuth: [] }],
    paths: {
      '/health': {
        get: {
          tags: ['System'],
          security: [],
          summary: 'Database and service health check',
          responses: { '200': { description: 'Healthy status and SQLite connectivity' }, '503': { description: 'Database unavailable' } },
        },
      },
      '/openapi.json': {
        get: {
          tags: ['System'],
          security: [],
          summary: 'OpenAPI 3.0.3 JSON specification',
          responses: { '200': { description: 'OpenAPI document' } },
        },
      },
      '/docs': {
        get: {
          tags: ['System'],
          security: [],
          summary: 'Human-readable HTML API reference',
          responses: { '200': { description: 'HTML documentation' } },
        },
      },
      '/auth/login': {
        post: {
          tags: ['Auth'],
          security: [],
          summary: 'Authenticate and issue HttpOnly session + CSRF cookies',
          requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/LoginRequest' } } } },
          responses: { '200': { description: 'Authenticated user and CSRF token' }, '401': { description: 'Invalid credentials' }, '429': { description: 'Rate limited' } },
        },
      },
      '/auth/logout': {
        post: {
          tags: ['Auth'],
          summary: 'Revoke active server-side session and clear cookies',
          responses: { '200': { description: 'Session revoked' }, '401': { description: 'Unauthorized' }, '403': { description: 'Invalid CSRF token' } },
        },
      },
      '/auth/me': {
        get: {
          tags: ['Auth'],
          summary: 'Fetch current authenticated profile',
          responses: { '200': { description: 'Authenticated user profile' }, '401': { description: 'Session missing or revoked' } },
        },
      },
      '/dashboard/stats': {
        get: {
          tags: ['Analytics'],
          summary: 'Aggregated dashboard counts, active run status, and constraint scores',
          responses: { '200': { description: 'Dashboard summary' } },
        },
      },
      '/departments': {
        get: { tags: ['Academic'], summary: 'List departments', responses: { '200': { description: 'Department list' } } },
        post: { tags: ['Academic'], summary: 'Create department (admin only)', responses: { '201': { description: 'Department created' }, '403': { description: 'Admin role required' } } },
      },
      '/faculty': {
        get: {
          tags: ['Academic'],
          summary: 'List faculty members (supports optional ?page=&limit=&departmentId=&search=)',
          parameters: [
            { name: 'departmentId', in: 'query', schema: { type: 'integer' } },
            { name: 'search', in: 'query', schema: { type: 'string' } },
            { name: 'page', in: 'query', schema: { type: 'integer', minimum: 1 } },
            { name: 'limit', in: 'query', schema: { type: 'integer', minimum: 1, maximum: 100 } },
          ],
          responses: { '200': { description: 'Faculty array or paginated envelope' } },
        },
        post: {
          tags: ['Academic'],
          summary: 'Create faculty member (admin, coordinator)',
          requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/FacultyInput' } } } },
          responses: { '201': { description: 'Created' }, '409': { description: 'Duplicate code/email' } },
        },
      },
      '/faculty/{id}': {
        get: { tags: ['Academic'], summary: 'Get faculty by ID', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }], responses: { '200': { description: 'Faculty record' }, '404': { description: 'Not found' } } },
        put: { tags: ['Academic'], summary: 'Update faculty (admin, coordinator)', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }], responses: { '200': { description: 'Updated' } } },
        delete: { tags: ['Academic'], summary: 'Delete or reassign faculty (admin, coordinator)', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }], responses: { '200': { description: 'Deleted' }, '409': { description: 'Has dependent subjects' } } },
      },
      '/subjects': {
        get: { tags: ['Academic'], summary: 'List subjects (supports optional ?page=&limit=&departmentId=&semester=&batchId=&search=)', responses: { '200': { description: 'Subjects list' } } },
        post: { tags: ['Academic'], summary: 'Create subject (admin, coordinator)', responses: { '201': { description: 'Created' } } },
      },
      '/subjects/{id}': {
        put: { tags: ['Academic'], summary: 'Update subject (admin, coordinator)', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }], responses: { '200': { description: 'Updated' } } },
        delete: { tags: ['Academic'], summary: 'Delete subject (admin, coordinator)', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }], responses: { '200': { description: 'Deleted' } } },
      },
      '/batches': {
        get: { tags: ['Academic'], summary: 'List student batches (supports optional ?page=&limit=&departmentId=&search=)', responses: { '200': { description: 'Batches list' } } },
        post: { tags: ['Academic'], summary: 'Create batch (admin, coordinator)', responses: { '201': { description: 'Created' } } },
      },
      '/batches/{id}': {
        put: { tags: ['Academic'], summary: 'Update batch (admin, coordinator)', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }], responses: { '200': { description: 'Updated' } } },
        delete: { tags: ['Academic'], summary: 'Delete batch (admin, coordinator)', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }], responses: { '200': { description: 'Deleted' }, '409': { description: 'Has dependent subjects' } } },
      },
      '/rooms': {
        get: { tags: ['Academic'], summary: 'List rooms and labs (supports optional ?page=&limit=&roomType=&search=)', responses: { '200': { description: 'Rooms list' } } },
        post: { tags: ['Academic'], summary: 'Create room (admin, coordinator)', responses: { '201': { description: 'Created' } } },
      },
      '/rooms/{id}': {
        put: { tags: ['Academic'], summary: 'Update room (admin, coordinator)', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }], responses: { '200': { description: 'Updated' } } },
        delete: { tags: ['Academic'], summary: 'Delete room (admin, coordinator)', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }], responses: { '200': { description: 'Deleted' }, '409': { description: 'Has active allocations' } } },
      },
      '/timetable': {
        get: { tags: ['Timetable'], summary: 'Get active/selected run timetable, allocations, independent validation report, and run history', responses: { '200': { description: 'Timetable data' } } },
      },
      '/timetable/solver-payload': {
        get: { tags: ['Timetable'], summary: 'Fetch normalized CSP solver input dataset for Web Worker execution', responses: { '200': { description: 'CSP payload' } } },
      },
      '/timetable/generate': {
        post: { tags: ['Timetable'], summary: 'Run CSP solver directly on server and persist result (admin, coordinator)', requestBody: { content: { 'application/json': { schema: { $ref: '#/components/schemas/GenerateOptions' } } } }, responses: { '201': { description: 'Run saved' } } },
      },
      '/timetable/save-generated': {
        post: { tags: ['Timetable'], summary: 'Verify Web Worker CSP result independently on server and persist transactionally (admin, coordinator)', responses: { '201': { description: 'Verified and saved' }, '409': { description: 'Hard constraint violation rejected' } } },
      },
      '/timetable/validate': {
        post: { tags: ['Timetable'], summary: 'Dry-run validation of current or proposed allocation move', responses: { '200': { description: 'Validation report' } } },
      },
      '/timetable/publish': {
        post: { tags: ['Timetable'], summary: 'Mark a historical scheduling run as the active published timetable (admin, coordinator)', responses: { '200': { description: 'Published' } } },
      },
      '/timetable/{id}': {
        put: { tags: ['Timetable'], summary: 'Move/lock allocation after hard-conflict validation (admin, coordinator)', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }], responses: { '200': { description: 'Updated' }, '409': { description: 'Schedule conflict' } } },
        delete: { tags: ['Timetable'], summary: 'Remove allocation and recompute run metrics (admin, coordinator)', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }], responses: { '200': { description: 'Deleted' } } },
      },
      '/analytics/workload': { get: { tags: ['Analytics'], summary: 'Faculty teaching hours and CV-based fairness score', responses: { '200': { description: 'Workload analytics' } } } },
      '/analytics/room-utilization': { get: { tags: ['Analytics'], summary: 'Room utilization rates across weekly periods', responses: { '200': { description: 'Room analytics' } } } },
      '/analytics/scheduling': { get: { tags: ['Analytics'], summary: 'Latest run validation, daily distribution, and department completion', responses: { '200': { description: 'Scheduling analytics' } } } },
      '/settings': {
        get: { tags: ['Settings'], summary: 'Get institution term settings, time slots, and departments', responses: { '200': { description: 'Settings bundle' } } },
        put: { tags: ['Settings'], summary: 'Update institution term & solver defaults (admin only)', responses: { '200': { description: 'Updated settings' } } },
      },
      '/settings/time-slots': {
        put: { tags: ['Settings'], summary: 'Replace daily time slot structure (admin only)', responses: { '200': { description: 'Updated slots' } } },
      },
      '/audit-logs': {
        get: { tags: ['System'], summary: 'Paginated security and administrative audit logs (admin only)', responses: { '200': { description: 'Audit logs page' }, '403': { description: 'Admin role required' } } },
      },
      '/system/integrity': {
        get: { tags: ['System'], summary: 'Run SQLite PRAGMA integrity_check and foreign_key_check (admin only)', responses: { '200': { description: 'Integrity report' } } },
      },
      '/system/backup': {
        post: { tags: ['System'], summary: 'Create online SQLite backup and verify backup integrity (admin only)', responses: { '201': { description: 'Verified backup created' } } },
      },
    },
  };
}

export function renderOpenApiHtml(specUrl = '/api/openapi.json'): string {
  const spec = getOpenApiSpec();
  const rows = Object.entries(spec.paths)
    .flatMap(([routePath, methods]) =>
      Object.entries(methods).map(([method, op]) => ({
        method: method.toUpperCase(),
        path: `/api${routePath}`,
        tag: (op as { tags?: string[] }).tags?.[0] ?? 'General',
        summary: (op as { summary?: string }).summary ?? '',
      }))
    );

  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>ClassClockwork ZeroClash — API Reference</title>
  <style>
    body { font-family: system-ui, -apple-system, sans-serif; background: #f8fafc; color: #0f172a; margin: 0; padding: 2rem; line-height: 1.5; }
    main { max-width: 980px; margin: 0 auto; background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 2rem; }
    h1 { margin: 0 0 0.5rem; font-size: 1.5rem; }
    p.meta { color: #475569; margin: 0 0 1.5rem; }
    .spec-link { display: inline-block; margin-bottom: 1.5rem; padding: 0.45rem 0.9rem; background: #1e293b; color: #fff; text-decoration: none; border-radius: 6px; font-size: 0.875rem; font-weight: 600; }
    table { width: 100%; border-collapse: collapse; font-size: 0.875rem; }
    th, td { text-align: left; padding: 0.65rem 0.75rem; border-bottom: 1px solid #e2e8f0; vertical-align: top; }
    th { background: #f1f5f9; font-weight: 600; color: #334155; }
    code { font-family: ui-monospace, SFMono-Regular, monospace; font-size: 0.82rem; background: #f1f5f9; padding: 0.15rem 0.35rem; border-radius: 4px; }
    .m { font-weight: 700; font-size: 0.75rem; padding: 0.2rem 0.45rem; border-radius: 4px; display: inline-block; min-width: 52px; text-align: center; }
    .GET { background: #e0f2fe; color: #0369a1; }
    .POST { background: #dcfce7; color: #15803d; }
    .PUT { background: #fef3c7; color: #b45309; }
    .DELETE { background: #fee2e2; color: #b91c1c; }
  </style>
</head>
<body>
  <main>
    <h1>${spec.info.title}</h1>
    <p class="meta">Version ${spec.info.version} — ${spec.info.description}</p>
    <a class="spec-link" href="${specUrl}">Download OpenAPI 3.0.3 JSON</a>
    <table>
      <thead>
        <tr>
          <th>Method</th>
          <th>Endpoint</th>
          <th>Group</th>
          <th>Description</th>
        </tr>
      </thead>
      <tbody>
        ${rows
          .map(
            (r) =>
              `<tr><td><span class="m ${r.method}">${r.method}</span></td><td><code>${r.path}</code></td><td>${r.tag}</td><td>${r.summary}</td></tr>`
          )
          .join('')}
      </tbody>
    </table>
  </main>
</body>
</html>`;
}
