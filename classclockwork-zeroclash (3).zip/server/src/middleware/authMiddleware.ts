import crypto from 'node:crypto';
import type Database from 'better-sqlite3';
import type { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { config } from '../config/env.ts';
import { SessionRepository } from '../database/repositories/sessionRepository.ts';
import { UserRepository } from '../database/repositories/userRepository.ts';
import { AuditService } from '../services/auditService.ts';
import { AppError } from './errorHandler.ts';

export const SESSION_COOKIE_NAME = 'cc_session';
export const CSRF_COOKIE_NAME = 'cc_csrf';
export const CSRF_HEADER_NAME = 'x-csrf-token';

export interface AuthUser {
  id: number;
  username: string;
  email: string;
  fullName: string;
  role: 'admin' | 'coordinator' | 'evaluator' | 'viewer';
  jti?: string;
}

export interface AuthenticatedRequest extends Request {
  user?: AuthUser;
  authSource?: 'cookie' | 'bearer';
}

export function parseCookies(cookieHeader?: string): Record<string, string> {
  const result: Record<string, string> = {};
  if (!cookieHeader) return result;
  const pairs = cookieHeader.split(';');
  for (const pair of pairs) {
    const idx = pair.indexOf('=');
    if (idx <= 0) continue;
    const key = pair.slice(0, idx).trim();
    const rawVal = pair.slice(idx + 1).trim();
    if (!key) continue;
    try {
      result[key] = decodeURIComponent(rawVal);
    } catch {
      result[key] = rawVal;
    }
  }
  return result;
}

export function extractBearerToken(req: Request): string | null {
  const header = req.headers.authorization;
  if (!header) return null;
  const parts = header.split(' ');
  if (parts.length !== 2 || parts[0].toLowerCase() !== 'bearer') return null;
  return parts[1].trim() || null;
}

function timingSafeMatch(a: string, b: string): boolean {
  const bufA = Buffer.from(a, 'utf8');
  const bufB = Buffer.from(b, 'utf8');
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

const MUTATING_METHODS = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);

export function requireAuth(req: AuthenticatedRequest, _res: Response, next: NextFunction): void {
  const cookies = parseCookies(req.headers.cookie);
  const cookieToken = cookies[SESSION_COOKIE_NAME] ?? null;
  const bearerToken = extractBearerToken(req);

  const token = cookieToken || bearerToken;
  const source: 'cookie' | 'bearer' | null = cookieToken ? 'cookie' : bearerToken ? 'bearer' : null;

  if (!token || !source) {
    next(new AppError(401, 'UNAUTHORIZED', 'Authentication session is required.'));
    return;
  }

  let decoded: AuthUser;
  try {
    decoded = jwt.verify(token, config.jwtSecret) as AuthUser;
  } catch {
    next(new AppError(401, 'TOKEN_INVALID', 'Session has expired or token is invalid.'));
    return;
  }

  const db = req.app.locals.db as Database.Database | undefined;
  if (db) {
    // Enforce server-side session revocation check when jti is present (mandatory for all issued sessions)
    if (!decoded.jti) {
      next(new AppError(401, 'SESSION_INVALID', 'Session identifier missing or invalid.'));
      return;
    }
    const sessionRepo = new SessionRepository(db);
    if (!sessionRepo.isSessionActive(decoded.jti, decoded.id)) {
      next(new AppError(401, 'SESSION_REVOKED', 'Session has been revoked or expired.'));
      return;
    }

    const userRepo = new UserRepository(db);
    const activeUser = userRepo.findById(decoded.id);
    if (!activeUser) {
      next(new AppError(401, 'USER_INACTIVE', 'Authenticated user account no longer exists.'));
      return;
    }

    req.user = {
      id: activeUser.id,
      username: activeUser.username,
      email: activeUser.email,
      fullName: activeUser.full_name,
      role: activeUser.role,
      jti: decoded.jti,
    };
  } else {
    req.user = {
      id: decoded.id,
      username: decoded.username,
      email: decoded.email,
      fullName: decoded.fullName,
      role: decoded.role,
      jti: decoded.jti,
    };
  }

  req.authSource = source;

  // Enforce double-submit CSRF protection for cookie-authenticated state-changing requests
  if (source === 'cookie' && MUTATING_METHODS.has(req.method.toUpperCase())) {
    const csrfCookie = cookies[CSRF_COOKIE_NAME];
    const headerRaw = req.headers[CSRF_HEADER_NAME];
    const csrfHeader = Array.isArray(headerRaw) ? headerRaw[0] : headerRaw;

    if (!csrfCookie || !csrfHeader || !timingSafeMatch(csrfCookie, csrfHeader)) {
      if (db && req.user) {
        new AuditService(db).log({
          actorUserId: req.user.id,
          actorUsername: req.user.username,
          action: 'CSRF_VALIDATION_FAILED',
          entityType: 'security',
          status: 'denied',
          details: { method: req.method, path: req.originalUrl },
          ipAddress: req.ip,
        });
      }
      next(new AppError(403, 'CSRF_INVALID', 'Invalid or missing CSRF verification token.'));
      return;
    }
  }

  next();
}

export function requireRole(...roles: Array<AuthUser['role']>) {
  return (req: AuthenticatedRequest, _res: Response, next: NextFunction): void => {
    if (!req.user) {
      next(new AppError(401, 'UNAUTHORIZED', 'Authentication is required.'));
      return;
    }
    if (!roles.includes(req.user.role)) {
      const db = req.app.locals.db as Database.Database | undefined;
      if (db) {
        new AuditService(db).log({
          actorUserId: req.user.id,
          actorUsername: req.user.username,
          action: 'RBAC_ACCESS_DENIED',
          entityType: 'authorization',
          status: 'denied',
          details: {
            requiredRoles: roles,
            actualRole: req.user.role,
            method: req.method,
            path: req.originalUrl,
          },
          ipAddress: req.ip,
        });
      }
      next(new AppError(403, 'FORBIDDEN', 'You do not have permission to perform this action.'));
      return;
    }
    next();
  };
}
