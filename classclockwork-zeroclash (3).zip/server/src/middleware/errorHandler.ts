import type { NextFunction, Request, Response } from 'express';
import { ZodError } from 'zod';
import { logger } from '../config/logger.ts';

export class AppError extends Error {
  statusCode: number;
  code: string;
  details?: unknown;

  constructor(statusCode: number, code: string, message: string, details?: unknown) {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
  }
}

export function notFoundHandler(req: Request, res: Response): void {
  res.status(404).json({
    ok: false,
    error: {
      code: 'NOT_FOUND',
      message: `Route ${req.method} ${req.originalUrl} was not found.`,
    },
  });
}

export function errorHandler(
  err: unknown,
  req: Request,
  res: Response,
  _next: NextFunction
): void {
  if (err instanceof AppError) {
    res.status(err.statusCode).json({
      ok: false,
      error: {
        code: err.code,
        message: err.message,
        ...(err.details !== undefined ? { details: err.details } : {}),
      },
    });
    return;
  }

  if (err instanceof ZodError) {
    res.status(400).json({
      ok: false,
      error: {
        code: 'VALIDATION_ERROR',
        message: err.issues.map((i) => `${i.path.join('.') || 'input'}: ${i.message}`).join('; '),
        details: err.issues,
      },
    });
    return;
  }

  const sqliteCode = (err as { code?: string })?.code;
  if (sqliteCode === 'SQLITE_CONSTRAINT_UNIQUE') {
    res.status(409).json({
      ok: false,
      error: {
        code: 'DUPLICATE_RECORD',
        message: 'A record with the same unique code, email, or name already exists.',
      },
    });
    return;
  }
  if (sqliteCode === 'SQLITE_CONSTRAINT_FOREIGNKEY') {
    res.status(409).json({
      ok: false,
      error: {
        code: 'FOREIGN_KEY_CONFLICT',
        message: 'Referenced academic entity does not exist or has dependent records.',
      },
    });
    return;
  }
  if (sqliteCode === 'SQLITE_CONSTRAINT_CHECK') {
    res.status(400).json({
      ok: false,
      error: {
        code: 'CONSTRAINT_VIOLATION',
        message: 'Input value violates database integrity bounds.',
      },
    });
    return;
  }

  logger.error('Unhandled server error', {
    method: req.method,
    url: req.originalUrl,
    error: err instanceof Error ? err.message : String(err),
  });

  res.status(500).json({
    ok: false,
    error: {
      code: 'INTERNAL_SERVER_ERROR',
      message: 'An unexpected server error occurred.',
    },
  });
}
