import rateLimit from 'express-rate-limit';

export const authRateLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  skip: () => process.env.NODE_ENV === 'test',
  message: {
    ok: false,
    error: {
      code: 'RATE_LIMITED',
      message: 'Too many authentication attempts. Please wait a minute and try again.',
    },
  },
});

export const solverRateLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 25,
  standardHeaders: true,
  legacyHeaders: false,
  skip: () => process.env.NODE_ENV === 'test',
  message: {
    ok: false,
    error: {
      code: 'RATE_LIMITED',
      message: 'Scheduling rate limit exceeded. Please wait briefly before starting another run.',
    },
  },
});
