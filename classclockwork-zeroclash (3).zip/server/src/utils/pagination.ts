import type { Request, Response } from 'express';

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export function sendListOrPaginated<T>(req: Request, res: Response, items: T[]): void {
  res.setHeader('X-Total-Count', String(items.length));

  const hasPageParam = req.query.page !== undefined || req.query.limit !== undefined;
  if (!hasPageParam) {
    res.status(200).json({ ok: true, data: items });
    return;
  }

  const rawPage = Number(req.query.page ?? 1);
  const rawLimit = Number(req.query.limit ?? 20);
  const limit = Number.isFinite(rawLimit) ? Math.min(100, Math.max(1, Math.trunc(rawLimit))) : 20;
  const total = items.length;
  const totalPages = Math.max(1, Math.ceil(total / limit));
  const page = Number.isFinite(rawPage) ? Math.min(totalPages, Math.max(1, Math.trunc(rawPage))) : 1;
  const offset = (page - 1) * limit;

  const data: PaginatedResponse<T> = {
    items: items.slice(offset, offset + limit),
    total,
    page,
    limit,
    totalPages,
  };

  res.status(200).json({ ok: true, data });
}
