import { z } from 'zod';

const daySchema = z.enum(['Mon', 'Tue', 'Wed', 'Thu', 'Fri']);
const roomTypeSchema = z.enum(['lecture', 'lab', 'seminar']);

export const loginSchema = z.object({
  username: z.string().trim().min(1, 'Username or email is required').max(120),
  password: z.string().min(1, 'Password is required').max(200),
});

export const createDepartmentSchema = z.object({
  code: z.string().trim().min(2).max(12).regex(/^[A-Za-z0-9_-]+$/, 'Invalid department code'),
  name: z.string().trim().min(2).max(120),
  headName: z.string().trim().max(120).optional().nullable(),
});

const slotRefSchema = z.object({
  day: daySchema,
  periodNumber: z.number().int().min(1).max(12),
});

const facultyBaseSchema = z.object({
  facultyCode: z.string().trim().min(2).max(20),
  fullName: z.string().trim().min(2).max(120),
  email: z.string().trim().email('Valid institutional email is required').max(160),
  departmentId: z.number().int().positive(),
  maxWeeklyHours: z.number().int().min(1).max(45),
  availableDays: z.array(daySchema).min(1, 'Select at least one available day'),
  preferredHours: z.array(slotRefSchema),
  unavailableSlots: z.array(slotRefSchema),
});

export const createFacultySchema = facultyBaseSchema.extend({
  preferredHours: z.array(slotRefSchema).default([]),
  unavailableSlots: z.array(slotRefSchema).default([]),
});

export const updateFacultySchema = facultyBaseSchema.partial();

export const createBatchSchema = z.object({
  batchCode: z.string().trim().min(2).max(24),
  name: z.string().trim().min(2).max(120),
  departmentId: z.number().int().positive(),
  semester: z.number().int().min(1).max(10),
  studentStrength: z.number().int().min(1).max(500),
});

export const updateBatchSchema = createBatchSchema.partial();

const roomBaseSchema = z.object({
  roomCode: z.string().trim().min(2).max(24),
  name: z.string().trim().min(2).max(120),
  roomType: roomTypeSchema,
  capacity: z.number().int().min(1).max(600),
  equipment: z.array(z.string().trim().min(1).max(60)),
  isAvailable: z.boolean(),
});

export const createRoomSchema = roomBaseSchema.extend({
  equipment: z.array(z.string().trim().min(1).max(60)).default([]),
  isAvailable: z.boolean().default(true),
});

export const updateRoomSchema = roomBaseSchema.partial();

const subjectBaseSchema = z.object({
  subjectCode: z.string().trim().min(2).max(24),
  name: z.string().trim().min(2).max(150),
  departmentId: z.number().int().positive(),
  semester: z.number().int().min(1).max(10),
  batchId: z.number().int().positive(),
  facultyId: z.number().int().positive().nullable(),
  weeklySessions: z.number().int().min(1).max(12),
  sessionDuration: z.number().int().min(1).max(4),
  studentCount: z.number().int().min(1).max(500),
  requiredRoomType: roomTypeSchema,
  requiredEquipment: z.array(z.string().trim().min(1).max(60)),
  credits: z.number().int().min(1).max(10),
  colorHex: z.string().regex(/^#[0-9a-fA-F]{6}$/).optional(),
});

export const createSubjectSchema = subjectBaseSchema.extend({
  sessionDuration: z.number().int().min(1).max(4).default(1),
  requiredEquipment: z.array(z.string().trim().min(1).max(60)).default([]),
  credits: z.number().int().min(1).max(10).default(3),
});

export const updateSubjectSchema = subjectBaseSchema.partial();

export const generateTimetableSchema = z.object({
  maxNodes: z.number().int().min(100).max(500000).optional(),
  timeoutMs: z.number().int().min(500).max(60000).optional(),
  enableForwardChecking: z.boolean().optional(),
  enableLcv: z.boolean().optional(),
  enableMrv: z.boolean().optional(),
  allowPartialFallback: z.boolean().optional(),
  publishImmediately: z.boolean().optional(),
  preserveLocked: z.boolean().optional(),
});

export const saveWorkerResultSchema = z.object({
  status: z.enum(['optimal', 'feasible', 'partial', 'infeasible', 'timeout', 'cancelled']),
  totalMeetings: z.number().int().min(0),
  scheduledMeetings: z.number().int().min(0),
  unscheduledMeetings: z.array(
    z.object({
      variableId: z.string(),
      subjectId: z.number().int().positive(),
      subjectCode: z.string(),
      subjectName: z.string(),
      batchId: z.number().int().positive(),
      facultyId: z.number().int().nullable(),
      sessionIndex: z.number().int().positive(),
      duration: z.number().int().positive(),
      reason: z.string(),
    })
  ),
  nodesExplored: z.number().int().min(0),
  durationMs: z.number().int().min(0),
  publishImmediately: z.boolean().default(true),
  config: z.record(z.string(), z.unknown()).default({}),
  allocations: z.array(
    z.object({
      subjectId: z.number().int().positive(),
      facultyId: z.number().int().positive(),
      batchId: z.number().int().positive(),
      roomId: z.number().int().positive(),
      day: daySchema,
      startPeriod: z.number().int().min(1).max(12),
      durationPeriods: z.number().int().min(1).max(4),
      sessionIndex: z.number().int().min(1).max(12),
    })
  ),
});

export const updateAllocationSchema = z.object({
  day: daySchema.optional(),
  startPeriod: z.number().int().min(1).max(12).optional(),
  roomId: z.number().int().positive().optional(),
  isLocked: z.boolean().optional(),
});

export const validateAllocationChangeSchema = z.object({
  runId: z.number().int().positive().optional(),
  allocationId: z.number().int().positive().optional(),
  day: daySchema.optional(),
  startPeriod: z.number().int().min(1).max(12).optional(),
  roomId: z.number().int().positive().optional(),
});

export const publishRunSchema = z.object({
  runId: z.number().int().positive(),
});

export const updateTimeSlotsSchema = z.object({
  slots: z
    .array(
      z.object({
        periodNumber: z.number().int().min(1).max(12),
        label: z.string().trim().min(1).max(40),
        startTime: z.string().regex(/^\d{2}:\d{2}$/),
        endTime: z.string().regex(/^\d{2}:\d{2}$/),
        isLunchBreak: z.boolean(),
      })
    )
    .min(4)
    .max(12),
});

export const updateSettingsSchema = z.object({
  institutionName: z.string().trim().min(2).max(120).optional(),
  academicYear: z.string().trim().min(4).max(40).optional(),
  semesterLabel: z.string().trim().min(2).max(60).optional(),
  defaultSolverMaxNodes: z.number().int().min(1000).max(500000).optional(),
  defaultSolverTimeoutMs: z.number().int().min(1000).max(60000).optional(),
});
