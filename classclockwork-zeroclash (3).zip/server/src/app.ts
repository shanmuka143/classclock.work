import type Database from 'better-sqlite3';
import cors from 'cors';
import express from 'express';
import helmet from 'helmet';
import { config } from './config/env.ts';
import { AppError, errorHandler, notFoundHandler } from './middleware/errorHandler.ts';
import { createApiRouter } from './routes/index.ts';

export function createApp(db: Database.Database): express.Express {
  const app = express();

  app.locals.db = db;
  app.set('trust proxy', 1);

  const isProd = config.nodeEnv === 'production';

  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: isProd ? ["'self'"] : ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
          styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
          fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'],
          imgSrc: ["'self'", 'data:', 'blob:'],
          workerSrc: ["'self'", 'blob:'],
          connectSrc: isProd ? ["'self'"] : ["'self'", 'ws:', 'wss:'],
          objectSrc: ["'none'"],
          baseUri: ["'self'"],
          formAction: ["'self'"],
          frameAncestors: ["'self'", 'https://aistudio.google.com', 'https://*.google.com'],
          upgradeInsecureRequests: null,
        },
      },
      crossOriginEmbedderPolicy: false,
      frameguard: false,
      referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
    })
  );

  const allowedOrigins = new Set(config.corsOrigins);

  app.use(
    cors((req, callback) => {
      const origin = req.headers.origin;
      if (!origin) {
        callback(null, { origin: true, credentials: true });
        return;
      }

      const host = req.headers.host;
      const sameHostHttp = host ? `http://${host}` : '';
      const sameHostHttps = host ? `https://${host}` : '';
      const isSameHost = origin === sameHostHttp || origin === sameHostHttps;

      if (allowedOrigins.has(origin) || isSameHost) {
        callback(null, { origin: true, credentials: true });
        return;
      }

      if (!isProd && (origin.startsWith('http://localhost:') || origin.startsWith('http://127.0.0.1:'))) {
        callback(null, { origin: true, credentials: true });
        return;
      }

      callback(
        new AppError(403, 'CORS_ORIGIN_DENIED', 'Origin is not permitted by CORS policy.') as unknown as Error,
        { origin: false }
      );
    })
  );

  app.use(express.json({ limit: '2mb' }));
  app.use(express.urlencoded({ extended: false }));

  app.use('/api', createApiRouter(db));
  app.use('/api/*', notFoundHandler);
  app.use(errorHandler);

  return app;
}
