import type Database from 'better-sqlite3';

export interface AcademicTermSettings {
  institutionName: string;
  academicYear: string;
  semesterLabel: string;
  workingDays: string[];
  defaultSolverMaxNodes: number;
  defaultSolverTimeoutMs: number;
}

const DEFAULT_SETTINGS: AcademicTermSettings = {
  institutionName: 'Westbridge Institute of Technology',
  academicYear: '2026–2027',
  semesterLabel: 'Fall Semester',
  workingDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
  defaultSolverMaxNodes: 150000,
  defaultSolverTimeoutMs: 12000,
};

export class SettingsRepository {
  private db: Database.Database;
  constructor(db: Database.Database) {
    this.db = db;
  }

  getAcademicTerm(): AcademicTermSettings {
    const row = this.db
      .prepare('SELECT value_json FROM institution_settings WHERE key = ?')
      .get('academic_term') as { value_json: string } | undefined;
    if (!row) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...(JSON.parse(row.value_json) as Partial<AcademicTermSettings>) };
  }

  updateAcademicTerm(settings: Partial<AcademicTermSettings>): AcademicTermSettings {
    const merged = { ...this.getAcademicTerm(), ...settings };
    this.db
      .prepare(
        `INSERT INTO institution_settings (key, value_json, updated_at)
         VALUES ('academic_term', ?, datetime('now'))
         ON CONFLICT(key) DO UPDATE SET value_json = excluded.value_json, updated_at = datetime('now')`
      )
      .run(JSON.stringify(merged));
    return merged;
  }
}
