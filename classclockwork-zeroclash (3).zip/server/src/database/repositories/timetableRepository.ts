import type Database from 'better-sqlite3';
import type { CspAllocation, DayOfWeek, UnscheduledMeeting } from '../../../../shared/csp/types.ts';

export interface SchedulingRunRecord {
  id: number;
  status: 'optimal' | 'feasible' | 'partial' | 'infeasible' | 'timeout' | 'cancelled' | 'manual';
  isPublished: boolean;
  totalMeetings: number;
  scheduledMeetings: number;
  unscheduledMeetings: number;
  hardConflictsCount: number;
  optimizationScore: number;
  nodesExplored: number;
  durationMs: number;
  config: Record<string, unknown>;
  unscheduledList: UnscheduledMeeting[];
  createdBy: number | null;
  createdAt: string;
}

export interface TimetableAllocationRecord extends CspAllocation {
  id: number;
  runId: number;
  isLocked: boolean;
  subjectCode: string;
  subjectName: string;
  colorHex: string;
  requiredRoomType: string;
  facultyName: string;
  facultyCode: string;
  batchCode: string;
  batchName: string;
  roomCode: string;
  roomName: string;
  departmentCode: string;
  createdAt: string;
}

export class TimetableRepository {
  private db: Database.Database;
  constructor(db: Database.Database) {
    this.db = db;
  }

  getLatestRun(): SchedulingRunRecord | undefined {
    const r = this.db
      .prepare('SELECT * FROM scheduling_runs ORDER BY is_published DESC, id DESC LIMIT 1')
      .get() as Record<string, unknown> | undefined;
    return r ? this.mapRun(r) : undefined;
  }

  getRunById(runId: number): SchedulingRunRecord | undefined {
    const r = this.db
      .prepare('SELECT * FROM scheduling_runs WHERE id = ?')
      .get(runId) as Record<string, unknown> | undefined;
    return r ? this.mapRun(r) : undefined;
  }

  listRuns(limit = 20): SchedulingRunRecord[] {
    const rows = this.db
      .prepare('SELECT * FROM scheduling_runs ORDER BY id DESC LIMIT ?')
      .all(limit) as Array<Record<string, unknown>>;
    return rows.map((r) => this.mapRun(r));
  }

  getAllocationsByRun(runId: number): TimetableAllocationRecord[] {
    const rows = this.db
      .prepare(`
        SELECT ta.*,
          s.subject_code, s.name AS subject_name, s.color_hex, s.required_room_type,
          f.full_name AS faculty_name, f.faculty_code,
          b.batch_code, b.name AS batch_name,
          r.room_code, r.name AS room_name,
          d.code AS department_code
        FROM timetable_allocations ta
        JOIN subjects s ON s.id = ta.subject_id
        JOIN faculty f ON f.id = ta.faculty_id
        JOIN batches b ON b.id = ta.batch_id
        JOIN rooms r ON r.id = ta.room_id
        JOIN departments d ON d.id = s.department_id
        WHERE ta.run_id = ?
        ORDER BY ta.day_of_week ASC, ta.start_period ASC, b.batch_code ASC
      `)
      .all(runId) as Array<Record<string, unknown>>;

    return rows.map((r) => this.mapAllocation(r));
  }

  getAllocationById(id: number): TimetableAllocationRecord | undefined {
    const r = this.db
      .prepare(`
        SELECT ta.*,
          s.subject_code, s.name AS subject_name, s.color_hex, s.required_room_type,
          f.full_name AS faculty_name, f.faculty_code,
          b.batch_code, b.name AS batch_name,
          r.room_code, r.name AS room_name,
          d.code AS department_code
        FROM timetable_allocations ta
        JOIN subjects s ON s.id = ta.subject_id
        JOIN faculty f ON f.id = ta.faculty_id
        JOIN batches b ON b.id = ta.batch_id
        JOIN rooms r ON r.id = ta.room_id
        JOIN departments d ON d.id = s.department_id
        WHERE ta.id = ?
      `)
      .get(id) as Record<string, unknown> | undefined;

    return r ? this.mapAllocation(r) : undefined;
  }

  saveGeneratedRun(params: {
    status: SchedulingRunRecord['status'];
    publishImmediately: boolean;
    totalMeetings: number;
    scheduledMeetings: number;
    unscheduledList: UnscheduledMeeting[];
    hardConflictsCount: number;
    optimizationScore: number;
    nodesExplored: number;
    durationMs: number;
    config: Record<string, unknown>;
    allocations: CspAllocation[];
    logs: Array<{ level: 'info' | 'warn' | 'error'; message: string }>;
    createdBy: number | null;
  }): SchedulingRunRecord {
    const tx = this.db.transaction(() => {
      if (params.publishImmediately) {
        this.db.prepare('UPDATE scheduling_runs SET is_published = 0').run();
      }

      const runInfo = this.db
        .prepare(
          `INSERT INTO scheduling_runs (
            status, is_published, total_meetings, scheduled_meetings, unscheduled_meetings,
            hard_conflicts_count, optimization_score, nodes_explored, duration_ms, config_json, unscheduled_json, created_by
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          params.status,
          params.publishImmediately ? 1 : 0,
          params.totalMeetings,
          params.scheduledMeetings,
          params.unscheduledList.length,
          params.hardConflictsCount,
          params.optimizationScore,
          params.nodesExplored,
          params.durationMs,
          JSON.stringify(params.config),
          JSON.stringify(params.unscheduledList),
          params.createdBy
        );

      const runId = Number(runInfo.lastInsertRowid);
      const insAlloc = this.db.prepare(
        `INSERT INTO timetable_allocations (
          run_id, subject_id, faculty_id, batch_id, room_id, day_of_week, start_period, duration_periods, session_index
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
      );
      for (const a of params.allocations) {
        insAlloc.run(
          runId,
          a.subjectId,
          a.facultyId,
          a.batchId,
          a.roomId,
          a.day,
          a.startPeriod,
          a.durationPeriods,
          a.sessionIndex
        );
      }

      const insLog = this.db.prepare(
        'INSERT INTO scheduling_logs (run_id, level, message) VALUES (?, ?, ?)'
      );
      for (const log of params.logs) {
        insLog.run(runId, log.level, log.message);
      }

      return runId;
    });

    const newRunId = tx();
    return this.getRunById(newRunId)!;
  }

  updateAllocation(
    id: number,
    patch: { day?: DayOfWeek; startPeriod?: number; roomId?: number; isLocked?: boolean }
  ): TimetableAllocationRecord | undefined {
    const existing = this.getAllocationById(id);
    if (!existing) return undefined;

    this.db
      .prepare(
        `UPDATE timetable_allocations
         SET day_of_week = ?, start_period = ?, room_id = ?, is_locked = ?
         WHERE id = ?`
      )
      .run(
        patch.day ?? existing.day,
        patch.startPeriod ?? existing.startPeriod,
        patch.roomId ?? existing.roomId,
        patch.isLocked !== undefined ? (patch.isLocked ? 1 : 0) : existing.isLocked ? 1 : 0,
        id
      );

    return this.getAllocationById(id);
  }

  deleteAllocation(id: number): boolean {
    const res = this.db.prepare('DELETE FROM timetable_allocations WHERE id = ?').run(id);
    return res.changes > 0;
  }

  updateRunStats(runId: number, stats: { hardConflictsCount: number; optimizationScore: number; scheduledMeetings: number }): void {
    this.db
      .prepare(
        'UPDATE scheduling_runs SET hard_conflicts_count = ?, optimization_score = ?, scheduled_meetings = ? WHERE id = ?'
      )
      .run(stats.hardConflictsCount, stats.optimizationScore, stats.scheduledMeetings, runId);
  }

  publishRun(runId: number): SchedulingRunRecord | undefined {
    const run = this.getRunById(runId);
    if (!run) return undefined;

    const tx = this.db.transaction(() => {
      this.db.prepare('UPDATE scheduling_runs SET is_published = 0').run();
      this.db.prepare('UPDATE scheduling_runs SET is_published = 1 WHERE id = ?').run(runId);
    });
    tx();
    return this.getRunById(runId);
  }

  getLogsForRun(runId: number): Array<{ id: number; level: string; message: string; createdAt: string }> {
    const rows = this.db
      .prepare('SELECT id, level, message, created_at FROM scheduling_logs WHERE run_id = ? ORDER BY id DESC LIMIT 50')
      .all(runId) as Array<Record<string, unknown>>;
    return rows.map((r) => ({
      id: Number(r.id),
      level: String(r.level),
      message: String(r.message),
      createdAt: String(r.created_at),
    }));
  }

  private mapRun(r: Record<string, unknown>): SchedulingRunRecord {
    return {
      id: Number(r.id),
      status: r.status as SchedulingRunRecord['status'],
      isPublished: Boolean(r.is_published),
      totalMeetings: Number(r.total_meetings),
      scheduledMeetings: Number(r.scheduled_meetings),
      unscheduledMeetings: Number(r.unscheduled_meetings),
      hardConflictsCount: Number(r.hard_conflicts_count),
      optimizationScore: Number(r.optimization_score),
      nodesExplored: Number(r.nodes_explored),
      durationMs: Number(r.duration_ms),
      config: JSON.parse(String(r.config_json ?? '{}')) as Record<string, unknown>,
      unscheduledList: JSON.parse(String(r.unscheduled_json ?? '[]')) as UnscheduledMeeting[],
      createdBy: r.created_by === null ? null : Number(r.created_by),
      createdAt: String(r.created_at),
    };
  }

  private mapAllocation(r: Record<string, unknown>): TimetableAllocationRecord {
    return {
      id: Number(r.id),
      runId: Number(r.run_id),
      subjectId: Number(r.subject_id),
      facultyId: Number(r.faculty_id),
      batchId: Number(r.batch_id),
      roomId: Number(r.room_id),
      day: r.day_of_week as DayOfWeek,
      startPeriod: Number(r.start_period),
      durationPeriods: Number(r.duration_periods),
      sessionIndex: Number(r.session_index),
      isLocked: Boolean(r.is_locked),
      subjectCode: String(r.subject_code),
      subjectName: String(r.subject_name),
      colorHex: String(r.color_hex),
      requiredRoomType: String(r.required_room_type),
      facultyName: String(r.faculty_name),
      facultyCode: String(r.faculty_code),
      batchCode: String(r.batch_code),
      batchName: String(r.batch_name),
      roomCode: String(r.room_code),
      roomName: String(r.room_name),
      departmentCode: String(r.department_code),
      createdAt: String(r.created_at),
    };
  }
}
