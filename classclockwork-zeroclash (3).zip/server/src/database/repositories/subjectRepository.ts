import type Database from 'better-sqlite3';
import type { CspSubject, RoomType } from '../../../../shared/csp/types.ts';

export interface SubjectRecord extends CspSubject {
  departmentName: string;
  departmentCode: string;
  batchCode: string;
  batchName: string;
  facultyName: string | null;
  createdAt: string;
}

export interface CreateSubjectInput {
  subjectCode: string;
  name: string;
  departmentId: number;
  semester: number;
  batchId: number;
  facultyId: number | null;
  weeklySessions: number;
  sessionDuration: number;
  studentCount: number;
  requiredRoomType: RoomType;
  requiredEquipment: string[];
  credits: number;
  colorHex?: string;
}

export class SubjectRepository {
  private db: Database.Database;
  constructor(db: Database.Database) {
    this.db = db;
  }

  findAll(): SubjectRecord[] {
    const rows = this.db
      .prepare(`
        SELECT s.*, d.name AS department_name, d.code AS department_code,
          b.batch_code, b.name AS batch_name,
          f.full_name AS faculty_name
        FROM subjects s
        JOIN departments d ON d.id = s.department_id
        JOIN batches b ON b.id = s.batch_id
        LEFT JOIN faculty f ON f.id = s.faculty_id
        ORDER BY s.subject_code ASC
      `)
      .all() as Array<Record<string, unknown>>;

    const reqRows = this.db
      .prepare('SELECT subject_id, equipment_name FROM subject_requirements')
      .all() as Array<{ subject_id: number; equipment_name: string }>;
    const reqMap = new Map<number, string[]>();
    for (const req of reqRows) {
      const list = reqMap.get(req.subject_id) ?? [];
      list.push(req.equipment_name);
      reqMap.set(req.subject_id, list);
    }

    return rows.map((r) => ({
      id: Number(r.id),
      subjectCode: String(r.subject_code),
      name: String(r.name),
      departmentId: Number(r.department_id),
      departmentName: String(r.department_name),
      departmentCode: String(r.department_code),
      semester: Number(r.semester),
      batchId: Number(r.batch_id),
      batchCode: String(r.batch_code),
      batchName: String(r.batch_name),
      facultyId: r.faculty_id === null ? null : Number(r.faculty_id),
      facultyName: r.faculty_name ? String(r.faculty_name) : null,
      weeklySessions: Number(r.weekly_sessions),
      sessionDuration: Number(r.session_duration),
      studentCount: Number(r.student_count),
      requiredRoomType: r.required_room_type as RoomType,
      requiredEquipment: reqMap.get(Number(r.id)) ?? [],
      credits: Number(r.credits),
      colorHex: String(r.color_hex),
      createdAt: String(r.created_at),
    }));
  }

  findById(id: number): SubjectRecord | undefined {
    const r = this.db
      .prepare(`
        SELECT s.*, d.name AS department_name, d.code AS department_code,
          b.batch_code, b.name AS batch_name,
          f.full_name AS faculty_name
        FROM subjects s
        JOIN departments d ON d.id = s.department_id
        JOIN batches b ON b.id = s.batch_id
        LEFT JOIN faculty f ON f.id = s.faculty_id
        WHERE s.id = ?
      `)
      .get(id) as Record<string, unknown> | undefined;

    if (!r) return undefined;

    const reqs = (
      this.db
        .prepare('SELECT equipment_name FROM subject_requirements WHERE subject_id = ?')
        .all(id) as Array<{ equipment_name: string }>
    ).map((x) => x.equipment_name);

    return {
      id: Number(r.id),
      subjectCode: String(r.subject_code),
      name: String(r.name),
      departmentId: Number(r.department_id),
      departmentName: String(r.department_name),
      departmentCode: String(r.department_code),
      semester: Number(r.semester),
      batchId: Number(r.batch_id),
      batchCode: String(r.batch_code),
      batchName: String(r.batch_name),
      facultyId: r.faculty_id === null ? null : Number(r.faculty_id),
      facultyName: r.faculty_name ? String(r.faculty_name) : null,
      weeklySessions: Number(r.weekly_sessions),
      sessionDuration: Number(r.session_duration),
      studentCount: Number(r.student_count),
      requiredRoomType: r.required_room_type as RoomType,
      requiredEquipment: reqs,
      credits: Number(r.credits),
      colorHex: String(r.color_hex),
      createdAt: String(r.created_at),
    };
  }

  create(input: CreateSubjectInput): SubjectRecord {
    const tx = this.db.transaction(() => {
      const info = this.db
        .prepare(
          `INSERT INTO subjects (
            subject_code, name, department_id, semester, batch_id, faculty_id,
            weekly_sessions, session_duration, student_count, required_room_type, credits, color_hex
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          input.subjectCode.trim().toUpperCase(),
          input.name.trim(),
          input.departmentId,
          input.semester,
          input.batchId,
          input.facultyId,
          input.weeklySessions,
          input.sessionDuration,
          input.studentCount,
          input.requiredRoomType,
          input.credits,
          input.colorHex ?? '#3730a3'
        );
      const id = Number(info.lastInsertRowid);
      this.replaceEquipment(id, input.requiredEquipment);
      return id;
    });
    const newId = tx();
    return this.findById(newId)!;
  }

  update(id: number, input: Partial<CreateSubjectInput>): SubjectRecord | undefined {
    const existing = this.findById(id);
    if (!existing) return undefined;

    const tx = this.db.transaction(() => {
      this.db
        .prepare(
          `UPDATE subjects SET
            subject_code = ?,
            name = ?,
            department_id = ?,
            semester = ?,
            batch_id = ?,
            faculty_id = ?,
            weekly_sessions = ?,
            session_duration = ?,
            student_count = ?,
            required_room_type = ?,
            credits = ?,
            color_hex = ?
          WHERE id = ?`
        )
        .run(
          (input.subjectCode ?? existing.subjectCode).trim().toUpperCase(),
          (input.name ?? existing.name).trim(),
          input.departmentId ?? existing.departmentId,
          input.semester ?? existing.semester,
          input.batchId ?? existing.batchId,
          input.facultyId !== undefined ? input.facultyId : existing.facultyId,
          input.weeklySessions ?? existing.weeklySessions,
          input.sessionDuration ?? existing.sessionDuration,
          input.studentCount ?? existing.studentCount,
          input.requiredRoomType ?? existing.requiredRoomType,
          input.credits ?? existing.credits,
          input.colorHex ?? existing.colorHex,
          id
        );

      if (input.requiredEquipment !== undefined) {
        this.replaceEquipment(id, input.requiredEquipment);
      }
    });
    tx();
    return this.findById(id);
  }

  delete(id: number): boolean {
    const res = this.db.prepare('DELETE FROM subjects WHERE id = ?').run(id);
    return res.changes > 0;
  }

  private replaceEquipment(subjectId: number, equipment: string[]): void {
    this.db.prepare('DELETE FROM subject_requirements WHERE subject_id = ?').run(subjectId);
    const ins = this.db.prepare('INSERT OR IGNORE INTO subject_requirements (subject_id, equipment_name) VALUES (?, ?)');
    for (const eq of equipment) {
      const cleaned = eq.trim();
      if (cleaned) ins.run(subjectId, cleaned);
    }
  }
}
