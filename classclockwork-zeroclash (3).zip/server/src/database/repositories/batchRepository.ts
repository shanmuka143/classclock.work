import type Database from 'better-sqlite3';
import type { CspBatch } from '../../../../shared/csp/types.ts';

export interface BatchRecord extends CspBatch {
  departmentName: string;
  departmentCode: string;
  subjectCount: number;
  createdAt: string;
}

export interface CreateBatchInput {
  batchCode: string;
  name: string;
  departmentId: number;
  semester: number;
  studentStrength: number;
}

export class BatchRepository {
  private db: Database.Database;
  constructor(db: Database.Database) {
    this.db = db;
  }

  findAll(): BatchRecord[] {
    const rows = this.db
      .prepare(`
        SELECT b.*, d.name AS department_name, d.code AS department_code,
          (SELECT COUNT(*) FROM subjects s WHERE s.batch_id = b.id) AS subject_count
        FROM batches b
        JOIN departments d ON d.id = b.department_id
        ORDER BY b.batch_code ASC
      `)
      .all() as Array<Record<string, unknown>>;

    return rows.map((r) => ({
      id: Number(r.id),
      batchCode: String(r.batch_code),
      name: String(r.name),
      departmentId: Number(r.department_id),
      departmentName: String(r.department_name),
      departmentCode: String(r.department_code),
      semester: Number(r.semester),
      studentStrength: Number(r.student_strength),
      subjectCount: Number(r.subject_count),
      createdAt: String(r.created_at),
    }));
  }

  findById(id: number): BatchRecord | undefined {
    const r = this.db
      .prepare(`
        SELECT b.*, d.name AS department_name, d.code AS department_code,
          (SELECT COUNT(*) FROM subjects s WHERE s.batch_id = b.id) AS subject_count
        FROM batches b
        JOIN departments d ON d.id = b.department_id
        WHERE b.id = ?
      `)
      .get(id) as Record<string, unknown> | undefined;

    if (!r) return undefined;
    return {
      id: Number(r.id),
      batchCode: String(r.batch_code),
      name: String(r.name),
      departmentId: Number(r.department_id),
      departmentName: String(r.department_name),
      departmentCode: String(r.department_code),
      semester: Number(r.semester),
      studentStrength: Number(r.student_strength),
      subjectCount: Number(r.subject_count),
      createdAt: String(r.created_at),
    };
  }

  create(input: CreateBatchInput): BatchRecord {
    const info = this.db
      .prepare(
        'INSERT INTO batches (batch_code, name, department_id, semester, student_strength) VALUES (?, ?, ?, ?, ?)'
      )
      .run(
        input.batchCode.trim().toUpperCase(),
        input.name.trim(),
        input.departmentId,
        input.semester,
        input.studentStrength
      );
    return this.findById(Number(info.lastInsertRowid))!;
  }

  update(id: number, input: Partial<CreateBatchInput>): BatchRecord | undefined {
    const existing = this.findById(id);
    if (!existing) return undefined;

    this.db
      .prepare(
        `UPDATE batches SET batch_code = ?, name = ?, department_id = ?, semester = ?, student_strength = ? WHERE id = ?`
      )
      .run(
        (input.batchCode ?? existing.batchCode).trim().toUpperCase(),
        (input.name ?? existing.name).trim(),
        input.departmentId ?? existing.departmentId,
        input.semester ?? existing.semester,
        input.studentStrength ?? existing.studentStrength,
        id
      );
    return this.findById(id);
  }

  countDependencies(id: number): { subjects: number } {
    const subjects = (this.db.prepare('SELECT COUNT(*) as cnt FROM subjects WHERE batch_id = ?').get(id) as { cnt: number }).cnt;
    return { subjects };
  }

  delete(id: number): boolean {
    const res = this.db.prepare('DELETE FROM batches WHERE id = ?').run(id);
    return res.changes > 0;
  }
}
