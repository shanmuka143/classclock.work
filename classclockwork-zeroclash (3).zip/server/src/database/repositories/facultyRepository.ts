import type Database from 'better-sqlite3';
import type { CspFaculty, DayOfWeek } from '../../../../shared/csp/types.ts';

export interface FacultyRecord extends CspFaculty {
  email: string;
  departmentName: string;
  departmentCode: string;
  assignedSubjectCount: number;
  assignedWeeklyHours: number;
  createdAt: string;
}

export interface CreateFacultyInput {
  facultyCode: string;
  fullName: string;
  email: string;
  departmentId: number;
  maxWeeklyHours: number;
  availableDays: DayOfWeek[];
  preferredHours: Array<{ day: DayOfWeek; periodNumber: number }>;
  unavailableSlots: Array<{ day: DayOfWeek; periodNumber: number }>;
}

export class FacultyRepository {
  private db: Database.Database;
  constructor(db: Database.Database) {
    this.db = db;
  }

  findAll(): FacultyRecord[] {
    const rows = this.db
      .prepare(`
        SELECT f.*, d.name AS department_name, d.code AS department_code,
          (SELECT COUNT(*) FROM subjects s WHERE s.faculty_id = f.id) AS assigned_subject_count,
          (SELECT COALESCE(SUM(s.weekly_sessions * s.session_duration), 0) FROM subjects s WHERE s.faculty_id = f.id) AS assigned_weekly_hours
        FROM faculty f
        JOIN departments d ON d.id = f.department_id
        ORDER BY f.faculty_code ASC
      `)
      .all() as Array<Record<string, unknown>>;

    const availRows = this.db
      .prepare('SELECT faculty_id, day_of_week, period_number, status FROM faculty_availability')
      .all() as Array<{ faculty_id: number; day_of_week: DayOfWeek; period_number: number; status: 'preferred' | 'unavailable' }>;

    const availMap = new Map<number, typeof availRows>();
    for (const a of availRows) {
      const list = availMap.get(a.faculty_id) ?? [];
      list.push(a);
      availMap.set(a.faculty_id, list);
    }

    return rows.map((r) => {
      const id = Number(r.id);
      const slots = availMap.get(id) ?? [];
      return {
        id,
        facultyCode: String(r.faculty_code),
        fullName: String(r.full_name),
        email: String(r.email),
        departmentId: Number(r.department_id),
        departmentName: String(r.department_name),
        departmentCode: String(r.department_code),
        maxWeeklyHours: Number(r.max_weekly_hours),
        availableDays: JSON.parse(String(r.available_days_json)) as DayOfWeek[],
        preferredHours: slots.filter((s) => s.status === 'preferred').map((s) => ({ day: s.day_of_week, periodNumber: s.period_number })),
        unavailableSlots: slots.filter((s) => s.status === 'unavailable').map((s) => ({ day: s.day_of_week, periodNumber: s.period_number })),
        assignedSubjectCount: Number(r.assigned_subject_count),
        assignedWeeklyHours: Number(r.assigned_weekly_hours),
        createdAt: String(r.created_at),
      };
    });
  }

  findById(id: number): FacultyRecord | undefined {
    const r = this.db
      .prepare(`
        SELECT f.*, d.name AS department_name, d.code AS department_code,
          (SELECT COUNT(*) FROM subjects s WHERE s.faculty_id = f.id) AS assigned_subject_count,
          (SELECT COALESCE(SUM(s.weekly_sessions * s.session_duration), 0) FROM subjects s WHERE s.faculty_id = f.id) AS assigned_weekly_hours
        FROM faculty f
        JOIN departments d ON d.id = f.department_id
        WHERE f.id = ?
      `)
      .get(id) as Record<string, unknown> | undefined;

    if (!r) return undefined;

    const slots = this.db
      .prepare('SELECT day_of_week, period_number, status FROM faculty_availability WHERE faculty_id = ?')
      .all(id) as Array<{ day_of_week: DayOfWeek; period_number: number; status: 'preferred' | 'unavailable' }>;

    return {
      id: Number(r.id),
      facultyCode: String(r.faculty_code),
      fullName: String(r.full_name),
      email: String(r.email),
      departmentId: Number(r.department_id),
      departmentName: String(r.department_name),
      departmentCode: String(r.department_code),
      maxWeeklyHours: Number(r.max_weekly_hours),
      availableDays: JSON.parse(String(r.available_days_json)) as DayOfWeek[],
      preferredHours: slots.filter((s) => s.status === 'preferred').map((s) => ({ day: s.day_of_week, periodNumber: s.period_number })),
      unavailableSlots: slots.filter((s) => s.status === 'unavailable').map((s) => ({ day: s.day_of_week, periodNumber: s.period_number })),
      assignedSubjectCount: Number(r.assigned_subject_count),
      assignedWeeklyHours: Number(r.assigned_weekly_hours),
      createdAt: String(r.created_at),
    };
  }

  create(input: CreateFacultyInput): FacultyRecord {
    const tx = this.db.transaction(() => {
      const info = this.db
        .prepare(
          'INSERT INTO faculty (faculty_code, full_name, email, department_id, max_weekly_hours, available_days_json) VALUES (?, ?, ?, ?, ?, ?)'
        )
        .run(
          input.facultyCode.trim().toUpperCase(),
          input.fullName.trim(),
          input.email.trim().toLowerCase(),
          input.departmentId,
          input.maxWeeklyHours,
          JSON.stringify(input.availableDays)
        );
      const id = Number(info.lastInsertRowid);
      this.replaceAvailability(id, input.preferredHours, input.unavailableSlots);
      return id;
    });
    const newId = tx();
    return this.findById(newId)!;
  }

  update(id: number, input: Partial<CreateFacultyInput>): FacultyRecord | undefined {
    const existing = this.findById(id);
    if (!existing) return undefined;

    const tx = this.db.transaction(() => {
      this.db
        .prepare(
          `UPDATE faculty SET
            faculty_code = ?,
            full_name = ?,
            email = ?,
            department_id = ?,
            max_weekly_hours = ?,
            available_days_json = ?
          WHERE id = ?`
        )
        .run(
          (input.facultyCode ?? existing.facultyCode).trim().toUpperCase(),
          (input.fullName ?? existing.fullName).trim(),
          (input.email ?? existing.email).trim().toLowerCase(),
          input.departmentId ?? existing.departmentId,
          input.maxWeeklyHours ?? existing.maxWeeklyHours,
          JSON.stringify(input.availableDays ?? existing.availableDays),
          id
        );

      if (input.preferredHours !== undefined || input.unavailableSlots !== undefined) {
        this.replaceAvailability(
          id,
          input.preferredHours ?? existing.preferredHours,
          input.unavailableSlots ?? existing.unavailableSlots
        );
      }
    });
    tx();
    return this.findById(id);
  }

  countDependencies(id: number): { subjects: number; allocations: number } {
    const subjects = (this.db.prepare('SELECT COUNT(*) as cnt FROM subjects WHERE faculty_id = ?').get(id) as { cnt: number }).cnt;
    const allocations = (this.db.prepare('SELECT COUNT(*) as cnt FROM timetable_allocations WHERE faculty_id = ?').get(id) as { cnt: number }).cnt;
    return { subjects, allocations };
  }

  delete(id: number, forceReassignToId?: number | null): boolean {
    const tx = this.db.transaction(() => {
      if (forceReassignToId !== undefined) {
        this.db.prepare('UPDATE subjects SET faculty_id = ? WHERE faculty_id = ?').run(forceReassignToId, id);
        if (forceReassignToId !== null) {
          this.db.prepare('UPDATE timetable_allocations SET faculty_id = ? WHERE faculty_id = ?').run(forceReassignToId, id);
        } else {
          this.db.prepare('DELETE FROM timetable_allocations WHERE faculty_id = ?').run(id);
        }
      }
      const res = this.db.prepare('DELETE FROM faculty WHERE id = ?').run(id);
      return res.changes > 0;
    });
    return tx();
  }

  private replaceAvailability(
    facultyId: number,
    preferred: Array<{ day: DayOfWeek; periodNumber: number }>,
    unavailable: Array<{ day: DayOfWeek; periodNumber: number }>
  ): void {
    this.db.prepare('DELETE FROM faculty_availability WHERE faculty_id = ?').run(facultyId);
    const ins = this.db.prepare(
      'INSERT OR REPLACE INTO faculty_availability (faculty_id, day_of_week, period_number, status) VALUES (?, ?, ?, ?)'
    );
    for (const p of preferred) {
      ins.run(facultyId, p.day, p.periodNumber, 'preferred');
    }
    for (const u of unavailable) {
      ins.run(facultyId, u.day, u.periodNumber, 'unavailable');
    }
  }
}
