import type Database from 'better-sqlite3';

export interface SessionRecord {
  jti: string;
  userId: number;
  issuedAt: string;
  expiresAt: string;
  revokedAt: string | null;
}

export class SessionRepository {
  private db: Database.Database;

  constructor(db: Database.Database) {
    this.db = db;
  }

  create(params: {
    jti: string;
    userId: number;
    expiresAtIso: string;
    userAgent?: string | null;
    ipAddress?: string | null;
  }): void {
    this.db
      .prepare(
        `INSERT INTO user_sessions (jti, user_id, expires_at, user_agent, ip_address)
         VALUES (?, ?, ?, ?, ?)`
      )
      .run(
        params.jti,
        params.userId,
        params.expiresAtIso,
        params.userAgent ?? null,
        params.ipAddress ?? null
      );
  }

  isSessionActive(jti: string, userId: number): boolean {
    const row = this.db
      .prepare(
        `SELECT jti, user_id, revoked_at, expires_at
         FROM user_sessions
         WHERE jti = ? AND user_id = ?`
      )
      .get(jti, userId) as
      | { jti: string; user_id: number; revoked_at: string | null; expires_at: string }
      | undefined;

    if (!row) return false;
    if (row.revoked_at !== null) return false;
    const expTime = Date.parse(row.expires_at);
    if (Number.isNaN(expTime) || expTime <= Date.now()) return false;
    return true;
  }

  revoke(jti: string): boolean {
    const res = this.db
      .prepare(`UPDATE user_sessions SET revoked_at = datetime('now') WHERE jti = ? AND revoked_at IS NULL`)
      .run(jti);
    return res.changes > 0;
  }

  revokeAllForUser(userId: number): number {
    const res = this.db
      .prepare(`UPDATE user_sessions SET revoked_at = datetime('now') WHERE user_id = ? AND revoked_at IS NULL`)
      .run(userId);
    return res.changes;
  }

  purgeExpired(): number {
    const nowIso = new Date().toISOString();
    const res = this.db
      .prepare(`DELETE FROM user_sessions WHERE expires_at <= ?`)
      .run(nowIso);
    return res.changes;
  }
}
