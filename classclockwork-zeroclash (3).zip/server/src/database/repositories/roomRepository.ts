import type Database from 'better-sqlite3';
import type { CspRoom, RoomType } from '../../../../shared/csp/types.ts';

export interface RoomRecord extends CspRoom {
  createdAt: string;
}

export interface CreateRoomInput {
  roomCode: string;
  name: string;
  roomType: RoomType;
  capacity: number;
  equipment: string[];
  isAvailable: boolean;
}

export class RoomRepository {
  private db: Database.Database;
  constructor(db: Database.Database) {
    this.db = db;
  }

  findAll(): RoomRecord[] {
    const rows = this.db.prepare('SELECT * FROM rooms ORDER BY room_code ASC').all() as Array<Record<string, unknown>>;
    return rows.map((r) => ({
      id: Number(r.id),
      roomCode: String(r.room_code),
      name: String(r.name),
      roomType: r.room_type as RoomType,
      capacity: Number(r.capacity),
      equipment: JSON.parse(String(r.equipment_json)) as string[],
      isAvailable: Boolean(r.is_available),
      createdAt: String(r.created_at),
    }));
  }

  findById(id: number): RoomRecord | undefined {
    const r = this.db.prepare('SELECT * FROM rooms WHERE id = ?').get(id) as Record<string, unknown> | undefined;
    if (!r) return undefined;
    return {
      id: Number(r.id),
      roomCode: String(r.room_code),
      name: String(r.name),
      roomType: r.room_type as RoomType,
      capacity: Number(r.capacity),
      equipment: JSON.parse(String(r.equipment_json)) as string[],
      isAvailable: Boolean(r.is_available),
      createdAt: String(r.created_at),
    };
  }

  create(input: CreateRoomInput): RoomRecord {
    const info = this.db
      .prepare(
        'INSERT INTO rooms (room_code, name, room_type, capacity, equipment_json, is_available) VALUES (?, ?, ?, ?, ?, ?)'
      )
      .run(
        input.roomCode.trim().toUpperCase(),
        input.name.trim(),
        input.roomType,
        input.capacity,
        JSON.stringify(input.equipment),
        input.isAvailable ? 1 : 0
      );
    return this.findById(Number(info.lastInsertRowid))!;
  }

  update(id: number, input: Partial<CreateRoomInput>): RoomRecord | undefined {
    const existing = this.findById(id);
    if (!existing) return undefined;

    this.db
      .prepare(
        `UPDATE rooms SET room_code = ?, name = ?, room_type = ?, capacity = ?, equipment_json = ?, is_available = ? WHERE id = ?`
      )
      .run(
        (input.roomCode ?? existing.roomCode).trim().toUpperCase(),
        (input.name ?? existing.name).trim(),
        input.roomType ?? existing.roomType,
        input.capacity ?? existing.capacity,
        JSON.stringify(input.equipment ?? existing.equipment),
        (input.isAvailable ?? existing.isAvailable) ? 1 : 0,
        id
      );
    return this.findById(id);
  }

  countDependencies(id: number): { allocations: number } {
    const allocations = (this.db.prepare('SELECT COUNT(*) as cnt FROM timetable_allocations WHERE room_id = ?').get(id) as { cnt: number }).cnt;
    return { allocations };
  }

  delete(id: number): boolean {
    const res = this.db.prepare('DELETE FROM rooms WHERE id = ?').run(id);
    return res.changes > 0;
  }
}
