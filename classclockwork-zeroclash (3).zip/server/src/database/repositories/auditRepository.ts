import type Database from 'better-sqlite3';

export interface AuditLogRecord {
  id: number;
  actorUserId: number | null;
  actorUsername: string | null;
  action: string;
  entityType: string;
  entityId: string | null;
  status: 'success' | 'failure' | 'denied';
  details: Record<string, unknown> | null;
  ipAddress: string | null;
  createdAt: string;
}

export interface CreateAuditLogInput {
  actorUserId?: number | null;
  actorUsername?: string | null;
  action: string;
  entityType: string;
  entityId?: string | number | null;
  status: 'success' | 'failure' | 'denied';
  details?: Record<string, unknown> | null;
  ipAddress?: string | null;
}

export class AuditRepository {
  private db: Database.Database;

  constructor(db: Database.Database) {
    this.db = db;
  }

  record(input: CreateAuditLogInput): number {
    const info = this.db
      .prepare(
        `INSERT INTO audit_logs (
          actor_user_id, actor_username, action, entity_type, entity_id, status, details_json, ip_address
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        input.actorUserId ?? null,
        input.actorUsername ?? null,
        input.action,
        input.entityType,
        input.entityId !== undefined && input.entityId !== null ? String(input.entityId) : null,
        input.status,
        input.details ? JSON.stringify(input.details) : null,
        input.ipAddress ?? null
      );
    return Number(info.lastInsertRowid);
  }

  list(filters?: {
    action?: string;
    status?: string;
    page?: number;
    limit?: number;
  }): { items: AuditLogRecord[]; total: number; page: number; limit: number } {
    const page = Math.max(1, filters?.page ?? 1);
    const limit = Math.min(100, Math.max(1, filters?.limit ?? 25));
    const offset = (page - 1) * limit;

    const whereClauses: string[] = [];
    const params: unknown[] = [];

    if (filters?.action && filters.action.trim()) {
      whereClauses.push('action LIKE ?');
      params.push(`%${filters.action.trim()}%`);
    }
    if (filters?.status && filters.status !== 'all') {
      whereClauses.push('status = ?');
      params.push(filters.status);
    }

    const whereSql = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';
    const totalRow = this.db
      .prepare(`SELECT COUNT(*) AS cnt FROM audit_logs ${whereSql}`)
      .get(...params) as { cnt: number };

    const rows = this.db
      .prepare(
        `SELECT * FROM audit_logs ${whereSql} ORDER BY id DESC LIMIT ? OFFSET ?`
      )
      .all(...params, limit, offset) as Array<Record<string, unknown>>;

    return {
      items: rows.map((r) => ({
        id: Number(r.id),
        actorUserId: r.actor_user_id === null ? null : Number(r.actor_user_id),
        actorUsername: r.actor_username ? String(r.actor_username) : null,
        action: String(r.action),
        entityType: String(r.entity_type),
        entityId: r.entity_id ? String(r.entity_id) : null,
        status: r.status as AuditLogRecord['status'],
        details: r.details_json ? (JSON.parse(String(r.details_json)) as Record<string, unknown>) : null,
        ipAddress: r.ip_address ? String(r.ip_address) : null,
        createdAt: String(r.created_at),
      })),
      total: totalRow.cnt,
      page,
      limit,
    };
  }
}
