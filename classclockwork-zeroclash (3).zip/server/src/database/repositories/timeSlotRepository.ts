import type Database from 'better-sqlite3';
import type { CspTimeSlot } from '../../../../shared/csp/types.ts';

export class TimeSlotRepository {
  private db: Database.Database;
  constructor(db: Database.Database) {
    this.db = db;
  }

  findAll(): CspTimeSlot[] {
    const rows = this.db
      .prepare('SELECT * FROM time_slots ORDER BY period_number ASC')
      .all() as Array<Record<string, unknown>>;

    return rows.map((r) => ({
      periodNumber: Number(r.period_number),
      label: String(r.label),
      startTime: String(r.start_time),
      endTime: String(r.end_time),
      isLunchBreak: Boolean(r.is_lunch_break),
    }));
  }

  replaceAll(slots: CspTimeSlot[]): CspTimeSlot[] {
    const tx = this.db.transaction(() => {
      this.db.prepare('DELETE FROM time_slots').run();
      const ins = this.db.prepare(
        'INSERT INTO time_slots (period_number, label, start_time, end_time, is_lunch_break) VALUES (?, ?, ?, ?, ?)'
      );
      for (const s of slots) {
        ins.run(s.periodNumber, s.label.trim(), s.startTime, s.endTime, s.isLunchBreak ? 1 : 0);
      }
    });
    tx();
    return this.findAll();
  }
}
