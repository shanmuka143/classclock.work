import type Database from 'better-sqlite3';

export interface DepartmentRecord {
  id: number;
  code: string;
  name: string;
  headName: string | null;
  createdAt: string;
}

export class DepartmentRepository {
  private db: Database.Database;
  constructor(db: Database.Database) {
    this.db = db;
  }

  findAll(): DepartmentRecord[] {
    const rows = this.db.prepare('SELECT * FROM departments ORDER BY code ASC').all() as Array<Record<string, unknown>>;
    return rows.map((r) => ({
      id: Number(r.id),
      code: String(r.code),
      name: String(r.name),
      headName: r.head_name ? String(r.head_name) : null,
      createdAt: String(r.created_at),
    }));
  }

  findById(id: number): DepartmentRecord | undefined {
    const r = this.db.prepare('SELECT * FROM departments WHERE id = ?').get(id) as Record<string, unknown> | undefined;
    if (!r) return undefined;
    return {
      id: Number(r.id),
      code: String(r.code),
      name: String(r.name),
      headName: r.head_name ? String(r.head_name) : null,
      createdAt: String(r.created_at),
    };
  }

  create(input: { code: string; name: string; headName?: string | null }): DepartmentRecord {
    const info = this.db
      .prepare('INSERT INTO departments (code, name, head_name) VALUES (?, ?, ?)')
      .run(input.code.trim().toUpperCase(), input.name.trim(), input.headName ?? null);
    return this.findById(Number(info.lastInsertRowid))!;
  }
}
