import type Database from 'better-sqlite3';

export interface UserRow {
  id: number;
  username: string;
  email: string;
  full_name: string;
  password_hash: string;
  role: 'admin' | 'coordinator' | 'evaluator' | 'viewer';
  created_at: string;
}

export class UserRepository {
  private db: Database.Database;
  constructor(db: Database.Database) {
    this.db = db;
  }

  findByUsernameOrEmail(identifier: string): UserRow | undefined {
    return this.db
      .prepare('SELECT * FROM users WHERE username = ? OR email = ?')
      .get(identifier, identifier) as UserRow | undefined;
  }

  findById(id: number): Omit<UserRow, 'password_hash'> | undefined {
    return this.db
      .prepare('SELECT id, username, email, full_name, role, created_at FROM users WHERE id = ?')
      .get(id) as Omit<UserRow, 'password_hash'> | undefined;
  }
}
