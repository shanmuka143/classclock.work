import type Database from 'better-sqlite3';
import { logger } from '../../config/logger.ts';
import { migration001 } from './001_initial_schema.ts';
import { migration002 } from './002_security_and_audit.ts';
import { migration003 } from './003_evaluator_role.ts';

interface Migration {
  name: string;
  disableForeignKeys?: boolean;
  up: (db: Database.Database) => void;
}

const migrations: Migration[] = [migration001, migration002, migration003];

export function runMigrations(db: Database.Database): string[] {
  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      applied_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  const existing = new Set<string>(
    (db.prepare('SELECT name FROM schema_migrations').all() as Array<{ name: string }>).map(
      (r) => r.name
    )
  );

  const applied: string[] = [];

  for (const migration of migrations) {
    if (existing.has(migration.name)) continue;

    if (migration.disableForeignKeys) {
      db.pragma('foreign_keys = OFF');
    }

    try {
      const tx = db.transaction(() => {
        migration.up(db);
        db.prepare('INSERT INTO schema_migrations (name) VALUES (?)').run(migration.name);
      });
      tx();
    } finally {
      if (migration.disableForeignKeys) {
        db.pragma('foreign_keys = ON');
      }
    }

    applied.push(migration.name);
    logger.info('Applied database migration', { migration: migration.name });
  }

  return applied;
}
