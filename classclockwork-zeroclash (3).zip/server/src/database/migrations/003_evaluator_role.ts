import type Database from 'better-sqlite3';

export const migration003 = {
  name: '003_evaluator_role',
  disableForeignKeys: true,
  up(db: Database.Database): void {
    db.exec(`
      CREATE TABLE users_v2 (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL UNIQUE,
        full_name TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL CHECK (role IN ('admin', 'coordinator', 'evaluator', 'viewer')),
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      INSERT INTO users_v2 (id, username, email, full_name, password_hash, role, created_at)
      SELECT id, username, email, full_name, password_hash, role, created_at FROM users;

      DROP TABLE users;
      ALTER TABLE users_v2 RENAME TO users;
    `);
  },
};
