import type Database from 'better-sqlite3';

export const migration001 = {
  name: '001_initial_schema',
  up(db: Database.Database): void {
    db.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL UNIQUE,
        full_name TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL CHECK (role IN ('admin', 'coordinator', 'viewer')),
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS departments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL UNIQUE,
        head_name TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS faculty (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        faculty_code TEXT NOT NULL UNIQUE,
        full_name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        department_id INTEGER NOT NULL REFERENCES departments(id) ON DELETE RESTRICT,
        max_weekly_hours INTEGER NOT NULL DEFAULT 18 CHECK (max_weekly_hours BETWEEN 1 AND 45),
        available_days_json TEXT NOT NULL DEFAULT '["Mon","Tue","Wed","Thu","Fri"]',
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS faculty_availability (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        faculty_id INTEGER NOT NULL REFERENCES faculty(id) ON DELETE CASCADE,
        day_of_week TEXT NOT NULL CHECK (day_of_week IN ('Mon','Tue','Wed','Thu','Fri')),
        period_number INTEGER NOT NULL CHECK (period_number BETWEEN 1 AND 12),
        status TEXT NOT NULL CHECK (status IN ('unavailable', 'preferred')),
        UNIQUE(faculty_id, day_of_week, period_number)
      );

      CREATE TABLE IF NOT EXISTS batches (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        batch_code TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        department_id INTEGER NOT NULL REFERENCES departments(id) ON DELETE RESTRICT,
        semester INTEGER NOT NULL CHECK (semester BETWEEN 1 AND 10),
        student_strength INTEGER NOT NULL CHECK (student_strength BETWEEN 1 AND 500),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        UNIQUE(name, department_id, semester)
      );

      CREATE TABLE IF NOT EXISTS rooms (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        room_code TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL UNIQUE,
        room_type TEXT NOT NULL CHECK (room_type IN ('lecture', 'lab', 'seminar')),
        capacity INTEGER NOT NULL CHECK (capacity BETWEEN 1 AND 600),
        equipment_json TEXT NOT NULL DEFAULT '[]',
        is_available INTEGER NOT NULL DEFAULT 1 CHECK (is_available IN (0, 1)),
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS subjects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject_code TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        department_id INTEGER NOT NULL REFERENCES departments(id) ON DELETE RESTRICT,
        semester INTEGER NOT NULL CHECK (semester BETWEEN 1 AND 10),
        batch_id INTEGER NOT NULL REFERENCES batches(id) ON DELETE RESTRICT,
        faculty_id INTEGER REFERENCES faculty(id) ON DELETE RESTRICT,
        weekly_sessions INTEGER NOT NULL CHECK (weekly_sessions BETWEEN 1 AND 12),
        session_duration INTEGER NOT NULL DEFAULT 1 CHECK (session_duration BETWEEN 1 AND 4),
        student_count INTEGER NOT NULL CHECK (student_count BETWEEN 1 AND 500),
        required_room_type TEXT NOT NULL CHECK (required_room_type IN ('lecture', 'lab', 'seminar')),
        credits INTEGER NOT NULL DEFAULT 3 CHECK (credits BETWEEN 1 AND 10),
        color_hex TEXT NOT NULL DEFAULT '#3730a3',
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS subject_requirements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
        equipment_name TEXT NOT NULL,
        UNIQUE(subject_id, equipment_name)
      );

      CREATE TABLE IF NOT EXISTS time_slots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        period_number INTEGER NOT NULL UNIQUE CHECK (period_number BETWEEN 1 AND 12),
        label TEXT NOT NULL,
        start_time TEXT NOT NULL,
        end_time TEXT NOT NULL,
        is_lunch_break INTEGER NOT NULL DEFAULT 0 CHECK (is_lunch_break IN (0, 1))
      );

      CREATE TABLE IF NOT EXISTS scheduling_runs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        status TEXT NOT NULL CHECK (status IN ('optimal', 'feasible', 'partial', 'infeasible', 'timeout', 'cancelled', 'manual')),
        is_published INTEGER NOT NULL DEFAULT 0 CHECK (is_published IN (0, 1)),
        total_meetings INTEGER NOT NULL,
        scheduled_meetings INTEGER NOT NULL,
        unscheduled_meetings INTEGER NOT NULL,
        hard_conflicts_count INTEGER NOT NULL DEFAULT 0,
        optimization_score REAL NOT NULL DEFAULT 0,
        nodes_explored INTEGER NOT NULL DEFAULT 0,
        duration_ms INTEGER NOT NULL DEFAULT 0,
        config_json TEXT NOT NULL DEFAULT '{}',
        unscheduled_json TEXT NOT NULL DEFAULT '[]',
        created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS timetable_allocations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        run_id INTEGER NOT NULL REFERENCES scheduling_runs(id) ON DELETE CASCADE,
        subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
        faculty_id INTEGER NOT NULL REFERENCES faculty(id) ON DELETE RESTRICT,
        batch_id INTEGER NOT NULL REFERENCES batches(id) ON DELETE CASCADE,
        room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE RESTRICT,
        day_of_week TEXT NOT NULL CHECK (day_of_week IN ('Mon','Tue','Wed','Thu','Fri')),
        start_period INTEGER NOT NULL CHECK (start_period BETWEEN 1 AND 12),
        duration_periods INTEGER NOT NULL DEFAULT 1 CHECK (duration_periods BETWEEN 1 AND 4),
        session_index INTEGER NOT NULL DEFAULT 1,
        is_locked INTEGER NOT NULL DEFAULT 0 CHECK (is_locked IN (0, 1)),
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS scheduling_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        run_id INTEGER REFERENCES scheduling_runs(id) ON DELETE CASCADE,
        level TEXT NOT NULL CHECK (level IN ('info', 'warn', 'error')),
        message TEXT NOT NULL,
        details_json TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS institution_settings (
        key TEXT PRIMARY KEY,
        value_json TEXT NOT NULL,
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE INDEX IF NOT EXISTS idx_faculty_dept ON faculty(department_id);
      CREATE INDEX IF NOT EXISTS idx_faculty_avail_fac ON faculty_availability(faculty_id);
      CREATE INDEX IF NOT EXISTS idx_batches_dept ON batches(department_id);
      CREATE INDEX IF NOT EXISTS idx_subjects_dept_sem ON subjects(department_id, semester);
      CREATE INDEX IF NOT EXISTS idx_subjects_batch ON subjects(batch_id);
      CREATE INDEX IF NOT EXISTS idx_subjects_faculty ON subjects(faculty_id);
      CREATE INDEX IF NOT EXISTS idx_allocations_run ON timetable_allocations(run_id);
      CREATE INDEX IF NOT EXISTS idx_allocations_day_period ON timetable_allocations(run_id, day_of_week, start_period);
      CREATE INDEX IF NOT EXISTS idx_allocations_faculty ON timetable_allocations(run_id, faculty_id);
      CREATE INDEX IF NOT EXISTS idx_allocations_room ON timetable_allocations(run_id, room_id);
      CREATE INDEX IF NOT EXISTS idx_allocations_batch ON timetable_allocations(run_id, batch_id);
    `);
  },
};
