import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import { config } from '../config/env.ts';
import { logger } from '../config/logger.ts';

let singletonDb: Database.Database | null = null;

export function createDatabase(dbPath: string): Database.Database {
  if (dbPath !== ':memory:') {
    const dir = path.dirname(dbPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    if (!fs.existsSync(dbPath)) {
      for (const suffix of ['-wal', '-shm']) {
        const sidecar = `${dbPath}${suffix}`;
        if (fs.existsSync(sidecar)) {
          fs.unlinkSync(sidecar);
        }
      }
    }
  }

  const db = new Database(dbPath);
  db.pragma('foreign_keys = ON');
  if (dbPath !== ':memory:') {
    db.pragma('journal_mode = WAL');
  }
  db.pragma('busy_timeout = 5000');
  return db;
}

export function getDb(): Database.Database {
  if (!singletonDb) {
    singletonDb = createDatabase(config.dbPath);
    logger.info('SQLite database connected', { dbPath: config.dbPath });
  }
  return singletonDb;
}

export function closeDb(): void {
  if (singletonDb) {
    singletonDb.close();
    singletonDb = null;
  }
}
