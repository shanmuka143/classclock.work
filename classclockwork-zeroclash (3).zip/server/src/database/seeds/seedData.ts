import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';
import type Database from 'better-sqlite3';
import { solveTimetableCsp } from '../../../../shared/csp/cspSolver.ts';
import type { CspBatch, CspFaculty, CspRoom, CspSubject, CspTimeSlot, DayOfWeek } from '../../../../shared/csp/types.ts';
import { logger } from '../../config/logger.ts';

export interface BootstrapAdminInput {
  username?: string;
  email?: string;
  fullName?: string;
  password: string;
}

function getBcryptRounds(): number {
  return process.env.NODE_ENV === 'production' ? 12 : 10;
}

function pickNonEmpty(value: string | undefined, fallback: string): string {
  return value && value.trim().length > 0 ? value.trim() : fallback;
}

function pickEmail(value: string | undefined, fallback: string): string {
  const trimmed = value?.trim().toLowerCase() ?? '';
  return trimmed.includes('@') ? trimmed : fallback;
}

export function bootstrapAdmin(db: Database.Database, input: BootstrapAdminInput): { created: boolean; username: string } {
  const username = pickNonEmpty(input.username ?? process.env.BOOTSTRAP_ADMIN_USERNAME, 'admin');
  const email = pickEmail(input.email ?? process.env.BOOTSTRAP_ADMIN_EMAIL, 'admin@classclockwork.edu');
  const fullName = pickNonEmpty(input.fullName ?? process.env.BOOTSTRAP_ADMIN_NAME, 'Dr. Eleanor Vance');
  const password = input.password;

  if (!password || password.length < 10) {
    throw new Error('BOOTSTRAP_ADMIN_PASSWORD must be at least 10 characters long.');
  }

  const hash = bcrypt.hashSync(password, getBcryptRounds());
  const existing = db.prepare('SELECT id, username FROM users WHERE username = ? OR email = ?').get(username, email) as
    | { id: number; username: string }
    | undefined;

  if (existing) {
    db.prepare('UPDATE users SET email = ?, full_name = ?, password_hash = ?, role = ? WHERE id = ?').run(
      email,
      fullName,
      hash,
      'admin',
      existing.id
    );
    return { created: false, username: existing.username };
  }

  db.prepare(
    'INSERT INTO users (username, email, full_name, password_hash, role) VALUES (?, ?, ?, ?, ?)'
  ).run(username, email, fullName, hash, 'admin');

  return { created: true, username };
}

export function bootstrapEvaluator(
  db: Database.Database,
  input?: { username?: string; email?: string; fullName?: string; password?: string }
): { created: boolean; username: string; password: string } {
  const username = pickNonEmpty(input?.username ?? process.env.BOOTSTRAP_EVALUATOR_USERNAME, 'evaluator');
  const email = pickEmail(input?.email ?? process.env.BOOTSTRAP_EVALUATOR_EMAIL, 'evaluator@classclockwork.edu');
  const fullName = pickNonEmpty(input?.fullName ?? process.env.BOOTSTRAP_EVALUATOR_NAME, 'Academic Project Evaluator');
  const providedPassword = pickNonEmpty(input?.password ?? process.env.BOOTSTRAP_EVALUATOR_PASSWORD, '');
  const generatedPassword =
    providedPassword && providedPassword.length >= 10
      ? providedPassword
      : `Eval-${crypto.randomBytes(9).toString('base64url')}!`;

  const hash = bcrypt.hashSync(generatedPassword, getBcryptRounds());
  const existing = db.prepare('SELECT id, username FROM users WHERE username = ? OR email = ?').get(username, email) as
    | { id: number; username: string }
    | undefined;

  if (existing) {
    db.prepare('UPDATE users SET email = ?, full_name = ?, password_hash = ?, role = ? WHERE id = ?').run(
      email,
      fullName,
      hash,
      'evaluator',
      existing.id
    );
    return { created: false, username: existing.username, password: generatedPassword };
  }

  db.prepare(
    'INSERT INTO users (username, email, full_name, password_hash, role) VALUES (?, ?, ?, ?, ?)'
  ).run(username, email, fullName, hash, 'evaluator');

  return { created: true, username, password: generatedPassword };
}

export function seedDatabase(db: Database.Database): { seeded: boolean } {
  const userCount = (db.prepare('SELECT COUNT(*) as cnt FROM users').get() as { cnt: number }).cnt;
  if (userCount > 0) {
    return { seeded: false };
  }

  const isProd = process.env.NODE_ENV === 'production';
  const adminUsername = pickNonEmpty(process.env.BOOTSTRAP_ADMIN_USERNAME, 'admin');
  const adminEmail = pickEmail(process.env.BOOTSTRAP_ADMIN_EMAIL, 'admin@classclockwork.edu');
  const adminName = pickNonEmpty(process.env.BOOTSTRAP_ADMIN_NAME, 'Dr. Eleanor Vance');
  const adminPassword = pickNonEmpty(process.env.BOOTSTRAP_ADMIN_PASSWORD, isProd ? '' : 'Admin@2026');

  if (isProd && adminPassword.length < 10) {
    throw new Error(
      'Production bootstrap error: BOOTSTRAP_ADMIN_PASSWORD (>= 10 characters) is required when initializing an empty production database.'
    );
  }

  const coordUsername = pickNonEmpty(process.env.BOOTSTRAP_COORDINATOR_USERNAME, 'coordinator');
  const coordEmail = pickEmail(process.env.BOOTSTRAP_COORDINATOR_EMAIL, 'coordinator@classclockwork.edu');
  const coordPassword = pickNonEmpty(process.env.BOOTSTRAP_COORDINATOR_PASSWORD, isProd ? '' : 'Coord@2026');

  const evalUsername = pickNonEmpty(process.env.BOOTSTRAP_EVALUATOR_USERNAME, 'evaluator');
  const evalEmail = pickEmail(process.env.BOOTSTRAP_EVALUATOR_EMAIL, 'evaluator@classclockwork.edu');
  const evalName = pickNonEmpty(process.env.BOOTSTRAP_EVALUATOR_NAME, 'Academic Project Evaluator');
  const evalPassword = pickNonEmpty(process.env.BOOTSTRAP_EVALUATOR_PASSWORD, '');

  const rounds = getBcryptRounds();
  const adminHash = bcrypt.hashSync(adminPassword, rounds);
  const coordHash = coordPassword.length >= 8 ? bcrypt.hashSync(coordPassword, rounds) : null;
  const evalHash = evalPassword.length >= 10 ? bcrypt.hashSync(evalPassword, rounds) : null;

  const tx = db.transaction(() => {
    // 1. Users
    const insertUser = db.prepare(
      'INSERT INTO users (username, email, full_name, password_hash, role) VALUES (?, ?, ?, ?, ?)'
    );
    const adminInfo = insertUser.run(adminUsername, adminEmail, adminName, adminHash, 'admin');
    if (coordHash) {
      insertUser.run(coordUsername, coordEmail, 'Prof. Marcus Sterling', coordHash, 'coordinator');
    }
    if (evalHash) {
      insertUser.run(evalUsername, evalEmail, evalName, evalHash, 'evaluator');
    }

    // 2. Departments
    const insertDept = db.prepare('INSERT INTO departments (code, name, head_name) VALUES (?, ?, ?)');
    const csDeptId = Number(insertDept.run('CSE', 'Computer Science & Engineering', 'Dr. Alan Mercer').lastInsertRowid);
    const eceDeptId = Number(insertDept.run('ECE', 'Electronics & Communication', 'Dr. Priya Nair').lastInsertRowid);
    const mathDeptId = Number(insertDept.run('MATH', 'Applied Mathematics', 'Dr. Henrik Lindqvist').lastInsertRowid);
    const mechDeptId = Number(insertDept.run('MECH', 'Mechanical Engineering', 'Dr. Samuel Okafor').lastInsertRowid);

    // 3. Time slots (8 periods: 08:30 to 17:00, Period 4 = Lunch Break)
    const insertSlot = db.prepare(
      'INSERT INTO time_slots (period_number, label, start_time, end_time, is_lunch_break) VALUES (?, ?, ?, ?, ?)'
    );
    const slots: Array<[number, string, string, string, number]> = [
      [1, 'Period 1', '08:30', '09:30', 0],
      [2, 'Period 2', '09:30', '10:30', 0],
      [3, 'Period 3', '10:45', '11:45', 0],
      [4, 'Lunch Break', '11:45', '12:45', 1],
      [5, 'Period 5', '12:45', '13:45', 0],
      [6, 'Period 6', '13:45', '14:45', 0],
      [7, 'Period 7', '15:00', '16:00', 0],
      [8, 'Period 8', '16:00', '17:00', 0],
    ];
    for (const s of slots) {
      insertSlot.run(...s);
    }

    // 4. Institution settings
    const insertSetting = db.prepare('INSERT INTO institution_settings (key, value_json) VALUES (?, ?)');
    insertSetting.run(
      'academic_term',
      JSON.stringify({
        institutionName: 'Westbridge Institute of Technology',
        academicYear: '2026–2027',
        semesterLabel: 'Fall Semester',
        workingDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
        defaultSolverMaxNodes: 150000,
        defaultSolverTimeoutMs: 12000,
      })
    );

    // 5. Faculty (10 members)
    const insertFaculty = db.prepare(
      'INSERT INTO faculty (faculty_code, full_name, email, department_id, max_weekly_hours, available_days_json) VALUES (?, ?, ?, ?, ?, ?)'
    );
    const allDays = JSON.stringify(['Mon', 'Tue', 'Wed', 'Thu', 'Fri']);
    const monThu = JSON.stringify(['Mon', 'Tue', 'Wed', 'Thu']);
    const tueFri = JSON.stringify(['Tue', 'Wed', 'Thu', 'Fri']);

    const f1 = Number(insertFaculty.run('FAC-101', 'Dr. Alan Mercer', 'a.mercer@classclockwork.edu', csDeptId, 16, allDays).lastInsertRowid);
    const f2 = Number(insertFaculty.run('FAC-102', 'Prof. Clara Lin', 'c.lin@classclockwork.edu', csDeptId, 18, allDays).lastInsertRowid);
    const f3 = Number(insertFaculty.run('FAC-103', 'Dr. Mateo Alvarez', 'm.alvarez@classclockwork.edu', csDeptId, 16, allDays).lastInsertRowid);
    const f4 = Number(insertFaculty.run('FAC-104', 'Dr. Priya Nair', 'p.nair@classclockwork.edu', eceDeptId, 18, allDays).lastInsertRowid);
    const f5 = Number(insertFaculty.run('FAC-105', 'Prof. Victor Thorne', 'v.thorne@classclockwork.edu', eceDeptId, 16, monThu).lastInsertRowid);
    const f6 = Number(insertFaculty.run('FAC-106', 'Dr. Henrik Lindqvist', 'h.lindqvist@classclockwork.edu', mathDeptId, 18, allDays).lastInsertRowid);
    const f7 = Number(insertFaculty.run('FAC-107', 'Prof. Nadia Petrov', 'n.petrov@classclockwork.edu', mathDeptId, 16, tueFri).lastInsertRowid);
    const f8 = Number(insertFaculty.run('FAC-108', 'Dr. Samuel Okafor', 's.okafor@classclockwork.edu', mechDeptId, 18, allDays).lastInsertRowid);
    const f9 = Number(insertFaculty.run('FAC-109', 'Prof. Mei-Ling Zhou', 'm.zhou@classclockwork.edu', csDeptId, 16, allDays).lastInsertRowid);
    const f10 = Number(insertFaculty.run('FAC-110', 'Dr. Arthur Pendelton', 'a.pendelton@classclockwork.edu', mechDeptId, 14, allDays).lastInsertRowid);

    // Faculty availability preferences & unavailabilities
    const insertAvail = db.prepare(
      'INSERT INTO faculty_availability (faculty_id, day_of_week, period_number, status) VALUES (?, ?, ?, ?)'
    );
    insertAvail.run(f1, 'Mon', 1, 'preferred');
    insertAvail.run(f1, 'Wed', 2, 'preferred');
    insertAvail.run(f1, 'Fri', 8, 'unavailable');
    insertAvail.run(f2, 'Tue', 2, 'preferred');
    insertAvail.run(f2, 'Thu', 3, 'preferred');
    insertAvail.run(f3, 'Mon', 8, 'unavailable');
    insertAvail.run(f4, 'Wed', 1, 'preferred');
    insertAvail.run(f6, 'Mon', 2, 'preferred');
    insertAvail.run(f6, 'Thu', 1, 'preferred');
    insertAvail.run(f8, 'Fri', 7, 'unavailable');

    // 6. Batches (6 student batches across 4 departments)
    const insertBatch = db.prepare(
      'INSERT INTO batches (batch_code, name, department_id, semester, student_strength) VALUES (?, ?, ?, ?, ?)'
    );
    const b1 = Number(insertBatch.run('CSE-3A', 'CSE Year 2 · Section A', csDeptId, 3, 58).lastInsertRowid);
    const b2 = Number(insertBatch.run('CSE-5A', 'CSE Year 3 · Section A', csDeptId, 5, 54).lastInsertRowid);
    const b3 = Number(insertBatch.run('ECE-3A', 'ECE Year 2 · Section A', eceDeptId, 3, 52).lastInsertRowid);
    const b4 = Number(insertBatch.run('ECE-5A', 'ECE Year 3 · Section A', eceDeptId, 5, 46).lastInsertRowid);
    const b5 = Number(insertBatch.run('MECH-3A', 'MECH Year 2 · Section A', mechDeptId, 3, 48).lastInsertRowid);
    const b6 = Number(insertBatch.run('CSE-1A', 'CSE Year 1 · Section A', csDeptId, 1, 62).lastInsertRowid);

    // 7. Rooms (8 classrooms, labs, and seminar rooms)
    const insertRoom = db.prepare(
      'INSERT INTO rooms (room_code, name, room_type, capacity, equipment_json, is_available) VALUES (?, ?, ?, ?, ?, ?)'
    );
    insertRoom.run('LH-101', 'North Lecture Hall 101', 'lecture', 75, JSON.stringify(['Projector', 'Smartboard', 'Audio System']), 1);
    insertRoom.run('LH-102', 'North Lecture Hall 102', 'lecture', 70, JSON.stringify(['Projector', 'Whiteboard']), 1);
    insertRoom.run('LH-201', 'Engineering Wing 201', 'lecture', 65, JSON.stringify(['Projector', 'Smartboard']), 1);
    insertRoom.run('LH-202', 'Engineering Wing 202', 'lecture', 60, JSON.stringify(['Projector', 'Whiteboard']), 1);
    insertRoom.run('CSL-1', 'Systems & AI Lab 1', 'lab', 64, JSON.stringify(['Workstations', 'Projector', 'Linux Cluster']), 1);
    insertRoom.run('ECL-1', 'VLSI & Embedded Lab', 'lab', 56, JSON.stringify(['Oscilloscopes', 'FPGA Kits', 'Projector']), 1);
    insertRoom.run('MEL-1', 'CAD & Thermo Lab', 'lab', 55, JSON.stringify(['CAD Workstations', 'Projector']), 1);
    insertRoom.run('SEM-301', 'Graduate Seminar 301', 'seminar', 65, JSON.stringify(['Projector', 'Conference Audio']), 1);

    // 8. Subjects (18 realistic courses)
    const insertSubject = db.prepare(
      `INSERT INTO subjects (
        subject_code, name, department_id, semester, batch_id, faculty_id,
        weekly_sessions, session_duration, student_count, required_room_type, credits, color_hex
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    const insertEquip = db.prepare('INSERT INTO subject_requirements (subject_id, equipment_name) VALUES (?, ?)');

    const subjectsSeed: Array<{
      code: string;
      name: string;
      deptId: number;
      sem: number;
      batchId: number;
      facId: number;
      sessions: number;
      duration: number;
      count: number;
      roomType: 'lecture' | 'lab' | 'seminar';
      credits: number;
      color: string;
      equip: string[];
    }> = [
      { code: 'CS301', name: 'Data Structures & Algorithms', deptId: csDeptId, sem: 3, batchId: b1, facId: f1, sessions: 3, duration: 1, count: 58, roomType: 'lecture', credits: 4, color: '#3730a3', equip: ['Projector'] },
      { code: 'CS302', name: 'Algorithms Laboratory', deptId: csDeptId, sem: 3, batchId: b1, facId: f1, sessions: 1, duration: 2, count: 58, roomType: 'lab', credits: 2, color: '#4338ca', equip: ['Workstations'] },
      { code: 'CS303', name: 'Computer Organization', deptId: csDeptId, sem: 3, batchId: b1, facId: f2, sessions: 3, duration: 1, count: 58, roomType: 'lecture', credits: 3, color: '#0f766e', equip: ['Projector'] },
      { code: 'MA301', name: 'Discrete Mathematics', deptId: mathDeptId, sem: 3, batchId: b1, facId: f6, sessions: 3, duration: 1, count: 58, roomType: 'lecture', credits: 4, color: '#7c2d12', equip: ['Projector'] },

      { code: 'CS501', name: 'Operating Systems', deptId: csDeptId, sem: 5, batchId: b2, facId: f3, sessions: 3, duration: 1, count: 54, roomType: 'lecture', credits: 4, color: '#1d4ed8', equip: ['Projector'] },
      { code: 'CS502', name: 'Database Management Systems', deptId: csDeptId, sem: 5, batchId: b2, facId: f9, sessions: 3, duration: 1, count: 54, roomType: 'lecture', credits: 4, color: '#0369a1', equip: ['Projector'] },
      { code: 'CS503', name: 'Systems Programming Lab', deptId: csDeptId, sem: 5, batchId: b2, facId: f3, sessions: 1, duration: 2, count: 54, roomType: 'lab', credits: 2, color: '#4f46e5', equip: ['Workstations', 'Linux Cluster'] },
      { code: 'CS504', name: 'Software Engineering Seminar', deptId: csDeptId, sem: 5, batchId: b2, facId: f9, sessions: 2, duration: 1, count: 54, roomType: 'seminar', credits: 2, color: '#6d28d9', equip: ['Projector'] },

      { code: 'EC301', name: 'Signals & Systems', deptId: eceDeptId, sem: 3, batchId: b3, facId: f4, sessions: 3, duration: 1, count: 52, roomType: 'lecture', credits: 4, color: '#be123c', equip: ['Projector'] },
      { code: 'EC302', name: 'Digital Logic Design', deptId: eceDeptId, sem: 3, batchId: b3, facId: f5, sessions: 3, duration: 1, count: 52, roomType: 'lecture', credits: 3, color: '#b45309', equip: ['Projector'] },
      { code: 'EC303', name: 'Digital Electronics Lab', deptId: eceDeptId, sem: 3, batchId: b3, facId: f5, sessions: 1, duration: 2, count: 52, roomType: 'lab', credits: 2, color: '#9f1239', equip: ['Oscilloscopes', 'FPGA Kits'] },

      { code: 'EC501', name: 'VLSI Architecture', deptId: eceDeptId, sem: 5, batchId: b4, facId: f4, sessions: 3, duration: 1, count: 46, roomType: 'lecture', credits: 4, color: '#047857', equip: ['Projector'] },
      { code: 'EC502', name: 'Embedded Systems Lab', deptId: eceDeptId, sem: 5, batchId: b4, facId: f4, sessions: 1, duration: 2, count: 46, roomType: 'lab', credits: 2, color: '#065f46', equip: ['FPGA Kits'] },

      { code: 'ME301', name: 'Engineering Thermodynamics', deptId: mechDeptId, sem: 3, batchId: b5, facId: f8, sessions: 3, duration: 1, count: 48, roomType: 'lecture', credits: 4, color: '#334155', equip: ['Projector'] },
      { code: 'ME302', name: 'Fluid Mechanics', deptId: mechDeptId, sem: 3, batchId: b5, facId: f10, sessions: 3, duration: 1, count: 48, roomType: 'lecture', credits: 3, color: '#475569', equip: ['Projector'] },
      { code: 'ME303', name: 'CAD Modeling Studio', deptId: mechDeptId, sem: 3, batchId: b5, facId: f8, sessions: 1, duration: 2, count: 48, roomType: 'lab', credits: 2, color: '#1e293b', equip: ['CAD Workstations'] },

      { code: 'CS101', name: 'Foundations of Computing', deptId: csDeptId, sem: 1, batchId: b6, facId: f2, sessions: 3, duration: 1, count: 62, roomType: 'lecture', credits: 4, color: '#2563eb', equip: ['Projector'] },
      { code: 'MA101', name: 'Linear Algebra & Calculus', deptId: mathDeptId, sem: 1, batchId: b6, facId: f7, sessions: 3, duration: 1, count: 62, roomType: 'lecture', credits: 4, color: '#9333ea', equip: ['Projector'] },
    ];

    for (const sub of subjectsSeed) {
      const subId = Number(
        insertSubject.run(
          sub.code,
          sub.name,
          sub.deptId,
          sub.sem,
          sub.batchId,
          sub.facId,
          sub.sessions,
          sub.duration,
          sub.count,
          sub.roomType,
          sub.credits,
          sub.color
        ).lastInsertRowid
      );
      for (const eq of sub.equip) {
        insertEquip.run(subId, eq);
      }
    }

    // 9. Generate initial valid published timetable using the real CSP engine
    const dbSubjects = db.prepare('SELECT * FROM subjects').all() as Array<Record<string, unknown>>;
    const dbFaculty = db.prepare('SELECT * FROM faculty').all() as Array<Record<string, unknown>>;
    const dbAvail = db.prepare('SELECT * FROM faculty_availability').all() as Array<{
      faculty_id: number;
      day_of_week: DayOfWeek;
      period_number: number;
      status: 'unavailable' | 'preferred';
    }>;
    const dbBatches = db.prepare('SELECT * FROM batches').all() as Array<Record<string, unknown>>;
    const dbRooms = db.prepare('SELECT * FROM rooms').all() as Array<Record<string, unknown>>;
    const dbSlots = db.prepare('SELECT * FROM time_slots ORDER BY period_number ASC').all() as Array<Record<string, unknown>>;
    const dbReqs = db.prepare('SELECT * FROM subject_requirements').all() as Array<{ subject_id: number; equipment_name: string }>;

    const reqMap = new Map<number, string[]>();
    for (const r of dbReqs) {
      const arr = reqMap.get(r.subject_id) ?? [];
      arr.push(r.equipment_name);
      reqMap.set(r.subject_id, arr);
    }

    const cspSubjects: CspSubject[] = dbSubjects.map((s) => ({
      id: Number(s.id),
      subjectCode: String(s.subject_code),
      name: String(s.name),
      departmentId: Number(s.department_id),
      semester: Number(s.semester),
      batchId: Number(s.batch_id),
      facultyId: s.faculty_id === null ? null : Number(s.faculty_id),
      weeklySessions: Number(s.weekly_sessions),
      sessionDuration: Number(s.session_duration),
      studentCount: Number(s.student_count),
      requiredRoomType: s.required_room_type as CspSubject['requiredRoomType'],
      requiredEquipment: reqMap.get(Number(s.id)) ?? [],
      credits: Number(s.credits),
      colorHex: String(s.color_hex),
    }));

    const cspFaculty: CspFaculty[] = dbFaculty.map((f) => {
      const fAvail = dbAvail.filter((a) => a.faculty_id === Number(f.id));
      return {
        id: Number(f.id),
        facultyCode: String(f.faculty_code),
        fullName: String(f.full_name),
        departmentId: Number(f.department_id),
        maxWeeklyHours: Number(f.max_weekly_hours),
        availableDays: JSON.parse(String(f.available_days_json)) as DayOfWeek[],
        preferredHours: fAvail.filter((a) => a.status === 'preferred').map((a) => ({ day: a.day_of_week, periodNumber: a.period_number })),
        unavailableSlots: fAvail.filter((a) => a.status === 'unavailable').map((a) => ({ day: a.day_of_week, periodNumber: a.period_number })),
      };
    });

    const cspBatches: CspBatch[] = dbBatches.map((b) => ({
      id: Number(b.id),
      batchCode: String(b.batch_code),
      name: String(b.name),
      departmentId: Number(b.department_id),
      semester: Number(b.semester),
      studentStrength: Number(b.student_strength),
    }));

    const cspRooms: CspRoom[] = dbRooms.map((r) => ({
      id: Number(r.id),
      roomCode: String(r.room_code),
      name: String(r.name),
      roomType: r.room_type as CspRoom['roomType'],
      capacity: Number(r.capacity),
      equipment: JSON.parse(String(r.equipment_json)) as string[],
      isAvailable: Boolean(r.is_available),
    }));

    const cspSlots: CspTimeSlot[] = dbSlots.map((t) => ({
      periodNumber: Number(t.period_number),
      label: String(t.label),
      startTime: String(t.start_time),
      endTime: String(t.end_time),
      isLunchBreak: Boolean(t.is_lunch_break),
    }));

    const solverResult = solveTimetableCsp({
      subjects: cspSubjects,
      faculty: cspFaculty,
      batches: cspBatches,
      rooms: cspRooms,
      timeSlots: cspSlots,
    });

    const runInfo = db
      .prepare(
        `INSERT INTO scheduling_runs (
          status, is_published, total_meetings, scheduled_meetings, unscheduled_meetings,
          hard_conflicts_count, optimization_score, nodes_explored, duration_ms, config_json, unscheduled_json, created_by
        ) VALUES (?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        solverResult.status,
        solverResult.totalMeetings,
        solverResult.scheduledMeetings,
        solverResult.unscheduledMeetings.length,
        solverResult.validation.hardViolations.length,
        solverResult.optimizationScore,
        solverResult.nodesExplored,
        solverResult.durationMs,
        JSON.stringify({ seedRun: true }),
        JSON.stringify(solverResult.unscheduledMeetings),
        Number(adminInfo.lastInsertRowid)
      );

    const runId = Number(runInfo.lastInsertRowid);
    const insertAlloc = db.prepare(
      `INSERT INTO timetable_allocations (
        run_id, subject_id, faculty_id, batch_id, room_id, day_of_week, start_period, duration_periods, session_index
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    for (const a of solverResult.allocations) {
      insertAlloc.run(
        runId,
        a.subjectId,
        a.facultyId,
        a.batchId,
        a.roomId,
        a.day,
        a.startPeriod,
        a.durationPeriods,
        a.sessionIndex
      );
    }

    const insertLog = db.prepare(
      'INSERT INTO scheduling_logs (run_id, level, message, details_json) VALUES (?, ?, ?, ?)'
    );
    for (const log of solverResult.logs) {
      insertLog.run(runId, log.level, log.message, null);
    }
  });

  tx();
  logger.info('Database seeded successfully with academic data and initial CSP timetable');
  return { seeded: true };
}
