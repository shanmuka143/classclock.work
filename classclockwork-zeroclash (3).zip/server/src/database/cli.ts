import { closeDb, getDb } from './connection.ts';
import { runMigrations } from './migrations/runner.ts';
import { bootstrapAdmin, bootstrapEvaluator, seedDatabase } from './seeds/seedData.ts';
import { DatabaseMaintenanceService } from '../services/databaseMaintenanceService.ts';

async function main() {
  const cmd = process.argv[2] ?? 'migrate';
  const db = getDb();

  try {
    if (cmd === 'migrate') {
      const applied = runMigrations(db);
      console.log(JSON.stringify({ ok: true, command: 'migrate', applied }));
    } else if (cmd === 'seed') {
      runMigrations(db);
      const result = seedDatabase(db);
      console.log(JSON.stringify({ ok: true, command: 'seed', ...result }));
    } else if (cmd === 'bootstrap-admin') {
      runMigrations(db);
      const password = process.env.BOOTSTRAP_ADMIN_PASSWORD ?? '';
      const result = bootstrapAdmin(db, { password });
      console.log(JSON.stringify({ ok: true, command: 'bootstrap-admin', ...result }));
    } else if (cmd === 'bootstrap-evaluator') {
      runMigrations(db);
      const result = bootstrapEvaluator(db);
      console.log(
        JSON.stringify({
          ok: true,
          command: 'bootstrap-evaluator',
          role: 'evaluator',
          created: result.created,
          username: result.username,
          temporaryPassword: result.password,
          note: 'Share securely with the project evaluator; rotate or re-run bootstrap-evaluator after evaluation.',
        })
      );
    } else if (cmd === 'integrity') {
      runMigrations(db);
      const report = new DatabaseMaintenanceService(db).checkIntegrity();
      console.log(JSON.stringify({ ok: report.integrityOk, command: 'integrity', ...report }));
      if (!report.integrityOk) process.exitCode = 1;
    } else if (cmd === 'backup') {
      runMigrations(db);
      const backup = await new DatabaseMaintenanceService(db).createBackup();
      console.log(JSON.stringify({ ok: backup.integrityOk, command: 'backup', ...backup }));
    } else {
      console.error(`Unknown database CLI command: ${cmd}`);
      process.exitCode = 1;
    }
  } finally {
    closeDb();
  }
}

main().catch((err) => {
  console.error(err instanceof Error ? err.message : String(err));
  process.exit(1);
});
