import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    globals: true,
    include: ['tests/unit/**/*.test.ts', 'tests/integration/**/*.test.ts', 'tests/frontend/**/*.test.tsx'],
    exclude: ['tests/e2e/**', 'node_modules/**', 'dist/**'],
    environment: 'node',
    setupFiles: ['./tests/setup.ts'],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'json-summary', 'html'],
      include: ['shared/csp/**/*.ts', 'server/src/**/*.ts', 'src/services/exportService.ts'],
      exclude: ['server/src/database/cli.ts', 'server/src/config/logger.ts'],
    },
  },
});
