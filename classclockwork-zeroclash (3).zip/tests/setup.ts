import '@testing-library/jest-dom/vitest';
process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = 'test_jwt_secret_key_for_vitest_suite_32chars';
