// @vitest-environment jsdom
import React from 'react';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { TimetableGrid } from '../../src/components/Timetable/TimetableGrid.tsx';
import { AuthProvider } from '../../src/context/AuthContext.tsx';
import { ToastProvider } from '../../src/context/ToastContext.tsx';
import { DashboardPage } from '../../src/pages/DashboardPage.tsx';
import { FacultyPage } from '../../src/pages/FacultyPage.tsx';
import { GeneratorPage } from '../../src/pages/GeneratorPage.tsx';
import { LoginPage } from '../../src/pages/LoginPage.tsx';
import { SettingsPage } from '../../src/pages/SettingsPage.tsx';
import type { CspTimeSlot } from '../../shared/csp/types.ts';
import type { TimetableAllocationDto } from '../../src/types/api.ts';

afterEach(() => {
  vi.restoreAllMocks();
});

describe('Frontend Component Tests', () => {
  it('renders clean LoginPage with zero hardcoded passwords and validates login errors', async () => {
    vi.spyOn(globalThis, 'fetch').mockImplementation(async (input) => {
      const url = typeof input === 'string' ? input : input.toString();
      if (url.endsWith('/auth/me')) {
        return new Response(JSON.stringify({ ok: false, error: { code: 'UNAUTHORIZED', message: 'Not signed in' } }), {
          status: 401,
          headers: { 'Content-Type': 'application/json' },
        });
      }
      return new Response(
        JSON.stringify({ ok: false, error: { code: 'INVALID_CREDENTIALS', message: 'Invalid username or password.' } }),
        { status: 401, headers: { 'Content-Type': 'application/json' } }
      );
    });

    render(
      <MemoryRouter>
        <AuthProvider>
          <ToastProvider>
            <LoginPage />
          </ToastProvider>
        </AuthProvider>
      </MemoryRouter>
    );

    expect(await screen.findByText(/Academic Console Sign In/i)).toBeInTheDocument();
    expect(screen.queryByText(/Admin@2026/i)).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /Fill Credentials/i })).not.toBeInTheDocument();

    const submitBtn = screen.getByRole('button', { name: /Sign In to Console/i });
    fireEvent.click(submitBtn);
    expect(await screen.findByText(/Please enter both username and password/i)).toBeInTheDocument();

    fireEvent.change(screen.getByLabelText(/Username or Institutional Email/i), { target: { value: 'admin' } });
    fireEvent.change(screen.getByLabelText(/Password/i), { target: { value: 'wrongpass' } });
    fireEvent.click(submitBtn);
    expect(await screen.findByText(/Invalid username or password/i)).toBeInTheDocument();
  });

  it('loads and renders real Dashboard statistics', async () => {
    const fetchMock = vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce(
      new Response(
        JSON.stringify({
          ok: true,
          data: {
            counts: {
              departments: 4,
              faculty: 10,
              subjects: 18,
              batches: 6,
              rooms: 8,
              classrooms: 5,
              labs: 3,
              scheduledClasses: 44,
              unscheduledClasses: 0,
              totalRequiredMeetings: 44,
              detectedConflicts: 0,
            },
            latestRun: {
              id: 1,
              status: 'optimal',
              isPublished: true,
              optimizationScore: 91.2,
              nodesExplored: 120,
              durationMs: 14,
              createdAt: '2026-11-20T08:00:00Z',
            },
            facultyWorkload: [
              {
                id: 1,
                facultyCode: 'FAC-101',
                fullName: 'Dr. Alan Mercer',
                departmentCode: 'CSE',
                scheduledHours: 10,
                maxWeeklyHours: 16,
                utilizationPct: 63,
              },
            ],
            recentLogs: [{ id: 1, level: 'info', message: 'CSP completed (optimal)', createdAt: '2026-11-20' }],
          },
        }),
        { status: 200, headers: { 'Content-Type': 'application/json' } }
      )
    );

    render(
      <MemoryRouter>
        <DashboardPage />
      </MemoryRouter>
    );

    expect(await screen.findByText(/Current Timetable is Hard-Constraint Valid/i)).toBeInTheDocument();
    expect(screen.getByText(/Dr\. Alan Mercer/i)).toBeInTheDocument();
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it('renders TimetableGrid and triggers drag-and-drop move callback', async () => {
    const slots: CspTimeSlot[] = [
      { periodNumber: 1, label: 'Period 1', startTime: '08:30', endTime: '09:30', isLunchBreak: false },
      { periodNumber: 2, label: 'Period 2', startTime: '09:30', endTime: '10:30', isLunchBreak: false },
      { periodNumber: 4, label: 'Lunch Break', startTime: '11:45', endTime: '12:45', isLunchBreak: true },
    ];
    const allocations: TimetableAllocationDto[] = [
      {
        id: 77,
        runId: 1,
        subjectId: 1,
        facultyId: 1,
        batchId: 1,
        roomId: 1,
        day: 'Mon',
        startPeriod: 1,
        durationPeriods: 1,
        sessionIndex: 1,
        isLocked: false,
        subjectCode: 'CS301',
        subjectName: 'Data Structures',
        colorHex: '#3730a3',
        requiredRoomType: 'lecture',
        facultyName: 'Dr. Alan Mercer',
        facultyCode: 'FAC-101',
        batchCode: 'CSE-3A',
        batchName: 'CSE Year 2',
        roomCode: 'LH-101',
        roomName: 'North Hall',
        departmentCode: 'CSE',
      },
    ];

    const onMove = vi.fn().mockResolvedValue(undefined);
    const onSelect = vi.fn();

    render(
      <TimetableGrid
        allocations={allocations}
        timeSlots={slots}
        onMoveAllocation={onMove}
        onSelectAllocation={onSelect}
      />
    );

    expect(screen.getByText('CS301')).toBeInTheDocument();
    expect(screen.getByText(/Protected Lunch Period/i)).toBeInTheDocument();

    const card = screen.getByTestId('alloc-CS301-s1');
    const targetCell = screen.getByTestId('cell-Tue-P2');

    const dataTransfer = {
      data: {} as Record<string, string>,
      setData(key: string, val: string) {
        this.data[key] = val;
      },
      getData(key: string) {
        return this.data[key] ?? '';
      },
      effectAllowed: 'move',
      dropEffect: 'move',
    };

    fireEvent.dragStart(card, { dataTransfer });
    fireEvent.dragOver(targetCell, { dataTransfer });
    fireEvent.drop(targetCell, { dataTransfer });

    await waitFor(() => {
      expect(onMove).toHaveBeenCalledWith(77, 'Tue', 2);
    });
  });

  it('renders GeneratorPage accessible controls and executes generation with backtracks and roomFit metrics', async () => {
    vi.spyOn(globalThis, 'fetch').mockImplementation(async (input) => {
      const url = typeof input === 'string' ? input : input.toString();
      if (url.includes('/timetable/solver-payload')) {
        return new Response(
          JSON.stringify({
            ok: true,
            data: { subjects: [], faculty: [], batches: [], rooms: [], timeSlots: [], lockedAllocations: [] },
          }),
          { status: 200, headers: { 'Content-Type': 'application/json' } }
        );
      }
      if (url.endsWith('/timetable/generate')) {
        return new Response(
          JSON.stringify({
            ok: true,
            data: {
              run: {
                id: 5,
                status: 'optimal',
                isPublished: true,
                totalMeetings: 10,
                scheduledMeetings: 10,
                unscheduledMeetings: 0,
                hardConflictsCount: 0,
                optimizationScore: 93.4,
                nodesExplored: 25,
                durationMs: 12,
                config: {},
                unscheduledList: [],
                createdBy: 1,
                createdAt: '2026-11-20',
              },
              result: {
                status: 'optimal',
                allocations: [],
                totalMeetings: 10,
                scheduledMeetings: 10,
                unscheduledMeetings: [],
                nodesExplored: 25,
                backtracksCount: 2,
                durationMs: 12,
                optimizationScore: 93.4,
                logs: [],
                validation: {
                  isValid: true,
                  hardViolations: [],
                  softMetrics: {
                    preferenceMatchRate: 90,
                    subjectSpreadRate: 95,
                    consecutivePenaltyCount: 0,
                    batchGapCount: 0,
                    dailyBalanceScore: 96,
                    roomFitScore: 92,
                    overallScore: 93.4,
                  },
                },
              },
            },
          }),
          { status: 201, headers: { 'Content-Type': 'application/json' } }
        );
      }
      return new Response(JSON.stringify({ ok: true, data: {} }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      });
    });

    render(
      <MemoryRouter>
        <ToastProvider>
          <GeneratorPage />
        </ToastProvider>
      </MemoryRouter>
    );

    expect(screen.getByLabelText(/Max Search Nodes/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Timeout \(ms\)/i)).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: /Generate Timetable/i }));

    expect(await screen.findByText(/Generation Complete — OPTIMAL/i)).toBeInTheDocument();
    expect(screen.getByText(/Room Capacity Fit/i)).toBeInTheDocument();
    expect(screen.getByText('92%')).toBeInTheDocument();
  });

  it('renders SettingsPage Admin Audit/Integrity controls for admin and read-only guard for evaluator', async () => {
    const settingsData = {
      academicTerm: {
        institutionName: 'Westbridge Institute',
        academicYear: '2026–2027',
        semesterLabel: 'Fall',
        workingDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
        defaultSolverMaxNodes: 150000,
        defaultSolverTimeoutMs: 12000,
      },
      timeSlots: [{ periodNumber: 1, label: 'P1', startTime: '08:30', endTime: '09:30', isLunchBreak: false }],
      departments: [{ id: 1, code: 'CSE', name: 'Computer Science', headName: 'Dr. Mercer' }],
    };

    // Case 1: Admin sees Integrity, Backup & Audit Logs
    vi.spyOn(globalThis, 'fetch').mockImplementation(async (input) => {
      const url = typeof input === 'string' ? input : input.toString();
      if (url.endsWith('/auth/me')) {
        return new Response(
          JSON.stringify({ ok: true, data: { user: { id: 1, username: 'admin', email: 'a@e.edu', fullName: 'Admin', role: 'admin' } } }),
          { status: 200, headers: { 'Content-Type': 'application/json' } }
        );
      }
      if (url.endsWith('/settings')) {
        return new Response(JSON.stringify({ ok: true, data: settingsData }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' },
        });
      }
      if (url.includes('/audit-logs')) {
        return new Response(
          JSON.stringify({
            ok: true,
            data: {
              items: [
                {
                  id: 1,
                  actorUserId: 1,
                  actorUsername: 'admin',
                  action: 'AUTH_LOGIN',
                  entityType: 'session',
                  entityId: 'jti-1',
                  status: 'success',
                  details: null,
                  ipAddress: '127.0.0.1',
                  createdAt: '2026-11-20 08:00:00',
                },
              ],
              total: 1,
              page: 1,
              limit: 10,
            },
          }),
          { status: 200, headers: { 'Content-Type': 'application/json' } }
        );
      }
      if (url.endsWith('/system/integrity')) {
        return new Response(
          JSON.stringify({
            ok: true,
            data: {
              integrityOk: true,
              integrityMessages: ['ok'],
              foreignKeyViolationsCount: 0,
              journalMode: 'wal',
              tableCounts: { subjects: 18 },
              checkedAt: '2026-11-20T08:05:00Z',
            },
          }),
          { status: 200, headers: { 'Content-Type': 'application/json' } }
        );
      }
      return new Response(JSON.stringify({ ok: true, data: {} }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      });
    });

    const { unmount } = render(
      <MemoryRouter>
        <AuthProvider>
          <ToastProvider>
            <SettingsPage />
          </ToastProvider>
        </AuthProvider>
      </MemoryRouter>
    );

    expect(await screen.findByText(/SQLite Reliability & Verified Backup/i)).toBeInTheDocument();
    expect(await screen.findByText('AUTH_LOGIN')).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: /Run Integrity Check/i }));
    expect(await screen.findByText(/Integrity: OK/i)).toBeInTheDocument();

    unmount();
    vi.restoreAllMocks();

    // Case 2: Evaluator sees read-only administrator banner and no audit/backup buttons
    vi.spyOn(globalThis, 'fetch').mockImplementation(async (input) => {
      const url = typeof input === 'string' ? input : input.toString();
      if (url.endsWith('/auth/me')) {
        return new Response(
          JSON.stringify({
            ok: true,
            data: { user: { id: 3, username: 'evaluator', email: 'e@e.edu', fullName: 'Eval', role: 'evaluator' } },
          }),
          { status: 200, headers: { 'Content-Type': 'application/json' } }
        );
      }
      return new Response(JSON.stringify({ ok: true, data: settingsData }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      });
    });

    render(
      <MemoryRouter>
        <AuthProvider>
          <ToastProvider>
            <SettingsPage />
          </ToastProvider>
        </AuthProvider>
      </MemoryRouter>
    );

    expect(await screen.findByText(/Administrator-Only Configuration:/i)).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /Run Integrity Check/i })).not.toBeInTheDocument();
  });

  it('exposes accessible modal form labels on FacultyPage', async () => {
    vi.spyOn(globalThis, 'fetch').mockImplementation(async (input) => {
      const url = typeof input === 'string' ? input : input.toString();
      if (url.endsWith('/faculty')) {
        return new Response(JSON.stringify({ ok: true, data: [] }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' },
        });
      }
      return new Response(
        JSON.stringify({
          ok: true,
          data: {
            academicTerm: {
              institutionName: 'Westbridge',
              academicYear: '2026',
              semesterLabel: 'Fall',
              workingDays: ['Mon'],
              defaultSolverMaxNodes: 1000,
              defaultSolverTimeoutMs: 5000,
            },
            timeSlots: [{ periodNumber: 1, label: 'P1', startTime: '08:30', endTime: '09:30', isLunchBreak: false }],
            departments: [{ id: 1, code: 'CSE', name: 'Computer Science', headName: null }],
          },
        }),
        { status: 200, headers: { 'Content-Type': 'application/json' } }
      );
    });

    render(
      <MemoryRouter>
        <ToastProvider>
          <FacultyPage />
        </ToastProvider>
      </MemoryRouter>
    );

    const addBtn = await screen.findByRole('button', { name: /Add Faculty Member/i });
    fireEvent.click(addBtn);
    expect(screen.getByLabelText(/Faculty Code/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Full Name/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Max Weekly Teaching Hours/i)).toBeInTheDocument();
  });

  it('renders AnalyticsPage with Room Fit and Workload Fairness metrics', async () => {
    const { AnalyticsPage } = await import('../../src/pages/AnalyticsPage.tsx');
    vi.spyOn(globalThis, 'fetch').mockImplementation(async (input) => {
      const url = typeof input === 'string' ? input : input.toString();
      if (url.endsWith('/analytics/workload')) {
        return new Response(
          JSON.stringify({
            ok: true,
            data: {
              fairnessScore: 94,
              avgUtilization: 72,
              distribution: [
                {
                  facultyId: 1,
                  facultyCode: 'FAC-101',
                  fullName: 'Dr. Alan Mercer',
                  departmentCode: 'CSE',
                  assignedHours: 12,
                  maxWeeklyHours: 16,
                  sessions: 10,
                  utilizationRate: 75,
                  status: 'optimal',
                },
              ],
            },
          }),
          { status: 200, headers: { 'Content-Type': 'application/json' } }
        );
      }
      if (url.endsWith('/analytics/room-utilization')) {
        return new Response(
          JSON.stringify({
            ok: true,
            data: {
              totalWeeklyAvailablePeriods: 35,
              rooms: [
                {
                  roomId: 1,
                  roomCode: 'LH-101',
                  name: 'North Hall',
                  roomType: 'lecture',
                  capacity: 75,
                  isAvailable: true,
                  usedPeriods: 20,
                  availablePeriods: 35,
                  sessionsCount: 20,
                  utilizationPct: 57,
                },
              ],
            },
          }),
          { status: 200, headers: { 'Content-Type': 'application/json' } }
        );
      }
      return new Response(
        JSON.stringify({
          ok: true,
          data: {
            latestRun: {
              id: 1,
              status: 'optimal',
              isPublished: true,
              totalMeetings: 44,
              scheduledMeetings: 44,
              unscheduledMeetings: 0,
              hardConflictsCount: 0,
              optimizationScore: 92,
              nodesExplored: 100,
              durationMs: 10,
              config: {},
              unscheduledList: [],
              createdBy: 1,
              createdAt: '2026-11-20',
            },
            runsHistory: [],
            validationSummary: {
              isHardValid: true,
              hardViolationsCount: 0,
              softMetrics: {
                preferenceMatchRate: 85,
                subjectSpreadRate: 95,
                consecutivePenaltyCount: 0,
                batchGapCount: 1,
                dailyBalanceScore: 92,
                roomFitScore: 88,
                overallScore: 91,
              },
            },
            dailyDistribution: [{ day: 'Mon', meetings: 9, periods: 10, labs: 1 }],
            departmentStats: [
              {
                departmentId: 1,
                code: 'CSE',
                name: 'Computer Science',
                subjectCount: 8,
                requiredMeetings: 20,
                scheduledMeetings: 20,
                completionPct: 100,
              },
            ],
          },
        }),
        { status: 200, headers: { 'Content-Type': 'application/json' } }
      );
    });

    render(
      <MemoryRouter>
        <ToastProvider>
          <AnalyticsPage />
        </ToastProvider>
      </MemoryRouter>
    );

    expect(await screen.findByText(/Valid \(0 Clashes\)/i)).toBeInTheDocument();
    expect(screen.getByText('94%')).toBeInTheDocument();
    expect(screen.getByText('88%')).toBeInTheDocument();
  });

  it('renders ConflictsPage violations and supports Escape key dismissal on Modal', async () => {
    const { ConflictsPage } = await import('../../src/pages/ConflictsPage.tsx');
    const { Modal } = await import('../../src/components/UI/Modal.tsx');

    vi.spyOn(globalThis, 'fetch').mockResolvedValue(
      new Response(
        JSON.stringify({
          ok: true,
          data: {
            run: {
              id: 3,
              status: 'partial',
              isPublished: false,
              totalMeetings: 5,
              scheduledMeetings: 4,
              unscheduledMeetings: 1,
              hardConflictsCount: 1,
              optimizationScore: 70,
              nodesExplored: 12,
              durationMs: 5,
              config: {},
              unscheduledList: [],
              createdBy: 1,
              createdAt: '2026-11-20',
            },
            runsHistory: [],
            timeSlots: [],
            allocations: [],
            allAllocationsCount: 0,
            logs: [],
            validation: {
              isValid: false,
              hardViolations: [
                { type: 'FACULTY_CLASH', message: 'Dr. Mercer double-booked on Mon P1', day: 'Mon', periodNumber: 1 },
              ],
              softMetrics: {
                preferenceMatchRate: 80,
                subjectSpreadRate: 80,
                consecutivePenaltyCount: 0,
                batchGapCount: 0,
                dailyBalanceScore: 80,
                roomFitScore: 80,
                overallScore: 80,
              },
            },
          },
        }),
        { status: 200, headers: { 'Content-Type': 'application/json' } }
      )
    );

    render(
      <MemoryRouter>
        <ToastProvider>
          <ConflictsPage />
        </ToastProvider>
      </MemoryRouter>
    );

    expect(await screen.findByText(/Dr\. Mercer double-booked on Mon P1/i)).toBeInTheDocument();

    const onClose = vi.fn();
    render(
      <Modal open={true} title="Inspect Modal" onClose={onClose}>
        <div>Modal Body</div>
      </Modal>
    );
    fireEvent.keyDown(window, { key: 'Escape' });
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it('exposes accessible labels on RoomsPage and BatchesPage modals', async () => {
    const { RoomsPage } = await import('../../src/pages/RoomsPage.tsx');
    const { BatchesPage } = await import('../../src/pages/BatchesPage.tsx');

    vi.spyOn(globalThis, 'fetch').mockImplementation(async (input) => {
      const url = typeof input === 'string' ? input : input.toString();
      if (url.endsWith('/settings')) {
        return new Response(
          JSON.stringify({
            ok: true,
            data: {
              academicTerm: {
                institutionName: 'Westbridge',
                academicYear: '2026',
                semesterLabel: 'Fall',
                workingDays: ['Mon'],
                defaultSolverMaxNodes: 1000,
                defaultSolverTimeoutMs: 5000,
              },
              timeSlots: [],
              departments: [{ id: 1, code: 'CSE', name: 'Computer Science', headName: null }],
            },
          }),
          { status: 200, headers: { 'Content-Type': 'application/json' } }
        );
      }
      return new Response(JSON.stringify({ ok: true, data: [] }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      });
    });

    const { unmount } = render(
      <MemoryRouter>
        <ToastProvider>
          <RoomsPage />
        </ToastProvider>
      </MemoryRouter>
    );

    fireEvent.click(await screen.findByRole('button', { name: /^Add Room$/i }));
    expect(screen.getByLabelText(/Room Code/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Seating Capacity/i)).toBeInTheDocument();
    unmount();

    render(
      <MemoryRouter>
        <ToastProvider>
          <BatchesPage />
        </ToastProvider>
      </MemoryRouter>
    );

    fireEvent.click(await screen.findByRole('button', { name: /Add Student Batch/i }));
    expect(screen.getByLabelText(/Batch Code/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Student Strength/i)).toBeInTheDocument();
  });
});
