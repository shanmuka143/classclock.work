import { describe, expect, it } from 'vitest';
import { validateTimetable } from '../../shared/csp/conflictDetector.ts';
import type {
  CspAllocation,
  CspBatch,
  CspFaculty,
  CspRoom,
  CspSubject,
  CspTimeSlot,
} from '../../shared/csp/types.ts';

const slots: CspTimeSlot[] = [
  { periodNumber: 1, label: 'P1', startTime: '08:30', endTime: '09:30', isLunchBreak: false },
  { periodNumber: 2, label: 'P2', startTime: '09:30', endTime: '10:30', isLunchBreak: false },
  { periodNumber: 3, label: 'Lunch', startTime: '10:30', endTime: '11:30', isLunchBreak: true },
  { periodNumber: 4, label: 'P4', startTime: '11:30', endTime: '12:30', isLunchBreak: false },
];

const faculty: CspFaculty[] = [
  {
    id: 1,
    facultyCode: 'F1',
    fullName: 'Dr. One',
    departmentId: 1,
    maxWeeklyHours: 2,
    availableDays: ['Mon', 'Tue'],
    preferredHours: [{ day: 'Mon', periodNumber: 1 }],
    unavailableSlots: [{ day: 'Tue', periodNumber: 2 }],
  },
  {
    id: 2,
    facultyCode: 'F2',
    fullName: 'Dr. Two',
    departmentId: 1,
    maxWeeklyHours: 10,
    availableDays: ['Mon', 'Tue', 'Wed'],
    preferredHours: [],
    unavailableSlots: [],
  },
];

const batches: CspBatch[] = [
  { id: 1, batchCode: 'B1', name: 'Batch 1', departmentId: 1, semester: 3, studentStrength: 50 },
  { id: 2, batchCode: 'B2', name: 'Batch 2', departmentId: 1, semester: 5, studentStrength: 30 },
];

const rooms: CspRoom[] = [
  { id: 1, roomCode: 'R1', name: 'Small Room', roomType: 'lecture', capacity: 35, equipment: ['Projector'], isAvailable: true },
  { id: 2, roomCode: 'L1', name: 'Lab Room', roomType: 'lab', capacity: 60, equipment: ['Workstations'], isAvailable: true },
  { id: 3, roomCode: 'R3', name: 'Closed Room', roomType: 'lecture', capacity: 80, equipment: ['Projector'], isAvailable: false },
  { id: 4, roomCode: 'R4', name: 'Right-Sized Hall', roomType: 'lecture', capacity: 55, equipment: ['Projector', 'Smartboard'], isAvailable: true },
];

const subjects: CspSubject[] = [
  {
    id: 1,
    subjectCode: 'S1',
    name: 'Theory',
    departmentId: 1,
    semester: 3,
    batchId: 1,
    facultyId: 1,
    weeklySessions: 2,
    sessionDuration: 1,
    studentCount: 50,
    requiredRoomType: 'lecture',
    requiredEquipment: ['Projector', 'Smartboard'],
    credits: 3,
    colorHex: '#3730a3',
  },
  {
    id: 2,
    subjectCode: 'S2',
    name: 'Other',
    departmentId: 1,
    semester: 5,
    batchId: 2,
    facultyId: 2,
    weeklySessions: 1,
    sessionDuration: 1,
    studentCount: 30,
    requiredRoomType: 'lecture',
    requiredEquipment: [],
    credits: 3,
    colorHex: '#0f766e',
  },
  {
    id: 3,
    subjectCode: 'S3',
    name: 'Unassigned Theory',
    departmentId: 1,
    semester: 5,
    batchId: 2,
    facultyId: null,
    weeklySessions: 1,
    sessionDuration: 1,
    studentCount: 30,
    requiredRoomType: 'lecture',
    requiredEquipment: [],
    credits: 2,
    colorHex: '#1d4ed8',
  },
];

describe('Independent Conflict Detector', () => {
  it('detects faculty, room, and batch collisions including multi-period overlap', () => {
    const allocations: CspAllocation[] = [
      { subjectId: 1, facultyId: 1, batchId: 1, roomId: 4, day: 'Mon', startPeriod: 1, durationPeriods: 2, sessionIndex: 1 },
      { subjectId: 2, facultyId: 1, batchId: 1, roomId: 4, day: 'Mon', startPeriod: 2, durationPeriods: 1, sessionIndex: 1 },
    ];
    const report = validateTimetable({ allocations, subjects, faculty, batches, rooms, timeSlots: slots });
    const types = report.hardViolations.map((v) => v.type);
    expect(report.isValid).toBe(false);
    expect(types).toContain('FACULTY_CLASH');
    expect(types).toContain('ROOM_CLASH');
    expect(types).toContain('BATCH_CLASH');
  });

  it('detects capacity, room type mismatch, missing equipment, and room unavailability', () => {
    const allocations: CspAllocation[] = [
      { subjectId: 1, facultyId: 1, batchId: 1, roomId: 2, day: 'Mon', startPeriod: 1, durationPeriods: 1, sessionIndex: 1 },
      { subjectId: 1, facultyId: 2, batchId: 2, roomId: 1, day: 'Tue', startPeriod: 1, durationPeriods: 1, sessionIndex: 2 },
      { subjectId: 2, facultyId: 2, batchId: 2, roomId: 3, day: 'Wed', startPeriod: 1, durationPeriods: 1, sessionIndex: 1 },
    ];
    const report = validateTimetable({ allocations, subjects, faculty, batches, rooms, timeSlots: slots });
    const types = report.hardViolations.map((v) => v.type);
    expect(types).toContain('ROOM_TYPE_MISMATCH');
    expect(types).toContain('EQUIPMENT_MISSING');
    expect(types).toContain('CAPACITY_VIOLATION');
    expect(types).toContain('ROOM_UNAVAILABLE');
  });

  it('detects faculty unavailability, weekly workload limit, lunch break, and invalid duration bounds', () => {
    const allocations: CspAllocation[] = [
      { subjectId: 2, facultyId: 1, batchId: 2, roomId: 1, day: 'Wed', startPeriod: 3, durationPeriods: 1, sessionIndex: 1 },
      { subjectId: 2, facultyId: 1, batchId: 2, roomId: 1, day: 'Tue', startPeriod: 2, durationPeriods: 4, sessionIndex: 2 },
    ];
    const report = validateTimetable({ allocations, subjects, faculty, batches, rooms, timeSlots: slots });
    const types = report.hardViolations.map((v) => v.type);
    expect(types).toContain('FACULTY_UNAVAILABLE');
    expect(types).toContain('LUNCH_BREAK_VIOLATION');
    expect(types).toContain('WORKLOAD_EXCEEDED');
    expect(types).toContain('INVALID_DURATION');
  });

  it('detects MISSING_FACULTY and DUPLICATE_SESSION hard violations', () => {
    const allocations: CspAllocation[] = [
      { subjectId: 3, facultyId: 0, batchId: 2, roomId: 1, day: 'Mon', startPeriod: 1, durationPeriods: 1, sessionIndex: 1 },
      { subjectId: 2, facultyId: 2, batchId: 2, roomId: 1, day: 'Mon', startPeriod: 2, durationPeriods: 1, sessionIndex: 1 },
      { subjectId: 2, facultyId: 2, batchId: 2, roomId: 1, day: 'Tue', startPeriod: 1, durationPeriods: 1, sessionIndex: 1 },
    ];
    const report = validateTimetable({ allocations, subjects, faculty, batches, rooms, timeSlots: slots });
    const types = report.hardViolations.map((v) => v.type);
    expect(report.isValid).toBe(false);
    expect(types).toContain('MISSING_FACULTY');
    expect(types).toContain('DUPLICATE_SESSION');
  });

  it('computes calibrated roomFitScore rewarding tighter capacity matches', () => {
    const tightFit = validateTimetable({
      allocations: [
        { subjectId: 1, facultyId: 1, batchId: 1, roomId: 4, day: 'Mon', startPeriod: 1, durationPeriods: 1, sessionIndex: 1 },
      ],
      subjects,
      faculty,
      batches,
      rooms,
      timeSlots: slots,
    });
    expect(tightFit.isValid).toBe(true);
    expect(tightFit.softMetrics.roomFitScore).toBeGreaterThanOrEqual(85);
    expect(tightFit.softMetrics.preferenceMatchRate).toBe(100);
  });
});
