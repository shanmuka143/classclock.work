import { describe, expect, it } from 'vitest';
import { validateTimetable } from '../../shared/csp/conflictDetector.ts';
import type {
  CspAllocation,
  CspBatch,
  CspFaculty,
  CspRoom,
  CspSubject,
  CspTimeSlot,
} from '../../shared/csp/types.ts';

const slots: CspTimeSlot[] = [
  { periodNumber: 1, label: 'P1', startTime: '08:30', endTime: '09:30', isLunchBreak: false },
  { periodNumber: 2, label: 'P2', startTime: '09:30', endTime: '10:30', isLunchBreak: false },
  { periodNumber: 3, label: 'P3', startTime: '10:30', endTime: '11:30', isLunchBreak: false },
  { periodNumber: 4, label: 'Lunch', startTime: '11:30', endTime: '12:30', isLunchBreak: true },
  { periodNumber: 5, label: 'P5', startTime: '12:30', endTime: '13:30', isLunchBreak: false },
];

const batches: CspBatch[] = [
  { id: 1, batchCode: 'B1', name: 'Batch 1', departmentId: 1, semester: 3, studentStrength: 40 },
];

const faculty: CspFaculty[] = [
  {
    id: 1,
    facultyCode: 'F1',
    fullName: 'Dr. Soft Metrics',
    departmentId: 1,
    maxWeeklyHours: 20,
    availableDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
    preferredHours: [
      { day: 'Mon', periodNumber: 1 },
      { day: 'Tue', periodNumber: 1 },
    ],
    unavailableSlots: [{ day: 'Fri', periodNumber: 5 }],
  },
];

const rooms: CspRoom[] = [
  { id: 1, roomCode: 'R-FIT', name: 'Exact Fit Room', roomType: 'lecture', capacity: 44, equipment: ['Projector'], isAvailable: true },
  { id: 2, roomCode: 'R-HUGE', name: 'Mega Auditorium', roomType: 'lecture', capacity: 400, equipment: ['Projector'], isAvailable: true },
];

const subjects: CspSubject[] = [
  {
    id: 1,
    subjectCode: 'CS101',
    name: 'Intro CS',
    departmentId: 1,
    semester: 3,
    batchId: 1,
    facultyId: 1,
    weeklySessions: 3,
    sessionDuration: 1,
    studentCount: 40,
    requiredRoomType: 'lecture',
    requiredEquipment: ['Projector'],
    credits: 3,
    colorHex: '#1d4ed8',
  },
];

describe('CSP Validator Soft Metrics & Edge Cases', () => {
  it('rewards spread across distinct days over clustering multiple sessions on a single day', () => {
    const spread: CspAllocation[] = [
      { subjectId: 1, facultyId: 1, batchId: 1, roomId: 1, day: 'Mon', startPeriod: 1, durationPeriods: 1, sessionIndex: 1 },
      { subjectId: 1, facultyId: 1, batchId: 1, roomId: 1, day: 'Tue', startPeriod: 1, durationPeriods: 1, sessionIndex: 2 },
      { subjectId: 1, facultyId: 1, batchId: 1, roomId: 1, day: 'Wed', startPeriod: 1, durationPeriods: 1, sessionIndex: 3 },
    ];
    const clustered: CspAllocation[] = [
      { subjectId: 1, facultyId: 1, batchId: 1, roomId: 1, day: 'Mon', startPeriod: 1, durationPeriods: 1, sessionIndex: 1 },
      { subjectId: 1, facultyId: 1, batchId: 1, roomId: 1, day: 'Mon', startPeriod: 2, durationPeriods: 1, sessionIndex: 2 },
      { subjectId: 1, facultyId: 1, batchId: 1, roomId: 1, day: 'Mon', startPeriod: 3, durationPeriods: 1, sessionIndex: 3 },
    ];

    const spreadReport = validateTimetable({ allocations: spread, subjects, faculty, batches, rooms, timeSlots: slots });
    const clusteredReport = validateTimetable({ allocations: clustered, subjects, faculty, batches, rooms, timeSlots: slots });

    expect(spreadReport.softMetrics.subjectSpreadRate).toBe(100);
    expect(clusteredReport.softMetrics.subjectSpreadRate).toBeLessThan(100);
    expect(spreadReport.softMetrics.overallScore).toBeGreaterThan(clusteredReport.softMetrics.overallScore);
  });

  it('penalizes batch idle gaps inside the same day across non-lunch periods', () => {
    const gapped: CspAllocation[] = [
      { subjectId: 1, facultyId: 1, batchId: 1, roomId: 1, day: 'Mon', startPeriod: 1, durationPeriods: 1, sessionIndex: 1 },
      { subjectId: 1, facultyId: 1, batchId: 1, roomId: 1, day: 'Mon', startPeriod: 5, durationPeriods: 1, sessionIndex: 2 },
    ];
    const compact: CspAllocation[] = [
      { subjectId: 1, facultyId: 1, batchId: 1, roomId: 1, day: 'Mon', startPeriod: 1, durationPeriods: 1, sessionIndex: 1 },
      { subjectId: 1, facultyId: 1, batchId: 1, roomId: 1, day: 'Mon', startPeriod: 2, durationPeriods: 1, sessionIndex: 2 },
    ];

    const gapReport = validateTimetable({ allocations: gapped, subjects, faculty, batches, rooms, timeSlots: slots });
    const compactReport = validateTimetable({ allocations: compact, subjects, faculty, batches, rooms, timeSlots: slots });

    expect(gapReport.softMetrics.batchGapCount).toBeGreaterThan(compactReport.softMetrics.batchGapCount);
  });

  it('scores tighter room seat fit higher than massively oversized auditorium placement', () => {
    const tight: CspAllocation[] = [
      { subjectId: 1, facultyId: 1, batchId: 1, roomId: 1, day: 'Mon', startPeriod: 1, durationPeriods: 1, sessionIndex: 1 },
    ];
    const oversized: CspAllocation[] = [
      { subjectId: 1, facultyId: 1, batchId: 1, roomId: 2, day: 'Mon', startPeriod: 1, durationPeriods: 1, sessionIndex: 1 },
    ];

    const tightReport = validateTimetable({ allocations: tight, subjects, faculty, batches, rooms, timeSlots: slots });
    const oversizedReport = validateTimetable({ allocations: oversized, subjects, faculty, batches, rooms, timeSlots: slots });

    expect(tightReport.softMetrics.roomFitScore).toBeGreaterThan(oversizedReport.softMetrics.roomFitScore);
  });

  it('detects specific period-level FACULTY_UNAVAILABLE even on an available day', () => {
    const blockedPeriod: CspAllocation[] = [
      { subjectId: 1, facultyId: 1, batchId: 1, roomId: 1, day: 'Fri', startPeriod: 5, durationPeriods: 1, sessionIndex: 1 },
    ];
    const report = validateTimetable({ allocations: blockedPeriod, subjects, faculty, batches, rooms, timeSlots: slots });
    expect(report.isValid).toBe(false);
    expect(report.hardViolations[0].type).toBe('FACULTY_UNAVAILABLE');
  });

  it('handles empty allocations array cleanly without division by zero', () => {
    const report = validateTimetable({ allocations: [], subjects, faculty, batches, rooms, timeSlots: slots });
    expect(report.isValid).toBe(true);
    expect(report.hardViolations).toEqual([]);
    expect(Number.isNaN(report.softMetrics.overallScore)).toBe(false);
  });
});
