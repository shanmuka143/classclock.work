import { describe, expect, it } from 'vitest';
import { loadConfig, parseDurationToMs } from '../../server/src/config/env.ts';
import { createDatabase } from '../../server/src/database/connection.ts';
import { runMigrations } from '../../server/src/database/migrations/runner.ts';
import { bootstrapAdmin, bootstrapEvaluator } from '../../server/src/database/seeds/seedData.ts';
import { parseCookies } from '../../server/src/middleware/authMiddleware.ts';

describe('Environment Validation & Security Utilities', () => {
  it('fails fast in production when JWT_SECRET is missing, short, or placeholder', () => {
    expect(() =>
      loadConfig({
        NODE_ENV: 'production',
        CORS_ORIGIN: 'https://timetable.example.edu',
      })
    ).toThrow(/JWT_SECRET/i);

    expect(() =>
      loadConfig({
        NODE_ENV: 'production',
        JWT_SECRET: 'too-short',
        CORS_ORIGIN: 'https://timetable.example.edu',
      })
    ).toThrow(/JWT_SECRET/i);

    expect(() =>
      loadConfig({
        NODE_ENV: 'production',
        JWT_SECRET: 'replace_with_secure_random_secret_at_least_32_chars',
        CORS_ORIGIN: 'https://timetable.example.edu',
      })
    ).toThrow(/placeholder/i);
  });

  it('fails fast in production when CORS_ORIGIN is missing, wildcard, or malformed URL', () => {
    const validSecret = 'a_cryptographically_strong_random_jwt_secret_key_99';

    expect(() =>
      loadConfig({
        NODE_ENV: 'production',
        JWT_SECRET: validSecret,
      })
    ).toThrow(/CORS_ORIGIN/i);

    expect(() =>
      loadConfig({
        NODE_ENV: 'production',
        JWT_SECRET: validSecret,
        CORS_ORIGIN: '*',
      })
    ).toThrow(/CORS_ORIGIN/i);

    expect(() =>
      loadConfig({
        NODE_ENV: 'production',
        JWT_SECRET: validSecret,
        CORS_ORIGIN: 'not-a-valid-url',
      })
    ).toThrow(/CORS_ORIGIN/i);
  });

  it('accepts valid hardened production configuration', () => {
    const cfg = loadConfig({
      NODE_ENV: 'production',
      PORT: '3000',
      JWT_SECRET: 'b9f2c8d1e4a76390b9f2c8d1e4a76390b9f2c8d1e4a76390',
      JWT_EXPIRES_IN: '8h',
      CORS_ORIGIN: 'https://scheduler.westbridge.edu, https://admin.westbridge.edu',
      COOKIE_SECURE: 'true',
    });

    expect(cfg.nodeEnv).toBe('production');
    expect(cfg.usingEphemeralDevSecret).toBe(false);
    expect(cfg.corsOrigins).toEqual([
      'https://scheduler.westbridge.edu',
      'https://admin.westbridge.edu',
    ]);
    expect(cfg.jwtExpiresInMs).toBe(8 * 60 * 60 * 1000);
    expect(cfg.cookieSecure).toBe('true');

    const proxyCfg = loadConfig({
      NODE_ENV: 'development',
      PORT: '8080',
      NGINX_PORT: '8080',
      DEFAULT_APP_PORT: '3000',
    });
    expect(proxyCfg.port).toBe(3000);

    const customPortCfg = loadConfig({
      NODE_ENV: 'development',
      PORT: '3199',
      NGINX_PORT: '8080',
      DEFAULT_APP_PORT: '3000',
    });
    expect(customPortCfg.port).toBe(3199);

    const blankOptionalCfg = loadConfig({
      NODE_ENV: '',
      PORT: '',
      JWT_EXPIRES_IN: '',
      COOKIE_SECURE: '',
      BOOTSTRAP_ADMIN_USERNAME: '',
      BOOTSTRAP_ADMIN_EMAIL: '',
      BOOTSTRAP_COORDINATOR_EMAIL: '',
      BOOTSTRAP_EVALUATOR_EMAIL: '',
    });
    expect(blankOptionalCfg.nodeEnv).toBe('development');
    expect(blankOptionalCfg.port).toBe(3000);
    expect(blankOptionalCfg.jwtExpiresIn).toBe('12h');
  });

  it('parses duration strings and HTTP cookies accurately', () => {
    expect(parseDurationToMs('30s')).toBe(30_000);
    expect(parseDurationToMs('15m')).toBe(900_000);
    expect(parseDurationToMs('12h')).toBe(43_200_000);
    expect(parseDurationToMs('7d')).toBe(604_800_000);

    const cookies = parseCookies('cc_session=abc.def.ghi; cc_csrf=token%2B123; theme=light');
    expect(cookies.cc_session).toBe('abc.def.ghi');
    expect(cookies.cc_csrf).toBe('token+123');
    expect(cookies.theme).toBe('light');
    expect(parseCookies(undefined)).toEqual({});
  });

  it('provisions admin and evaluator accounts with random evaluator password fallback', () => {
    const db = createDatabase(':memory:');
    try {
      runMigrations(db);
      expect(() => bootstrapAdmin(db, { password: 'short' })).toThrow(/at least 10/i);

      const adminRes = bootstrapAdmin(db, { password: 'StrongAdminPassword!2026' });
      expect(adminRes.created).toBe(true);
      expect(adminRes.username).toBe('admin');

      const evalRes = bootstrapEvaluator(db);
      expect(evalRes.created).toBe(true);
      expect(evalRes.username).toBe('evaluator');
      expect(evalRes.password.length).toBeGreaterThanOrEqual(12);

      // Re-running updates without duplicate row error
      const evalUpdate = bootstrapEvaluator(db, { password: 'CustomEvalPassword!2026' });
      expect(evalUpdate.created).toBe(false);
      expect(evalUpdate.password).toBe('CustomEvalPassword!2026');
    } finally {
      db.close();
    }
  });
});
