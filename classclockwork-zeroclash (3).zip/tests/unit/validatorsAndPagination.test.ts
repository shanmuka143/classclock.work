import { describe, expect, it } from 'vitest';
import {
  createBatchSchema,
  createDepartmentSchema,
  createFacultySchema,
  createRoomSchema,
  createSubjectSchema,
  generateTimetableSchema,
  loginSchema,
  saveWorkerResultSchema,
  updateAllocationSchema,
  updateSettingsSchema,
  updateTimeSlotsSchema,
} from '../../server/src/validators/schemas.ts';
import { sendListOrPaginated } from '../../server/src/utils/pagination.ts';

function mockRes() {
  const headers: Record<string, string> = {};
  let statusCode = 0;
  let jsonBody: unknown = null;
  const res = {
    setHeader(k: string, v: string) {
      headers[k.toLowerCase()] = v;
    },
    status(code: number) {
      statusCode = code;
      return res;
    },
    json(body: unknown) {
      jsonBody = body;
      return res;
    },
  };
  return {
    res: res as unknown as Parameters<typeof sendListOrPaginated>[1],
    getResult: () => ({ headers, statusCode, jsonBody }),
  };
}

describe('Zod Request Schemas & Pagination Utility', () => {
  it('validates loginSchema boundaries', () => {
    expect(loginSchema.safeParse({ username: 'admin', password: 'secret' }).success).toBe(true);
    expect(loginSchema.safeParse({ username: '  ', password: 'secret' }).success).toBe(false);
    expect(loginSchema.safeParse({ username: 'admin', password: '' }).success).toBe(false);
  });

  it('validates createDepartmentSchema codes and names', () => {
    expect(createDepartmentSchema.safeParse({ code: 'CSE', name: 'Computer Science' }).success).toBe(true);
    expect(createDepartmentSchema.safeParse({ code: 'CS$1', name: 'Bad Code' }).success).toBe(false);
    expect(createDepartmentSchema.safeParse({ code: 'C', name: 'Short Code' }).success).toBe(false);
  });

  it('validates createFacultySchema email, availableDays, and maxWeeklyHours', () => {
    expect(
      createFacultySchema.safeParse({
        facultyCode: 'FAC-1',
        fullName: 'Dr. Grace Hopper',
        email: 'grace@edu.org',
        departmentId: 1,
        maxWeeklyHours: 20,
        availableDays: ['Mon', 'Wed'],
      }).success
    ).toBe(true);

    expect(
      createFacultySchema.safeParse({
        facultyCode: 'FAC-1',
        fullName: 'Dr. Grace Hopper',
        email: 'grace@edu.org',
        departmentId: 1,
        maxWeeklyHours: 60,
        availableDays: ['Mon'],
      }).success
    ).toBe(false);

    expect(
      createFacultySchema.safeParse({
        facultyCode: 'FAC-1',
        fullName: 'Dr. Grace Hopper',
        email: 'grace@edu.org',
        departmentId: 1,
        maxWeeklyHours: 16,
        availableDays: [],
      }).success
    ).toBe(false);
  });

  it('validates createBatchSchema and createRoomSchema bounds', () => {
    expect(
      createBatchSchema.safeParse({
        batchCode: 'CSE-3A',
        name: 'Year 2 A',
        departmentId: 1,
        semester: 3,
        studentStrength: 60,
      }).success
    ).toBe(true);

    expect(
      createBatchSchema.safeParse({
        batchCode: 'CSE-3A',
        name: 'Year 2 A',
        departmentId: 1,
        semester: 15,
        studentStrength: 60,
      }).success
    ).toBe(false);

    expect(
      createRoomSchema.safeParse({
        roomCode: 'LH-101',
        name: 'Main Hall',
        roomType: 'lecture',
        capacity: 120,
      }).success
    ).toBe(true);

    expect(
      createRoomSchema.safeParse({
        roomCode: 'LH-101',
        name: 'Main Hall',
        roomType: 'auditorium',
        capacity: 120,
      }).success
    ).toBe(false);
  });

  it('validates createSubjectSchema colorHex and sessionDuration', () => {
    expect(
      createSubjectSchema.safeParse({
        subjectCode: 'CS401',
        name: 'Compilers',
        departmentId: 1,
        semester: 5,
        batchId: 1,
        facultyId: null,
        weeklySessions: 3,
        sessionDuration: 2,
        studentCount: 55,
        requiredRoomType: 'lecture',
        colorHex: '#1d4ed8',
      }).success
    ).toBe(true);

    expect(
      createSubjectSchema.safeParse({
        subjectCode: 'CS401',
        name: 'Compilers',
        departmentId: 1,
        semester: 5,
        batchId: 1,
        facultyId: 1,
        weeklySessions: 3,
        sessionDuration: 1,
        studentCount: 55,
        requiredRoomType: 'lecture',
        colorHex: 'blue',
      }).success
    ).toBe(false);
  });

  it('validates timetable generator, worker save, manual update, and settings schemas', () => {
    expect(generateTimetableSchema.safeParse({ maxNodes: 50000, timeoutMs: 10000 }).success).toBe(true);
    expect(generateTimetableSchema.safeParse({ maxNodes: 10 }).success).toBe(false);

    expect(updateAllocationSchema.safeParse({ day: 'Thu', startPeriod: 5, isLocked: true }).success).toBe(true);
    expect(updateAllocationSchema.safeParse({ day: 'Sat', startPeriod: 5 }).success).toBe(false);

    expect(
      saveWorkerResultSchema.safeParse({
        status: 'feasible',
        totalMeetings: 1,
        scheduledMeetings: 1,
        unscheduledMeetings: [],
        nodesExplored: 4,
        durationMs: 2,
        allocations: [
          {
            subjectId: 1,
            facultyId: 1,
            batchId: 1,
            roomId: 1,
            day: 'Mon',
            startPeriod: 1,
            durationPeriods: 1,
            sessionIndex: 1,
          },
        ],
      }).success
    ).toBe(true);

    expect(
      updateTimeSlotsSchema.safeParse({
        slots: [
          { periodNumber: 1, label: 'P1', startTime: '08:30', endTime: '09:30', isLunchBreak: false },
          { periodNumber: 2, label: 'P2', startTime: '09:30', endTime: '10:30', isLunchBreak: false },
          { periodNumber: 3, label: 'Lunch', startTime: '10:30', endTime: '11:30', isLunchBreak: true },
          { periodNumber: 4, label: 'P4', startTime: '11:30', endTime: '12:30', isLunchBreak: false },
        ],
      }).success
    ).toBe(true);

    expect(updateSettingsSchema.safeParse({ academicYear: '2026-2027' }).success).toBe(true);
  });

  it('returns plain array when pagination params omitted and clamps pages when specified', () => {
    const sample = [1, 2, 3, 4, 5, 6, 7];

    const m1 = mockRes();
    sendListOrPaginated({ query: {} } as unknown as Parameters<typeof sendListOrPaginated>[0], m1.res, sample);
    expect(m1.getResult().headers['x-total-count']).toBe('7');
    expect((m1.getResult().jsonBody as { data: number[] }).data).toEqual(sample);

    const m2 = mockRes();
    sendListOrPaginated(
      { query: { page: '99', limit: '3' } } as unknown as Parameters<typeof sendListOrPaginated>[0],
      m2.res,
      sample
    );
    const paged = (m2.getResult().jsonBody as { data: { items: number[]; page: number; totalPages: number } }).data;
    expect(paged.page).toBe(3);
    expect(paged.totalPages).toBe(3);
    expect(paged.items).toEqual([7]);
  });
});
