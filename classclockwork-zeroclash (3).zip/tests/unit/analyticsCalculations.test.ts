import { describe, expect, it } from 'vitest';
import { computeFairnessScore } from '../../server/src/services/analyticsService.ts';
import { buildCsvContent, buildIcsContent } from '../../src/services/exportService.ts';
import type { CspTimeSlot } from '../../shared/csp/types.ts';
import type { TimetableAllocationDto } from '../../src/types/api.ts';

describe('Analytics & Export Utilities', () => {
  it('computes workload fairness score accurately across balanced and skewed distributions', () => {
    expect(computeFairnessScore([75, 75, 75])).toBe(100);
    expect(computeFairnessScore([])).toBe(100);
    expect(computeFairnessScore([0, 0])).toBe(100);
    expect(computeFairnessScore([50])).toBe(100);
    const skewed = computeFairnessScore([10, 90]);
    expect(skewed).toBeLessThan(50);
  });

  it('builds valid RFC-compliant CSV and multi-period ICS timetable exports', () => {
    const slots: CspTimeSlot[] = [
      { periodNumber: 1, label: 'Period 1', startTime: '08:30', endTime: '09:30', isLunchBreak: false },
      { periodNumber: 2, label: 'Period 2', startTime: '09:30', endTime: '10:30', isLunchBreak: false },
    ];
    const allocations: TimetableAllocationDto[] = [
      {
        id: 1,
        runId: 1,
        subjectId: 1,
        facultyId: 1,
        batchId: 1,
        roomId: 1,
        day: 'Mon',
        startPeriod: 1,
        durationPeriods: 2,
        sessionIndex: 1,
        isLocked: false,
        subjectCode: 'CS301',
        subjectName: 'Data Structures, Part 1',
        colorHex: '#3730a3',
        requiredRoomType: 'lecture',
        facultyName: 'Dr. Alan Mercer',
        facultyCode: 'FAC-101',
        batchCode: 'CSE-3A',
        batchName: 'CSE Year 2',
        roomCode: 'LH-101',
        roomName: 'North Hall 101',
        departmentCode: 'CSE',
      },
    ];

    const csv = buildCsvContent(allocations, slots);
    expect(csv).toContain('Subject Code,Subject Name');
    expect(csv).toContain('"Data Structures, Part 1"');
    expect(csv).toContain('08:30 - 10:30');

    const ics = buildIcsContent(allocations, slots, 'CSE-3A');
    expect(ics).toContain('BEGIN:VCALENDAR');
    expect(ics).toContain('BEGIN:VEVENT');
    expect(ics).toContain('RRULE:FREQ=WEEKLY;COUNT=15;BYDAY=MO');
    expect(ics).toContain('SUMMARY:CS301 — Data Structures, Part 1 (CSE-3A)');
    expect(ics).toContain('T083000');
    expect(ics).toContain('T103000');
    expect(ics).toContain('END:VCALENDAR');
  });
});
