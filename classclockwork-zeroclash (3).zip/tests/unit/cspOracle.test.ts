import { describe, expect, it } from 'vitest';
import { validateTimetable } from '../../shared/csp/conflictDetector.ts';
import { solveTimetableCsp } from '../../shared/csp/cspSolver.ts';
import type {
  CspAllocation,
  CspBatch,
  CspFaculty,
  CspRoom,
  CspSubject,
  CspTimeSlot,
  DayOfWeek,
} from '../../shared/csp/types.ts';

function bruteForceHasFullSolution(
  subjects: CspSubject[],
  faculty: CspFaculty[],
  batches: CspBatch[],
  rooms: CspRoom[],
  timeSlots: CspTimeSlot[],
  days: readonly DayOfWeek[]
): boolean {
  const meetings: Array<{ subject: CspSubject; sessionIndex: number }> = [];
  for (const s of subjects) {
    if (!s.facultyId) return false;
    for (let idx = 1; idx <= s.weeklySessions; idx++) {
      meetings.push({ subject: s, sessionIndex: idx });
    }
  }

  const current: CspAllocation[] = [];

  function dfs(idx: number): boolean {
    if (idx === meetings.length) {
      return validateTimetable({ allocations: current, subjects, faculty, batches, rooms, timeSlots }).isValid;
    }

    const { subject, sessionIndex } = meetings[idx];
    for (const day of days) {
      for (const slot of timeSlots) {
        if (slot.isLunchBreak) continue;
        for (const room of rooms) {
          current.push({
            subjectId: subject.id,
            facultyId: subject.facultyId!,
            batchId: subject.batchId,
            roomId: room.id,
            day,
            startPeriod: slot.periodNumber,
            durationPeriods: subject.sessionDuration,
            sessionIndex,
          });

          const partialCheck = validateTimetable({
            allocations: current,
            subjects,
            faculty,
            batches,
            rooms,
            timeSlots,
          });
          if (partialCheck.isValid && dfs(idx + 1)) {
            return true;
          }
          current.pop();
        }
      }
    }
    return false;
  }

  return dfs(0);
}

describe('CSP Exhaustive Brute-Force Oracle & Algorithmic Guarantees', () => {
  const miniSlots: CspTimeSlot[] = [
    { periodNumber: 1, label: 'P1', startTime: '09:00', endTime: '10:00', isLunchBreak: false },
    { periodNumber: 2, label: 'Lunch', startTime: '10:00', endTime: '11:00', isLunchBreak: true },
    { periodNumber: 3, label: 'P3', startTime: '11:00', endTime: '12:00', isLunchBreak: false },
  ];

  const miniDays: readonly DayOfWeek[] = ['Mon', 'Tue'];

  const miniBatches: CspBatch[] = [
    { id: 1, batchCode: 'B1', name: 'Batch 1', departmentId: 1, semester: 1, studentStrength: 40 },
    { id: 2, batchCode: 'B2', name: 'Batch 2', departmentId: 1, semester: 3, studentStrength: 35 },
  ];

  const miniRooms: CspRoom[] = [
    { id: 1, roomCode: 'R1', name: 'Room 1', roomType: 'lecture', capacity: 45, equipment: ['Projector'], isAvailable: true },
    { id: 2, roomCode: 'R2', name: 'Room 2', roomType: 'lecture', capacity: 80, equipment: ['Projector'], isAvailable: true },
  ];

  it('matches brute-force satisfiability oracle across tight feasible and infeasible micro-instances', () => {
    const scenarios: Array<{
      name: string;
      faculty: CspFaculty[];
      subjects: CspSubject[];
      expectSatisfiable: boolean;
    }> = [
      {
        name: 'tight feasible 2-faculty 3-meeting puzzle',
        expectSatisfiable: true,
        faculty: [
          {
            id: 1,
            facultyCode: 'F1',
            fullName: 'Dr. One',
            departmentId: 1,
            maxWeeklyHours: 2,
            availableDays: ['Mon', 'Tue'],
            preferredHours: [{ day: 'Mon', periodNumber: 1 }],
            unavailableSlots: [{ day: 'Tue', periodNumber: 3 }],
          },
          {
            id: 2,
            facultyCode: 'F2',
            fullName: 'Dr. Two',
            departmentId: 1,
            maxWeeklyHours: 2,
            availableDays: ['Mon', 'Tue'],
            preferredHours: [],
            unavailableSlots: [{ day: 'Mon', periodNumber: 1 }],
          },
        ],
        subjects: [
          {
            id: 1,
            subjectCode: 'C1',
            name: 'Course 1',
            departmentId: 1,
            semester: 1,
            batchId: 1,
            facultyId: 1,
            weeklySessions: 2,
            sessionDuration: 1,
            studentCount: 40,
            requiredRoomType: 'lecture',
            requiredEquipment: ['Projector'],
            credits: 2,
            colorHex: '#1d4ed8',
          },
          {
            id: 2,
            subjectCode: 'C2',
            name: 'Course 2',
            departmentId: 1,
            semester: 1,
            batchId: 1,
            facultyId: 2,
            weeklySessions: 1,
            sessionDuration: 1,
            studentCount: 40,
            requiredRoomType: 'lecture',
            requiredEquipment: [],
            credits: 1,
            colorHex: '#0f766e',
          },
        ],
      },
      {
        name: 'pigeonhole infeasible 5 meetings for 1 batch across 4 Mon/Tue slots',
        expectSatisfiable: false,
        faculty: [
          {
            id: 1,
            facultyCode: 'F1',
            fullName: 'Dr. One',
            departmentId: 1,
            maxWeeklyHours: 10,
            availableDays: ['Mon', 'Tue'],
            preferredHours: [],
            unavailableSlots: [],
          },
          {
            id: 2,
            facultyCode: 'F2',
            fullName: 'Dr. Two',
            departmentId: 1,
            maxWeeklyHours: 10,
            availableDays: ['Mon', 'Tue'],
            preferredHours: [],
            unavailableSlots: [],
          },
        ],
        subjects: [
          {
            id: 1,
            subjectCode: 'P1',
            name: 'Load 1',
            departmentId: 1,
            semester: 1,
            batchId: 1,
            facultyId: 1,
            weeklySessions: 3,
            sessionDuration: 1,
            studentCount: 40,
            requiredRoomType: 'lecture',
            requiredEquipment: [],
            credits: 3,
            colorHex: '#1d4ed8',
          },
          {
            id: 2,
            subjectCode: 'P2',
            name: 'Load 2',
            departmentId: 1,
            semester: 1,
            batchId: 1,
            facultyId: 2,
            weeklySessions: 2,
            sessionDuration: 1,
            studentCount: 40,
            requiredRoomType: 'lecture',
            requiredEquipment: [],
            credits: 2,
            colorHex: '#be123c',
          },
        ],
      },
      {
        name: 'AC-3 singleton propagation puzzle requiring specific day assignment',
        expectSatisfiable: true,
        faculty: [
          {
            id: 1,
            facultyCode: 'F1',
            fullName: 'Dr. One',
            departmentId: 1,
            maxWeeklyHours: 2,
            availableDays: ['Mon'],
            preferredHours: [],
            unavailableSlots: [{ day: 'Mon', periodNumber: 3 }],
          },
          {
            id: 2,
            facultyCode: 'F2',
            fullName: 'Dr. Two',
            departmentId: 1,
            maxWeeklyHours: 2,
            availableDays: ['Mon'],
            preferredHours: [],
            unavailableSlots: [],
          },
        ],
        subjects: [
          {
            id: 1,
            subjectCode: 'A1',
            name: 'Pinned by Unavail',
            departmentId: 1,
            semester: 1,
            batchId: 1,
            facultyId: 1,
            weeklySessions: 1,
            sessionDuration: 1,
            studentCount: 40,
            requiredRoomType: 'lecture',
            requiredEquipment: [],
            credits: 1,
            colorHex: '#1d4ed8',
          },
          {
            id: 2,
            subjectCode: 'A2',
            name: 'Forced Neighbor',
            departmentId: 1,
            semester: 1,
            batchId: 1,
            facultyId: 2,
            weeklySessions: 1,
            sessionDuration: 1,
            studentCount: 40,
            requiredRoomType: 'lecture',
            requiredEquipment: [],
            credits: 1,
            colorHex: '#0f766e',
          },
        ],
      },
    ];

    for (const sc of scenarios) {
      const oracleSatisfiable = bruteForceHasFullSolution(
        sc.subjects,
        sc.faculty,
        miniBatches,
        miniRooms,
        miniSlots,
        miniDays
      );
      expect(oracleSatisfiable, `Oracle expectation mismatch on ${sc.name}`).toBe(sc.expectSatisfiable);

      const cspRes = solveTimetableCsp({
        subjects: sc.subjects,
        faculty: sc.faculty,
        batches: miniBatches,
        rooms: miniRooms,
        timeSlots: miniSlots,
        options: { enableForwardChecking: true, enableMrv: true, enableLcv: true, allowPartialFallback: true },
      });

      expect(cspRes.validation.isValid).toBe(true);
      if (oracleSatisfiable) {
        expect(cspRes.scheduledMeetings, sc.name).toBe(cspRes.totalMeetings);
        expect(['optimal', 'feasible']).toContain(cspRes.status);
      } else {
        expect(cspRes.scheduledMeetings, sc.name).toBeLessThan(cspRes.totalMeetings);
        expect(['partial', 'infeasible']).toContain(cspRes.status);
      }
    }
  });

  it('produces strictly deterministic outputs across repeated invocations', () => {
    const faculty: CspFaculty[] = [
      {
        id: 1,
        facultyCode: 'F1',
        fullName: 'Dr. One',
        departmentId: 1,
        maxWeeklyHours: 10,
        availableDays: ['Mon', 'Tue', 'Wed'],
        preferredHours: [{ day: 'Mon', periodNumber: 1 }],
        unavailableSlots: [],
      },
      {
        id: 2,
        facultyCode: 'F2',
        fullName: 'Dr. Two',
        departmentId: 1,
        maxWeeklyHours: 10,
        availableDays: ['Mon', 'Tue', 'Wed'],
        preferredHours: [],
        unavailableSlots: [],
      },
    ];
    const subjects: CspSubject[] = [
      {
        id: 1,
        subjectCode: 'S1',
        name: 'Algo',
        departmentId: 1,
        semester: 1,
        batchId: 1,
        facultyId: 1,
        weeklySessions: 2,
        sessionDuration: 1,
        studentCount: 40,
        requiredRoomType: 'lecture',
        requiredEquipment: [],
        credits: 3,
        colorHex: '#1d4ed8',
      },
      {
        id: 2,
        subjectCode: 'S2',
        name: 'Systems',
        departmentId: 1,
        semester: 3,
        batchId: 2,
        facultyId: 2,
        weeklySessions: 2,
        sessionDuration: 1,
        studentCount: 35,
        requiredRoomType: 'lecture',
        requiredEquipment: [],
        credits: 3,
        colorHex: '#0f766e',
      },
    ];

    const runA = solveTimetableCsp({ subjects, faculty, batches: miniBatches, rooms: miniRooms, timeSlots: miniSlots });
    const runB = solveTimetableCsp({ subjects, faculty, batches: miniBatches, rooms: miniRooms, timeSlots: miniSlots });

    expect(runA.allocations).toEqual(runB.allocations);
    expect(runA.nodesExplored).toBe(runB.nodesExplored);
    expect(runA.backtracksCount).toBe(runB.backtracksCount);
    expect(runA.optimizationScore).toBe(runB.optimizationScore);
  });

  it('explores fewer or equal nodes with MRV+LCV+ForwardChecking than unguided backtracking', () => {
    const slots: CspTimeSlot[] = [
      { periodNumber: 1, label: 'P1', startTime: '08:30', endTime: '09:30', isLunchBreak: false },
      { periodNumber: 2, label: 'P2', startTime: '09:30', endTime: '10:30', isLunchBreak: false },
      { periodNumber: 3, label: 'P3', startTime: '10:30', endTime: '11:30', isLunchBreak: false },
    ];
    const faculty: CspFaculty[] = [
      {
        id: 1,
        facultyCode: 'F1',
        fullName: 'Dr. Loose',
        departmentId: 1,
        maxWeeklyHours: 12,
        availableDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
        preferredHours: [],
        unavailableSlots: [],
      },
      {
        id: 2,
        facultyCode: 'F2',
        fullName: 'Dr. Constrained',
        departmentId: 1,
        maxWeeklyHours: 4,
        availableDays: ['Mon'],
        preferredHours: [],
        unavailableSlots: [{ day: 'Mon', periodNumber: 3 }],
      },
    ];
    const subjects: CspSubject[] = [
      {
        id: 1,
        subjectCode: 'L1',
        name: 'Broad Course',
        departmentId: 1,
        semester: 1,
        batchId: 1,
        facultyId: 1,
        weeklySessions: 4,
        sessionDuration: 1,
        studentCount: 40,
        requiredRoomType: 'lecture',
        requiredEquipment: [],
        credits: 4,
        colorHex: '#1d4ed8',
      },
      {
        id: 2,
        subjectCode: 'T1',
        name: 'Tight Course',
        departmentId: 1,
        semester: 1,
        batchId: 1,
        facultyId: 2,
        weeklySessions: 2,
        sessionDuration: 1,
        studentCount: 40,
        requiredRoomType: 'lecture',
        requiredEquipment: [],
        credits: 2,
        colorHex: '#be123c',
      },
    ];

    const guided = solveTimetableCsp({
      subjects,
      faculty,
      batches: miniBatches,
      rooms: [miniRooms[0]],
      timeSlots: slots,
      options: { enableMrv: true, enableLcv: true, enableForwardChecking: true, maxNodes: 5000 },
    });

    const unguided = solveTimetableCsp({
      subjects,
      faculty,
      batches: miniBatches,
      rooms: [miniRooms[0]],
      timeSlots: slots,
      options: { enableMrv: false, enableLcv: false, enableForwardChecking: false, maxNodes: 5000 },
    });

    expect(guided.scheduledMeetings).toBe(6);
    expect(unguided.scheduledMeetings).toBe(6);
    expect(guided.nodesExplored).toBeLessThanOrEqual(unguided.nodesExplored);
  });

  it('never marks a partial schedule as optimal even with allowPartialFallback', () => {
    const faculty: CspFaculty[] = [
      {
        id: 1,
        facultyCode: 'F1',
        fullName: 'Dr. One',
        departmentId: 1,
        maxWeeklyHours: 2,
        availableDays: ['Mon'],
        preferredHours: [],
        unavailableSlots: [],
      },
    ];
    const subjects: CspSubject[] = [
      {
        id: 1,
        subjectCode: 'OVER1',
        name: 'Over Cap',
        departmentId: 1,
        semester: 1,
        batchId: 1,
        facultyId: 1,
        weeklySessions: 3, // needs 3h, cap is 2h
        sessionDuration: 1,
        studentCount: 40,
        requiredRoomType: 'lecture',
        requiredEquipment: [],
        credits: 3,
        colorHex: '#be123c',
      },
    ];

    const res = solveTimetableCsp({
      subjects,
      faculty,
      batches: miniBatches,
      rooms: miniRooms,
      timeSlots: miniSlots,
      options: { allowPartialFallback: true },
    });

    expect(res.status).toBe('partial');
    expect(res.scheduledMeetings).toBe(2);
    expect(res.unscheduledMeetings).toHaveLength(1);
    expect(res.validation.isValid).toBe(true);
  });
});
