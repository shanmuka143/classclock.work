import { describe, expect, it } from 'vitest';
import { solveTimetableCsp } from '../../shared/csp/cspSolver.ts';
import type {
  CspBatch,
  CspFaculty,
  CspRoom,
  CspSubject,
  CspTimeSlot,
} from '../../shared/csp/types.ts';

const baseSlots: CspTimeSlot[] = [
  { periodNumber: 1, label: 'P1', startTime: '08:30', endTime: '09:30', isLunchBreak: false },
  { periodNumber: 2, label: 'P2', startTime: '09:30', endTime: '10:30', isLunchBreak: false },
  { periodNumber: 3, label: 'Lunch', startTime: '10:30', endTime: '11:30', isLunchBreak: true },
  { periodNumber: 4, label: 'P4', startTime: '11:30', endTime: '12:30', isLunchBreak: false },
  { periodNumber: 5, label: 'P5', startTime: '12:30', endTime: '13:30', isLunchBreak: false },
];

const baseBatches: CspBatch[] = [
  { id: 1, batchCode: 'CS-1', name: 'CS Cohort 1', departmentId: 1, semester: 3, studentStrength: 45 },
  { id: 2, batchCode: 'CS-2', name: 'CS Cohort 2', departmentId: 1, semester: 5, studentStrength: 40 },
];

const baseFaculty: CspFaculty[] = [
  {
    id: 1,
    facultyCode: 'F1',
    fullName: 'Dr. Alpha',
    departmentId: 1,
    maxWeeklyHours: 12,
    availableDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
    preferredHours: [{ day: 'Mon', periodNumber: 1 }],
    unavailableSlots: [{ day: 'Fri', periodNumber: 5 }],
  },
  {
    id: 2,
    facultyCode: 'F2',
    fullName: 'Prof. Beta',
    departmentId: 1,
    maxWeeklyHours: 10,
    availableDays: ['Mon', 'Tue', 'Wed', 'Thu'],
    preferredHours: [],
    unavailableSlots: [],
  },
];

const baseRooms: CspRoom[] = [
  { id: 1, roomCode: 'R1', name: 'Hall 1', roomType: 'lecture', capacity: 60, equipment: ['Projector'], isAvailable: true },
  { id: 2, roomCode: 'L1', name: 'Lab 1', roomType: 'lab', capacity: 50, equipment: ['Workstations', 'Projector'], isAvailable: true },
];

describe('CSP Timetable Solver', () => {
  it('expands weekly sessions into variables and solves a conflict-free schedule with MRV/LCV/FC', () => {
    const subjects: CspSubject[] = [
      {
        id: 1,
        subjectCode: 'CS301',
        name: 'Algorithms',
        departmentId: 1,
        semester: 3,
        batchId: 1,
        facultyId: 1,
        weeklySessions: 3,
        sessionDuration: 1,
        studentCount: 45,
        requiredRoomType: 'lecture',
        requiredEquipment: ['Projector'],
        credits: 4,
        colorHex: '#3730a3',
      },
      {
        id: 2,
        subjectCode: 'CS302',
        name: 'Algorithms Lab',
        departmentId: 1,
        semester: 3,
        batchId: 1,
        facultyId: 1,
        weeklySessions: 1,
        sessionDuration: 2,
        studentCount: 45,
        requiredRoomType: 'lab',
        requiredEquipment: ['Workstations'],
        credits: 2,
        colorHex: '#0f766e',
      },
      {
        id: 3,
        subjectCode: 'CS501',
        name: 'Operating Systems',
        departmentId: 1,
        semester: 5,
        batchId: 2,
        facultyId: 2,
        weeklySessions: 3,
        sessionDuration: 1,
        studentCount: 40,
        requiredRoomType: 'lecture',
        requiredEquipment: ['Projector'],
        credits: 3,
        colorHex: '#1d4ed8',
      },
    ];

    const result = solveTimetableCsp({
      subjects,
      faculty: baseFaculty,
      batches: baseBatches,
      rooms: baseRooms,
      timeSlots: baseSlots,
    });

    expect(['optimal', 'feasible']).toContain(result.status);
    expect(result.totalMeetings).toBe(7);
    expect(result.scheduledMeetings).toBe(7);
    expect(result.unscheduledMeetings).toHaveLength(0);
    expect(result.validation.isValid).toBe(true);
    expect(result.validation.hardViolations).toHaveLength(0);
    expect(typeof result.backtracksCount).toBe('number');
    expect(result.validation.softMetrics.roomFitScore).toBeGreaterThan(0);

    // Verify 2-hour lab wasn't placed across lunch break (Period 3)
    const labAlloc = result.allocations.find((a) => a.subjectId === 2)!;
    expect(labAlloc.durationPeriods).toBe(2);
    expect([1, 4]).toContain(labAlloc.startPeriod);
  });

  it('handles backtracking when MRV + forward checking must avoid dead ends', () => {
    const tightFaculty: CspFaculty[] = [
      {
        id: 10,
        facultyCode: 'F10',
        fullName: 'Dr. Tight',
        departmentId: 1,
        maxWeeklyHours: 4,
        availableDays: ['Mon'],
        preferredHours: [],
        unavailableSlots: [{ day: 'Mon', periodNumber: 5 }],
      },
    ];
    const subjects: CspSubject[] = [
      {
        id: 11,
        subjectCode: 'T1',
        name: 'Course 1',
        departmentId: 1,
        semester: 3,
        batchId: 1,
        facultyId: 10,
        weeklySessions: 1,
        sessionDuration: 2,
        studentCount: 45,
        requiredRoomType: 'lecture',
        requiredEquipment: [],
        credits: 2,
        colorHex: '#3730a3',
      },
      {
        id: 12,
        subjectCode: 'T2',
        name: 'Course 2',
        departmentId: 1,
        semester: 3,
        batchId: 1,
        facultyId: 10,
        weeklySessions: 1,
        sessionDuration: 1,
        studentCount: 45,
        requiredRoomType: 'lecture',
        requiredEquipment: [],
        credits: 1,
        colorHex: '#1d4ed8',
      },
    ];

    const result = solveTimetableCsp({
      subjects,
      faculty: tightFaculty,
      batches: baseBatches,
      rooms: baseRooms,
      timeSlots: baseSlots,
    });

    expect(result.scheduledMeetings).toBe(2);
    expect(result.validation.isValid).toBe(true);
  });

  it('honestly reports partial/infeasible schedule when faculty workload cap or room capacity is impossible', () => {
    const subjects: CspSubject[] = [
      {
        id: 21,
        subjectCode: 'BIG1',
        name: 'Mega Lecture',
        departmentId: 1,
        semester: 3,
        batchId: 1,
        facultyId: 1,
        weeklySessions: 2,
        sessionDuration: 1,
        studentCount: 250,
        requiredRoomType: 'lecture',
        requiredEquipment: [],
        credits: 3,
        colorHex: '#be123c',
      },
      {
        id: 22,
        subjectCode: 'NOFAC',
        name: 'Unassigned Course',
        departmentId: 1,
        semester: 3,
        batchId: 1,
        facultyId: null,
        weeklySessions: 1,
        sessionDuration: 1,
        studentCount: 40,
        requiredRoomType: 'lecture',
        requiredEquipment: [],
        credits: 2,
        colorHex: '#334155',
      },
    ];

    const result = solveTimetableCsp({
      subjects,
      faculty: baseFaculty,
      batches: baseBatches,
      rooms: baseRooms,
      timeSlots: baseSlots,
    });

    expect(result.status).toBe('infeasible');
    expect(result.scheduledMeetings).toBe(0);
    expect(result.unscheduledMeetings).toHaveLength(3);
    expect(result.unscheduledMeetings[0].reason).toMatch(/No faculty|No available/i);
  });

  it('preserves locked allocations and schedules remaining sessions cleanly around them', () => {
    const subjects: CspSubject[] = [
      {
        id: 1,
        subjectCode: 'CS301',
        name: 'Algorithms',
        departmentId: 1,
        semester: 3,
        batchId: 1,
        facultyId: 1,
        weeklySessions: 2,
        sessionDuration: 1,
        studentCount: 45,
        requiredRoomType: 'lecture',
        requiredEquipment: ['Projector'],
        credits: 3,
        colorHex: '#3730a3',
      },
    ];

    const result = solveTimetableCsp({
      subjects,
      faculty: baseFaculty,
      batches: baseBatches,
      rooms: baseRooms,
      timeSlots: baseSlots,
      lockedAllocations: [
        {
          subjectId: 1,
          facultyId: 1,
          batchId: 1,
          roomId: 1,
          day: 'Tue',
          startPeriod: 2,
          durationPeriods: 1,
          sessionIndex: 1,
        },
      ],
    });

    expect(result.validation.isValid).toBe(true);
    expect(result.scheduledMeetings).toBe(2);
    const lockedSession = result.allocations.find((a) => a.sessionIndex === 1)!;
    expect(lockedSession.day).toBe('Tue');
    expect(lockedSession.startPeriod).toBe(2);
  });

  it('supports deterministic fast cancellation and progress reporting', () => {
    const subjects: CspSubject[] = [
      {
        id: 1,
        subjectCode: 'CS301',
        name: 'Algorithms',
        departmentId: 1,
        semester: 3,
        batchId: 1,
        facultyId: 1,
        weeklySessions: 3,
        sessionDuration: 1,
        studentCount: 45,
        requiredRoomType: 'lecture',
        requiredEquipment: [],
        credits: 3,
        colorHex: '#3730a3',
      },
    ];

    const progressEvents: number[] = [];
    const result = solveTimetableCsp(
      {
        subjects,
        faculty: baseFaculty,
        batches: baseBatches,
        rooms: baseRooms,
        timeSlots: baseSlots,
      },
      {
        onProgress: (p) => progressEvents.push(p.nodesExplored),
        shouldCancel: () => true,
      }
    );

    expect(result.status).toBe('cancelled');
    expect(progressEvents.length).toBeGreaterThan(0);
    expect(result.durationMs).toBeLessThan(100);
  });
});
