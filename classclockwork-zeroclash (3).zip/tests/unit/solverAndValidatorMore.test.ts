import { describe, expect, it } from 'vitest';
import { validateTimetable } from '../../shared/csp/conflictDetector.ts';
import { solveTimetableCsp } from '../../shared/csp/cspSolver.ts';
import type {
  CspAllocation,
  CspBatch,
  CspFaculty,
  CspRoom,
  CspSubject,
  CspTimeSlot,
} from '../../shared/csp/types.ts';

const slots: CspTimeSlot[] = [
  { periodNumber: 1, label: 'P1', startTime: '08:30', endTime: '09:30', isLunchBreak: false },
  { periodNumber: 2, label: 'P2', startTime: '09:30', endTime: '10:30', isLunchBreak: false },
  { periodNumber: 3, label: 'P3', startTime: '10:30', endTime: '11:30', isLunchBreak: false },
  { periodNumber: 4, label: 'Lunch', startTime: '11:30', endTime: '12:30', isLunchBreak: true },
  { periodNumber: 5, label: 'P5', startTime: '12:30', endTime: '13:30', isLunchBreak: false },
  { periodNumber: 6, label: 'P6', startTime: '13:30', endTime: '14:30', isLunchBreak: false },
];

const batches: CspBatch[] = [
  { id: 1, batchCode: 'B1', name: 'Batch 1', departmentId: 1, semester: 1, studentStrength: 40 },
  { id: 2, batchCode: 'B2', name: 'Batch 2', departmentId: 1, semester: 3, studentStrength: 35 },
];

const faculty: CspFaculty[] = [
  {
    id: 1,
    facultyCode: 'F1',
    fullName: 'Dr. One',
    departmentId: 1,
    maxWeeklyHours: 16,
    availableDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
    preferredHours: [{ day: 'Mon', periodNumber: 1 }],
    unavailableSlots: [],
  },
  {
    id: 2,
    facultyCode: 'F2',
    fullName: 'Dr. Two',
    departmentId: 1,
    maxWeeklyHours: 16,
    availableDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
    preferredHours: [{ day: 'Tue', periodNumber: 2 }],
    unavailableSlots: [],
  },
];

const rooms: CspRoom[] = [
  { id: 1, roomCode: 'LH-1', name: 'Hall 1', roomType: 'lecture', capacity: 45, equipment: ['Projector'], isAvailable: true },
  { id: 2, roomCode: 'LH-2', name: 'Hall 2', roomType: 'lecture', capacity: 90, equipment: ['Projector', 'Smartboard'], isAvailable: true },
  { id: 3, roomCode: 'LAB-1', name: 'Lab 1', roomType: 'lab', capacity: 45, equipment: ['Workstations'], isAvailable: true },
  { id: 4, roomCode: 'SEM-1', name: 'Seminar 1', roomType: 'seminar', capacity: 40, equipment: ['Audio'], isAvailable: true },
];

describe('Additional CSP Constraint & Diagnostic Coverage', () => {
  it('detects missing lunch period spanning for multi-hour lab sessions', () => {
    const subjects: CspSubject[] = [
      {
        id: 1,
        subjectCode: 'LAB101',
        name: 'Lab Across Lunch',
        departmentId: 1,
        semester: 1,
        batchId: 1,
        facultyId: 1,
        weeklySessions: 1,
        sessionDuration: 2,
        studentCount: 40,
        requiredRoomType: 'lab',
        requiredEquipment: ['Workstations'],
        credits: 2,
        colorHex: '#0f766e',
      },
    ];

    const spanLunch: CspAllocation[] = [
      { subjectId: 1, facultyId: 1, batchId: 1, roomId: 3, day: 'Mon', startPeriod: 3, durationPeriods: 2, sessionIndex: 1 },
    ];
    const report = validateTimetable({ allocations: spanLunch, subjects, faculty, batches, rooms, timeSlots: slots });
    expect(report.isValid).toBe(false);
    expect(report.hardViolations.some((v) => v.type === 'LUNCH_BREAK_VIOLATION')).toBe(true);
  });

  it('honors room equipment case-insensitivity and prefers tighter room capacity when solving', () => {
    const subjects: CspSubject[] = [
      {
        id: 1,
        subjectCode: 'CS201',
        name: 'Tight Room Course',
        departmentId: 1,
        semester: 1,
        batchId: 1,
        facultyId: 1,
        weeklySessions: 1,
        sessionDuration: 1,
        studentCount: 40,
        requiredRoomType: 'lecture',
        requiredEquipment: ['projector'],
        credits: 3,
        colorHex: '#1d4ed8',
      },
    ];

    const result = solveTimetableCsp({ subjects, faculty, batches, rooms, timeSlots: slots });
    expect(result.validation.isValid).toBe(true);
    expect(result.scheduledMeetings).toBe(1);
    expect(result.allocations[0].roomId).toBe(1); // capacity 45 preferred over capacity 90
  });

  it('respects seminar room type matching cleanly', () => {
    const subjects: CspSubject[] = [
      {
        id: 1,
        subjectCode: 'SEM400',
        name: 'Research Seminar',
        departmentId: 1,
        semester: 3,
        batchId: 2,
        facultyId: 2,
        weeklySessions: 1,
        sessionDuration: 1,
        studentCount: 35,
        requiredRoomType: 'seminar',
        requiredEquipment: ['Audio'],
        credits: 2,
        colorHex: '#6d28d9',
      },
    ];

    const result = solveTimetableCsp({ subjects, faculty, batches, rooms, timeSlots: slots });
    expect(result.validation.isValid).toBe(true);
    expect(result.allocations[0].roomId).toBe(4);
  });

  it('reports explicit diagnostic message when a subject has zero feasible rooms due to equipment', () => {
    const subjects: CspSubject[] = [
      {
        id: 1,
        subjectCode: 'QUANT99',
        name: 'Quantum Hardware Lab',
        departmentId: 1,
        semester: 3,
        batchId: 2,
        facultyId: 2,
        weeklySessions: 1,
        sessionDuration: 1,
        studentCount: 35,
        requiredRoomType: 'lab',
        requiredEquipment: ['Cryogenic Dilution Refrigerator'],
        credits: 4,
        colorHex: '#be123c',
      },
    ];

    const result = solveTimetableCsp({ subjects, faculty, batches, rooms, timeSlots: slots });
    expect(result.status).toBe('infeasible');
    expect(result.unscheduledMeetings).toHaveLength(1);
    expect(result.unscheduledMeetings[0].reason).toMatch(/No available '?lab'? room/i);
  });

  it('handles zero-subject empty curriculum cleanly', () => {
    const result = solveTimetableCsp({ subjects: [], faculty, batches, rooms, timeSlots: slots });
    expect(result.totalMeetings).toBe(0);
    expect(result.scheduledMeetings).toBe(0);
    expect(result.validation.isValid).toBe(true);
    expect(['optimal', 'feasible']).toContain(result.status);
  });

  it('enforces consecutive teaching penalty when a faculty teaches 3+ back-to-back periods', () => {
    const subjects: CspSubject[] = [
      {
        id: 1,
        subjectCode: 'C1',
        name: 'Course 1',
        departmentId: 1,
        semester: 1,
        batchId: 1,
        facultyId: 1,
        weeklySessions: 3,
        sessionDuration: 1,
        studentCount: 40,
        requiredRoomType: 'lecture',
        requiredEquipment: [],
        credits: 3,
        colorHex: '#1d4ed8',
      },
    ];
    const backToBack: CspAllocation[] = [
      { subjectId: 1, facultyId: 1, batchId: 1, roomId: 1, day: 'Mon', startPeriod: 1, durationPeriods: 1, sessionIndex: 1 },
      { subjectId: 1, facultyId: 1, batchId: 1, roomId: 1, day: 'Mon', startPeriod: 2, durationPeriods: 1, sessionIndex: 2 },
      { subjectId: 1, facultyId: 1, batchId: 1, roomId: 1, day: 'Mon', startPeriod: 3, durationPeriods: 1, sessionIndex: 3 },
    ];
    const report = validateTimetable({ allocations: backToBack, subjects, faculty, batches, rooms, timeSlots: slots });
    expect(report.isValid).toBe(true);
    expect(report.softMetrics.consecutivePenaltyCount).toBeGreaterThan(0);
  });

  it('handles search node budget abort gracefully and returns best valid partial schedule', () => {
    const subjects: CspSubject[] = [
      {
        id: 1,
        subjectCode: 'B1',
        name: 'Budget Course 1',
        departmentId: 1,
        semester: 1,
        batchId: 1,
        facultyId: 1,
        weeklySessions: 4,
        sessionDuration: 1,
        studentCount: 40,
        requiredRoomType: 'lecture',
        requiredEquipment: [],
        credits: 4,
        colorHex: '#1d4ed8',
      },
      {
        id: 2,
        subjectCode: 'B2',
        name: 'Budget Course 2',
        departmentId: 1,
        semester: 1,
        batchId: 1,
        facultyId: 2,
        weeklySessions: 4,
        sessionDuration: 1,
        studentCount: 40,
        requiredRoomType: 'lecture',
        requiredEquipment: [],
        credits: 4,
        colorHex: '#0f766e',
      },
    ];

    const result = solveTimetableCsp({
      subjects,
      faculty,
      batches,
      rooms: [rooms[0]],
      timeSlots: slots,
      options: { maxNodes: 3, allowPartialFallback: false },
    });

    expect(result.validation.isValid).toBe(true);
    expect(result.nodesExplored).toBeLessThanOrEqual(4);
    expect(['partial', 'infeasible']).toContain(result.status);
  });
});
