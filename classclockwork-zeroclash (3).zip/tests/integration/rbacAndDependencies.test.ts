import bcrypt from 'bcryptjs';
import type Database from 'better-sqlite3';
import request from 'supertest';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { createApp } from '../../server/src/app.ts';
import { createDatabase } from '../../server/src/database/connection.ts';
import { runMigrations } from '../../server/src/database/migrations/runner.ts';
import { seedDatabase } from '../../server/src/database/seeds/seedData.ts';

let db: Database.Database;
let app: ReturnType<typeof createApp>;
let adminAgent: ReturnType<typeof request.agent>;
let adminCsrf: string;
let viewerAgent: ReturnType<typeof request.agent>;
let viewerCsrf: string;

beforeAll(async () => {
  db = createDatabase(':memory:');
  runMigrations(db);
  seedDatabase(db);

  const viewerHash = bcrypt.hashSync('ViewerPass!2026', 10);
  db.prepare('INSERT INTO users (username, email, full_name, password_hash, role) VALUES (?, ?, ?, ?, ?)').run(
    'viewer',
    'viewer@classclockwork.edu',
    'Read-Only Viewer',
    viewerHash,
    'viewer'
  );

  app = createApp(db);

  adminAgent = request.agent(app);
  const aRes = await adminAgent.post('/api/auth/login').send({ username: 'admin', password: 'Admin@2026' });
  adminCsrf = aRes.body.data.csrfToken;

  viewerAgent = request.agent(app);
  const vRes = await viewerAgent.post('/api/auth/login').send({ username: 'viewer', password: 'ViewerPass!2026' });
  viewerCsrf = vRes.body.data.csrfToken;
});

afterAll(() => {
  db.close();
});

describe('RBAC Viewer Restrictions, Dependency Reassignment & Filtering', () => {
  it('blocks viewer role from all write operations across academic and scheduling endpoints', async () => {
    const readOk = await viewerAgent.get('/api/timetable');
    expect(readOk.status).toBe(200);

    const facDenied = await viewerAgent
      .post('/api/faculty')
      .set('X-CSRF-Token', viewerCsrf)
      .send({
        facultyCode: 'FAC-VIEW',
        fullName: 'Blocked',
        email: 'blocked@edu.org',
        departmentId: 1,
        maxWeeklyHours: 12,
        availableDays: ['Mon'],
      });
    expect(facDenied.status).toBe(403);

    const genDenied = await viewerAgent
      .post('/api/timetable/generate')
      .set('X-CSRF-Token', viewerCsrf)
      .send({});
    expect(genDenied.status).toBe(403);
  });

  it('supports faculty deletion with safe reassignment (?reassignTo=null)', async () => {
    const facRes = await adminAgent
      .post('/api/faculty')
      .set('X-CSRF-Token', adminCsrf)
      .send({
        facultyCode: 'FAC-REASS',
        fullName: 'Dr. Reassignable',
        email: 'reassign@classclockwork.edu',
        departmentId: 1,
        maxWeeklyHours: 14,
        availableDays: ['Mon', 'Tue'],
      });
    expect(facRes.status).toBe(201);
    const facId = facRes.body.data.id;

    const subRes = await adminAgent
      .post('/api/subjects')
      .set('X-CSRF-Token', adminCsrf)
      .send({
        subjectCode: 'CS-REASS',
        name: 'Reassignment Test Course',
        departmentId: 1,
        semester: 3,
        batchId: 1,
        facultyId: facId,
        weeklySessions: 1,
        sessionDuration: 1,
        studentCount: 40,
        requiredRoomType: 'lecture',
        credits: 2,
      });
    expect(subRes.status).toBe(201);
    const subId = subRes.body.data.id;

    const blocked = await adminAgent.delete(`/api/faculty/${facId}`).set('X-CSRF-Token', adminCsrf);
    expect(blocked.status).toBe(409);

    const reassigned = await adminAgent
      .delete(`/api/faculty/${facId}?reassignTo=null`)
      .set('X-CSRF-Token', adminCsrf);
    expect(reassigned.status).toBe(200);

    const updatedSub = await adminAgent.get(`/api/subjects?search=CS-REASS`);
    expect(updatedSub.status).toBe(200);
    expect(updatedSub.body.data[0].facultyId).toBeNull();

    await adminAgent.delete(`/api/subjects/${subId}`).set('X-CSRF-Token', adminCsrf);
  });

  it('prevents deleting referenced rooms and batches with 409 conflicts', async () => {
    const roomsRes = await adminAgent.get('/api/rooms');
    const usedRoom = roomsRes.body.data.find((r: { roomCode: string }) => r.roomCode === 'LH-101');
    const delRoom = await adminAgent.delete(`/api/rooms/${usedRoom.id}`).set('X-CSRF-Token', adminCsrf);
    expect(delRoom.status).toBe(409);

    const batchesRes = await adminAgent.get('/api/batches');
    const usedBatch = batchesRes.body.data[0];
    const delBatch = await adminAgent.delete(`/api/batches/${usedBatch.id}`).set('X-CSRF-Token', adminCsrf);
    expect(delBatch.status).toBe(409);
  });

  it('filters audit logs by action and status and validates time-slot lunch checks', async () => {
    const authLogs = await adminAgent.get('/api/audit-logs?action=AUTH_LOGIN&status=success');
    expect(authLogs.status).toBe(200);
    expect(authLogs.body.data.items.length).toBeGreaterThanOrEqual(2);
    expect(authLogs.body.data.items.every((i: { action: string }) => i.action === 'AUTH_LOGIN')).toBe(true);

    const deniedLogs = await adminAgent.get('/api/audit-logs?status=denied');
    expect(deniedLogs.status).toBe(200);
    expect(deniedLogs.body.data.items.some((i: { status: string }) => i.status === 'denied')).toBe(true);
  });

  it('returns 404 for unknown resource IDs across faculty, subject, batch, and room endpoints', async () => {
    const [f404, s404, b404, r404] = await Promise.all([
      adminAgent.get('/api/faculty/999999'),
      adminAgent.put('/api/subjects/999999').set('X-CSRF-Token', adminCsrf).send({ credits: 3 }),
      adminAgent.delete('/api/batches/999999').set('X-CSRF-Token', adminCsrf),
      adminAgent.delete('/api/rooms/999999').set('X-CSRF-Token', adminCsrf),
    ]);
    expect(f404.status).toBe(404);
    expect(s404.status).toBe(404);
    expect(b404.status).toBe(404);
    expect(r404.status).toBe(404);
  });

  it('supports ?page=&limit= pagination on subjects, batches, and rooms', async () => {
    const [subs, batches, rooms] = await Promise.all([
      adminAgent.get('/api/subjects?page=1&limit=5'),
      adminAgent.get('/api/batches?page=1&limit=2'),
      adminAgent.get('/api/rooms?page=2&limit=3'),
    ]);

    expect(subs.status).toBe(200);
    expect(subs.body.data.items).toHaveLength(5);
    expect(subs.body.data.total).toBeGreaterThanOrEqual(18);

    expect(batches.status).toBe(200);
    expect(batches.body.data.items).toHaveLength(2);

    expect(rooms.status).toBe(200);
    expect(rooms.body.data.page).toBe(2);
    expect(rooms.body.data.items).toHaveLength(3);
  });
});
