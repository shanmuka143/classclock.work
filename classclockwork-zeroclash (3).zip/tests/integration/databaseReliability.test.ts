import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { createDatabase } from '../../server/src/database/connection.ts';
import { runMigrations } from '../../server/src/database/migrations/runner.ts';
import { seedDatabase } from '../../server/src/database/seeds/seedData.ts';
import { DatabaseMaintenanceService } from '../../server/src/services/databaseMaintenanceService.ts';

let tempDir: string;
let dbFile: string;

beforeEach(() => {
  tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'cc-sqlite-rel-'));
  dbFile = path.join(tempDir, 'test.sqlite');
});

afterEach(() => {
  fs.rmSync(tempDir, { recursive: true, force: true });
});

describe('SQLite Persistence, Migrations, Constraints & Recovery Reliability', () => {
  it('persists committed data across database close and reopen cycles', () => {
    const db1 = createDatabase(dbFile);
    const applied1 = runMigrations(db1);
    expect(applied1.length).toBeGreaterThanOrEqual(3);

    const seedRes = seedDatabase(db1);
    expect(seedRes.seeded).toBe(true);

    db1.prepare('INSERT INTO departments (code, name, head_name) VALUES (?, ?, ?)').run(
      'AERO',
      'Aerospace Engineering',
      'Dr. Katherine Johnson'
    );
    db1.close();

    // Reopen existing file-backed SQLite database
    const db2 = createDatabase(dbFile);
    try {
      const applied2 = runMigrations(db2);
      expect(applied2).toEqual([]); // Migration idempotency

      const dept = db2.prepare('SELECT code, name, head_name FROM departments WHERE code = ?').get('AERO') as
        | { code: string; name: string; head_name: string }
        | undefined;
      expect(dept).toBeDefined();
      expect(dept?.name).toBe('Aerospace Engineering');
      expect(dept?.head_name).toBe('Dr. Katherine Johnson');
    } finally {
      db2.close();
    }
  });

  it('enforces foreign keys, unique session index, and transaction rollback atomicity', () => {
    const db = createDatabase(dbFile);
    try {
      runMigrations(db);
      seedDatabase(db);

      // Foreign key constraint violation must throw
      expect(() =>
        db
          .prepare(
            `INSERT INTO subjects (
              subject_code, name, department_id, semester, batch_id, faculty_id,
              weekly_sessions, session_duration, student_count, required_room_type, credits, color_hex
            ) VALUES ('BAD999', 'Orphan Subject', 99999, 1, 99999, NULL, 1, 1, 30, 'lecture', 3, '#000000')`
          )
          .run()
      ).toThrow(/FOREIGN KEY/i);

      // Transaction rollback on mid-flight error leaves database completely clean
      const beforeCount = (db.prepare('SELECT COUNT(*) AS cnt FROM departments').get() as { cnt: number }).cnt;
      const failingTx = db.transaction(() => {
        db.prepare('INSERT INTO departments (code, name, head_name) VALUES (?, ?, ?)').run(
          'TX1',
          'Transient Dept',
          null
        );
        throw new Error('Simulated mid-transaction crash');
      });

      expect(() => failingTx()).toThrow('Simulated mid-transaction crash');
      const afterCount = (db.prepare('SELECT COUNT(*) AS cnt FROM departments').get() as { cnt: number }).cnt;
      expect(afterCount).toBe(beforeCount);

      // Unique session index prevents duplicate (run_id, subject_id, session_index)
      const allocRow = db
        .prepare('SELECT run_id, subject_id, faculty_id, batch_id, room_id, session_index FROM timetable_allocations LIMIT 1')
        .get() as {
        run_id: number;
        subject_id: number;
        faculty_id: number;
        batch_id: number;
        room_id: number;
        session_index: number;
      };

      expect(() =>
        db
          .prepare(
            `INSERT INTO timetable_allocations (
              run_id, subject_id, faculty_id, batch_id, room_id, day_of_week, start_period, duration_periods, session_index
            ) VALUES (?, ?, ?, ?, ?, 'Fri', 8, 1, ?)`
          )
          .run(
            allocRow.run_id,
            allocRow.subject_id,
            allocRow.faculty_id,
            allocRow.batch_id,
            allocRow.room_id,
            allocRow.session_index
          )
      ).toThrow(/UNIQUE constraint failed/i);
    } finally {
      db.close();
    }
  });

  it('passes SQLite integrity_check, foreign_key_check, and produces restorable online backups', async () => {
    const db = createDatabase(dbFile);
    try {
      runMigrations(db);
      seedDatabase(db);

      const maintenance = new DatabaseMaintenanceService(db);
      const report = maintenance.checkIntegrity();
      expect(report.integrityOk).toBe(true);
      expect(report.foreignKeyViolationsCount).toBe(0);
      expect(report.tableCounts.subjects).toBe(18);

      const backupDir = path.join(tempDir, 'backups');
      const backup = await maintenance.createBackup(backupDir);
      expect(backup.integrityOk).toBe(true);
      expect(fs.existsSync(backup.backupPath)).toBe(true);

      // Open the backup as a live database and verify records match
      const restoredDb = createDatabase(backup.backupPath);
      try {
        const subjectsCnt = (restoredDb.prepare('SELECT COUNT(*) AS cnt FROM subjects').get() as { cnt: number }).cnt;
        expect(subjectsCnt).toBe(18);
      } finally {
        restoredDb.close();
      }
    } finally {
      db.close();
    }
  });
});
