import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import type Database from 'better-sqlite3';
import request from 'supertest';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { createApp } from '../../server/src/app.ts';
import { createDatabase } from '../../server/src/database/connection.ts';
import { runMigrations } from '../../server/src/database/migrations/runner.ts';
import { bootstrapEvaluator, seedDatabase } from '../../server/src/database/seeds/seedData.ts';

let db: Database.Database;
let app: ReturnType<typeof createApp>;
let adminAgent: ReturnType<typeof request.agent>;
let adminCsrf: string;
let coordAgent: ReturnType<typeof request.agent>;
let coordCsrf: string;
let evalAgent: ReturnType<typeof request.agent>;
let evalCsrf: string;
let evalPassword: string;

function extractCookieValue(setCookieHeaders: string[] | string | undefined, cookieName: string): string | null {
  const list = Array.isArray(setCookieHeaders) ? setCookieHeaders : setCookieHeaders ? [setCookieHeaders] : [];
  for (const raw of list) {
    if (raw.startsWith(`${cookieName}=`)) {
      return raw.slice(cookieName.length + 1).split(';')[0];
    }
  }
  return null;
}

beforeAll(async () => {
  db = createDatabase(':memory:');
  runMigrations(db);
  seedDatabase(db);
  const evalProvisioned = bootstrapEvaluator(db, { password: 'EvalStrongPassword!2026' });
  evalPassword = evalProvisioned.password;
  app = createApp(db);

  adminAgent = request.agent(app);
  const adminRes = await adminAgent
    .post('/api/auth/login')
    .send({ username: 'admin', password: 'Admin@2026' });
  expect(adminRes.status).toBe(200);
  expect(adminRes.body.data.token).toBeUndefined();
  expect(extractCookieValue(adminRes.headers['set-cookie'], 'cc_session')).toBeTruthy();
  adminCsrf = adminRes.body.data.csrfToken;
  expect(adminCsrf).toBeTruthy();

  coordAgent = request.agent(app);
  const coordRes = await coordAgent
    .post('/api/auth/login')
    .send({ username: 'coordinator', password: 'Coord@2026' });
  expect(coordRes.status).toBe(200);
  coordCsrf = coordRes.body.data.csrfToken;

  evalAgent = request.agent(app);
  const evalRes = await evalAgent
    .post('/api/auth/login')
    .send({ username: 'evaluator', password: evalPassword });
  expect(evalRes.status).toBe(200);
  expect(evalRes.body.data.user.role).toBe('evaluator');
  evalCsrf = evalRes.body.data.csrfToken;
});

afterAll(() => {
  db.close();
});

describe('API Integration Tests with Real SQLite & Cookie/CSRF Security', () => {
  it('enforces HttpOnly cookie authentication, CSRF double-submit protection, and RBAC', async () => {
    const health = await request(app).get('/api/health');
    expect(health.status).toBe(200);
    expect(health.body.data.database).toBe('connected');

    const unauth = await request(app).get('/api/faculty');
    expect(unauth.status).toBe(401);

    const badLogin = await request(app)
      .post('/api/auth/login')
      .send({ username: 'admin', password: 'wrong' });
    expect(badLogin.status).toBe(401);

    const me = await adminAgent.get('/api/auth/me');
    expect(me.status).toBe(200);
    expect(me.body.data.user.role).toBe('admin');

    // Mutating cookie request WITHOUT X-CSRF-Token must be blocked with 403 CSRF_INVALID
    const missingCsrf = await adminAgent
      .put('/api/settings')
      .send({ institutionName: 'Blocked Without CSRF' });
    expect(missingCsrf.status).toBe(403);
    expect(missingCsrf.body.error.code).toBe('CSRF_INVALID');

    // Coordinator cannot modify admin settings even with valid CSRF token
    const coordForbidden = await coordAgent
      .put('/api/settings')
      .set('X-CSRF-Token', coordCsrf)
      .send({ institutionName: 'Unauthorized Change' });
    expect(coordForbidden.status).toBe(403);

    // Evaluator cannot access admin-only settings/audit/system routes
    const evalSettingsForbidden = await evalAgent
      .put('/api/settings')
      .set('X-CSRF-Token', evalCsrf)
      .send({ institutionName: 'Blocked' });
    expect(evalSettingsForbidden.status).toBe(403);

    const evalAuditForbidden = await evalAgent.get('/api/audit-logs');
    expect(evalAuditForbidden.status).toBe(403);

    const evalIntegrityForbidden = await evalAgent.get('/api/system/integrity');
    expect(evalIntegrityForbidden.status).toBe(403);
  });

  it('allows evaluator role to execute core academic CRUD & scheduling workflows', async () => {
    const createRoom = await evalAgent
      .post('/api/rooms')
      .set('X-CSRF-Token', evalCsrf)
      .send({
        roomCode: 'EVAL-101',
        name: 'Evaluator Verification Room',
        roomType: 'lecture',
        capacity: 75,
        equipment: ['Projector'],
        isAvailable: false,
      });
    expect(createRoom.status).toBe(201);
    const roomId = createRoom.body.data.id;

    const gen = await evalAgent
      .post('/api/timetable/generate')
      .set('X-CSRF-Token', evalCsrf)
      .send({ publishImmediately: false, maxNodes: 50000 });
    expect(gen.status).toBe(201);
    expect(gen.body.data.run.hardConflictsCount).toBe(0);

    const delRoom = await evalAgent
      .delete(`/api/rooms/${roomId}`)
      .set('X-CSRF-Token', evalCsrf);
    expect(delRoom.status).toBe(200);
  });

  it('performs Faculty, Subject, Batch, and Room CRUD with SQLite validation and dependency checks', async () => {
    const badFac = await adminAgent
      .post('/api/faculty')
      .set('X-CSRF-Token', adminCsrf)
      .send({
        facultyCode: 'FAC-999',
        fullName: 'Bad Email',
        email: 'not-an-email',
        departmentId: 1,
        maxWeeklyHours: 16,
        availableDays: ['Mon'],
      });
    expect(badFac.status).toBe(400);

    const newFac = await adminAgent
      .post('/api/faculty')
      .set('X-CSRF-Token', adminCsrf)
      .send({
        facultyCode: 'FAC-900',
        fullName: 'Dr. Ada Lovelace',
        email: 'a.lovelace@classclockwork.edu',
        departmentId: 1,
        maxWeeklyHours: 18,
        availableDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
        preferredHours: [{ day: 'Mon', periodNumber: 1 }],
        unavailableSlots: [{ day: 'Fri', periodNumber: 8 }],
      });
    expect(newFac.status).toBe(201);
    const facId = newFac.body.data.id;

    const dupFac = await adminAgent
      .post('/api/faculty')
      .set('X-CSRF-Token', adminCsrf)
      .send({
        facultyCode: 'FAC-900',
        fullName: 'Duplicate Ada',
        email: 'dup.ada@classclockwork.edu',
        departmentId: 1,
        maxWeeklyHours: 16,
        availableDays: ['Mon'],
      });
    expect(dupFac.status).toBe(409);

    const newRoom = await adminAgent
      .post('/api/rooms')
      .set('X-CSRF-Token', adminCsrf)
      .send({
        roomCode: 'LH-900',
        name: 'Turing Lecture Theatre',
        roomType: 'lecture',
        capacity: 90,
        equipment: ['Projector', 'Smartboard'],
        isAvailable: true,
      });
    expect(newRoom.status).toBe(201);
    const roomId = newRoom.body.data.id;

    const newBatch = await adminAgent
      .post('/api/batches')
      .set('X-CSRF-Token', adminCsrf)
      .send({
        batchCode: 'CSE-9A',
        name: 'CSE Honors Cohort',
        departmentId: 1,
        semester: 7,
        studentStrength: 42,
      });
    expect(newBatch.status).toBe(201);
    const batchId = newBatch.body.data.id;

    const newSub = await adminAgent
      .post('/api/subjects')
      .set('X-CSRF-Token', adminCsrf)
      .send({
        subjectCode: 'CS901',
        name: 'Computability Theory',
        departmentId: 1,
        semester: 7,
        batchId,
        facultyId: facId,
        weeklySessions: 2,
        sessionDuration: 1,
        studentCount: 42,
        requiredRoomType: 'lecture',
        requiredEquipment: ['Projector'],
        credits: 4,
      });
    expect(newSub.status).toBe(201);

    const blockedDelete = await adminAgent
      .delete(`/api/faculty/${facId}`)
      .set('X-CSRF-Token', adminCsrf);
    expect(blockedDelete.status).toBe(409);
    expect(blockedDelete.body.error.code).toBe('FACULTY_HAS_DEPENDENCIES');

    await adminAgent.delete(`/api/subjects/${newSub.body.data.id}`).set('X-CSRF-Token', adminCsrf);
    await adminAgent.delete(`/api/batches/${batchId}`).set('X-CSRF-Token', adminCsrf);
    await adminAgent.delete(`/api/rooms/${roomId}`).set('X-CSRF-Token', adminCsrf);
    const delFac = await adminAgent.delete(`/api/faculty/${facId}`).set('X-CSRF-Token', adminCsrf);
    expect(delFac.status).toBe(200);
  });

  it('generates timetable, enforces server-side verification on worker runs, rejects conflicts, and persists valid changes', async () => {
    const genRes = await adminAgent
      .post('/api/timetable/generate')
      .set('X-CSRF-Token', adminCsrf)
      .send({ publishImmediately: true });
    expect(genRes.status).toBe(201);
    expect(genRes.body.data.run.hardConflictsCount).toBe(0);
    expect(genRes.body.data.allocations.length).toBeGreaterThan(10);

    const allocations = genRes.body.data.allocations;
    const first = allocations[0];

    // 1. Invalid move onto protected Lunch Break (Period 4) -> 409 & DB preserved
    const lunchConflict = await adminAgent
      .put(`/api/timetable/${first.id}`)
      .set('X-CSRF-Token', adminCsrf)
      .send({ day: first.day, startPeriod: 4 });
    expect(lunchConflict.status).toBe(409);
    expect(lunchConflict.body.error.code).toBe('SCHEDULE_CONFLICT');

    const afterReject = await adminAgent.get('/api/timetable');
    const unchanged = afterReject.body.data.allocations.find((a: { id: number }) => a.id === first.id);
    expect(unchanged.startPeriod).toBe(first.startPeriod);
    expect(unchanged.day).toBe(first.day);

    // 2. Reject invalid worker-submitted schedule with forced faculty clash
    const tampered = await adminAgent
      .post('/api/timetable/save-generated')
      .set('X-CSRF-Token', adminCsrf)
      .send({
        status: 'optimal',
        totalMeetings: 2,
        scheduledMeetings: 2,
        unscheduledMeetings: [],
        nodesExplored: 10,
        durationMs: 5,
        publishImmediately: false,
        allocations: [
          {
            subjectId: first.subjectId,
            facultyId: first.facultyId,
            batchId: first.batchId,
            roomId: first.roomId,
            day: 'Mon',
            startPeriod: 1,
            durationPeriods: 1,
            sessionIndex: 1,
          },
          {
            subjectId: allocations[1].subjectId,
            facultyId: first.facultyId,
            batchId: allocations[1].batchId,
            roomId: allocations[1].roomId,
            day: 'Mon',
            startPeriod: 1,
            durationPeriods: 1,
            sessionIndex: 1,
          },
        ],
      });
    expect(tampered.status).toBe(409);
    expect(tampered.body.error.code).toBe('GENERATED_SCHEDULE_INVALID');

    // 3. Reject non-existent entity IDs in worker-submitted schedule
    const badRef = await adminAgent
      .post('/api/timetable/save-generated')
      .set('X-CSRF-Token', adminCsrf)
      .send({
        status: 'feasible',
        totalMeetings: 1,
        scheduledMeetings: 1,
        unscheduledMeetings: [],
        nodesExplored: 1,
        durationMs: 1,
        publishImmediately: false,
        allocations: [
          {
            subjectId: 999999,
            facultyId: first.facultyId,
            batchId: first.batchId,
            roomId: first.roomId,
            day: 'Mon',
            startPeriod: 1,
            durationPeriods: 1,
            sessionIndex: 1,
          },
        ],
      });
    expect(badRef.status).toBe(400);
    expect(badRef.body.error.code).toBe('INVALID_ENTITY_REFERENCE');

    // 4. Perform valid manual move
    const candidateDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'] as const;
    const candidatePeriods = [1, 2, 3, 5, 6, 7, 8];
    let movedSuccessfully = false;
    for (const d of candidateDays) {
      for (const p of candidatePeriods) {
        if (d === first.day && p === first.startPeriod) continue;
        const attempt = await adminAgent
          .put(`/api/timetable/${first.id}`)
          .set('X-CSRF-Token', adminCsrf)
          .send({ day: d, startPeriod: p });
        if (attempt.status === 200) {
          movedSuccessfully = true;
          expect(attempt.body.data.allocation.day).toBe(d);
          expect(attempt.body.data.allocation.startPeriod).toBe(p);
          break;
        }
      }
      if (movedSuccessfully) break;
    }
    expect(movedSuccessfully).toBe(true);
  });

  it('serves accurate dashboard, analytics, pagination, OpenAPI docs, audit logs, and system integrity checks', async () => {
    const [dash, work, roomUtil, sched, pagedFac, openapi, docs, integrity, auditRes] = await Promise.all([
      adminAgent.get('/api/dashboard/stats'),
      adminAgent.get('/api/analytics/workload'),
      adminAgent.get('/api/analytics/room-utilization'),
      adminAgent.get('/api/analytics/scheduling'),
      adminAgent.get('/api/faculty?page=1&limit=3'),
      request(app).get('/api/openapi.json'),
      request(app).get('/api/docs'),
      adminAgent.get('/api/system/integrity'),
      adminAgent.get('/api/audit-logs?action=CSRF_VALIDATION_FAILED&page=1&limit=5'),
    ]);

    expect(dash.status).toBe(200);
    expect(dash.body.data.counts.departments).toBeGreaterThanOrEqual(4);
    expect(dash.body.data.counts.detectedConflicts).toBe(0);

    expect(work.status).toBe(200);
    expect(work.body.data.fairnessScore).toBeGreaterThan(0);

    expect(roomUtil.status).toBe(200);
    expect(roomUtil.body.data.rooms.length).toBeGreaterThanOrEqual(8);

    expect(sched.status).toBe(200);
    expect(sched.body.data.validationSummary.isHardValid).toBe(true);
    expect(sched.body.data.validationSummary.softMetrics.roomFitScore).toBeGreaterThan(0);

    expect(pagedFac.status).toBe(200);
    expect(pagedFac.body.data.items).toHaveLength(3);
    expect(pagedFac.body.data.total).toBeGreaterThanOrEqual(10);
    expect(pagedFac.body.data.page).toBe(1);
    expect(Number(pagedFac.headers['x-total-count'])).toBeGreaterThanOrEqual(10);

    expect(openapi.status).toBe(200);
    expect(openapi.body.openapi).toBe('3.0.3');
    expect(openapi.body.paths['/timetable/generate']).toBeDefined();

    expect(docs.status).toBe(200);
    expect(docs.text).toContain('ClassClockwork');

    expect(integrity.status).toBe(200);
    expect(integrity.body.data.integrityOk).toBe(true);
    expect(integrity.body.data.foreignKeyViolationsCount).toBe(0);

    expect(auditRes.status).toBe(200);
    expect(auditRes.body.data.items.length).toBeGreaterThan(0);
    expect(auditRes.body.data.items.some((e: { action: string }) => e.action === 'CSRF_VALIDATION_FAILED')).toBe(true);
  });

  it('exercises settings, departments, server-recomputed worker run saving, and session revocation on logout', async () => {
    const settingsGet = await adminAgent.get('/api/settings');
    expect(settingsGet.status).toBe(200);

    const settingsPut = await adminAgent
      .put('/api/settings')
      .set('X-CSRF-Token', adminCsrf)
      .send({ semesterLabel: 'Spring Semester 2027' });
    expect(settingsPut.status).toBe(200);
    expect(settingsPut.body.data.semesterLabel).toBe('Spring Semester 2027');

    const deptCreate = await adminAgent
      .post('/api/departments')
      .set('X-CSRF-Token', adminCsrf)
      .send({ code: 'BIO', name: 'Biomedical Engineering', headName: 'Dr. Rosalind Franklin' });
    expect(deptCreate.status).toBe(201);

    // Save a partial worker run claiming status='optimal' -> server MUST override status to 'partial'
    const subList = await adminAgent.get('/api/subjects?search=CS301');
    const roomList = await adminAgent.get('/api/rooms?roomType=lecture');
    const firstSub = subList.body.data[0];
    const firstRoom = roomList.body.data[0];

    const saveWorkerRes = await adminAgent
      .post('/api/timetable/save-generated')
      .set('X-CSRF-Token', adminCsrf)
      .send({
        status: 'optimal',
        totalMeetings: 2,
        scheduledMeetings: 1,
        unscheduledMeetings: [
          {
            variableId: 'test-unsched',
            subjectId: firstSub.id,
            subjectCode: firstSub.subjectCode,
            subjectName: firstSub.name,
            batchId: firstSub.batchId,
            facultyId: firstSub.facultyId,
            sessionIndex: 2,
            duration: 1,
            reason: 'Simulated partial unscheduled meeting',
          },
        ],
        nodesExplored: 5,
        durationMs: 2,
        publishImmediately: false,
        allocations: [
          {
            subjectId: firstSub.id,
            facultyId: firstSub.facultyId,
            batchId: firstSub.batchId,
            roomId: firstRoom.id,
            day: 'Tue',
            startPeriod: 2,
            durationPeriods: 1,
            sessionIndex: 1,
          },
        ],
      });
    expect(saveWorkerRes.status).toBe(201);
    expect(saveWorkerRes.body.data.run.status).toBe('partial');

    // Capture coordinator session cookie BEFORE logout, then logout and prove old cookie is revoked!
    const tmpCoordLogin = await request(app)
      .post('/api/auth/login')
      .send({ username: 'coordinator', password: 'Coord@2026' });
    const rawCookies = tmpCoordLogin.headers['set-cookie'];
    const capturedSession = extractCookieValue(rawCookies, 'cc_session');
    const capturedCsrf = tmpCoordLogin.body.data.csrfToken;
    expect(capturedSession).toBeTruthy();

    const logoutRes = await request(app)
      .post('/api/auth/logout')
      .set('Cookie', [`cc_session=${capturedSession}`, `cc_csrf=${capturedCsrf}`])
      .set('X-CSRF-Token', capturedCsrf);
    expect(logoutRes.status).toBe(200);
    expect(logoutRes.body.data.revoked).toBe(true);

    const replayAfterLogout = await request(app)
      .get('/api/auth/me')
      .set('Cookie', [`cc_session=${capturedSession}`]);
    expect(replayAfterLogout.status).toBe(401);
    expect(replayAfterLogout.body.error.code).toBe('SESSION_REVOKED');

    // Verify database backup creates a readable file in temp dir
    const tmpBackupDir = fs.mkdtempSync(path.join(os.tmpdir(), 'cc-backup-test-'));
    try {
      const { DatabaseMaintenanceService } = await import('../../server/src/services/databaseMaintenanceService.ts');
      const maint = new DatabaseMaintenanceService(db);
      const bkp = await maint.createBackup(tmpBackupDir);
      expect(bkp.integrityOk).toBe(true);
      expect(bkp.sizeBytes).toBeGreaterThan(0);
      expect(fs.existsSync(bkp.backupPath)).toBe(true);
    } finally {
      fs.rmSync(tmpBackupDir, { recursive: true, force: true });
    }
  });
});
