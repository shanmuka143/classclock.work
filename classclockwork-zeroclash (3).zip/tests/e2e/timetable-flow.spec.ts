import { expect, test } from '@playwright/test';

const ADMIN_USERNAME = process.env.E2E_ADMIN_USERNAME ?? 'admin';
const ADMIN_PASSWORD = process.env.E2E_ADMIN_PASSWORD ?? 'Admin@2026';

test.describe('End-to-End ClassClockwork Timetable Workflow', () => {
  test('administrator logs in, manages resources, generates timetable, validates edits, persists across reload, checks integrity, and exports', async ({
    page,
  }) => {
    const suffix = Date.now().toString().slice(-4);
    const facCode = `FAC-E2E-${suffix}`;
    const roomCode = `LH-E2E-${suffix}`;
    const subCode = `CS-E2E-${suffix}`;

    // 1. Administrator logs in via cookie + CSRF session
    await page.goto('/login');
    await expect(page.getByRole('heading', { name: /Academic Console Sign In/i })).toBeVisible();
    await page.getByLabel(/Username or Institutional Email/i).fill(ADMIN_USERNAME);
    await page.getByLabel(/Password/i).fill(ADMIN_PASSWORD);
    await page.getByRole('button', { name: /Sign In to Console/i }).click();
    await expect(page.getByRole('heading', { name: /Administrative Overview/i })).toBeVisible();

    // 2. Adds faculty
    await page.getByRole('link', { name: 'Faculty' }).click();
    await page.getByRole('button', { name: /Add Faculty/i }).click();
    await page.getByLabel(/Faculty Code/i).fill(facCode);
    await page.getByLabel(/Full Name/i).fill(`Dr. E2E Faculty ${suffix}`);
    await page.getByLabel(/Email/i).fill(`e2e.${suffix}@classclockwork.edu`);
    await page.getByRole('button', { name: /Create Faculty/i }).click();
    await expect(page.getByText(facCode, { exact: true })).toBeVisible();

    // 3. Adds a classroom
    await page.getByRole('link', { name: 'Rooms & Labs' }).click();
    await page.getByRole('button', { name: /Add Room/i }).click();
    await page.getByLabel(/Room Code/i).fill(roomCode);
    await page.getByLabel(/Room Name/i).fill(`E2E Hall ${suffix}`);
    await page.getByRole('button', { name: /Create Room/i }).click();
    await expect(page.getByText(roomCode, { exact: true })).toBeVisible();

    // 4. Adds a subject
    await page.getByRole('link', { name: 'Subjects' }).click();
    await page.getByRole('button', { name: /Add Subject/i }).click();
    await page.getByLabel(/Subject Code/i).fill(subCode);
    await page.getByLabel(/Subject Name/i).fill(`E2E Course ${suffix}`);
    await page.getByRole('button', { name: /Create Subject/i }).click();
    await expect(page.getByText(subCode, { exact: true })).toBeVisible();

    // 5. Generates a timetable via Web Worker CSP solver
    await page.getByRole('link', { name: 'CSP Generator' }).click();
    await page.getByRole('button', { name: /Generate Timetable/i }).click();
    await expect(page.getByText(/0 Violations/i)).toBeVisible({ timeout: 25000 });

    // 6. Views the timetable
    await page.getByRole('button', { name: /Open Timetable/i }).click();
    await expect(page.getByRole('heading', { name: /Weekly Schedule Matrix/i })).toBeVisible();

    await page.getByRole('button', { name: 'All Classes' }).click();
    const firstCard = page.locator(`[data-testid="alloc-${subCode}-s1"]`).first();
    await expect(firstCard).toBeVisible();

    // 7. Attempts an invalid schedule change (move onto Period 4 Lunch Break)
    await firstCard.click();
    await page.getByLabel('Start Period').selectOption('4');
    await page.getByRole('button', { name: /Validate & Save/i }).click();

    // 8. Confirms change is rejected with exact reason
    await expect(page.getByRole('alert')).toContainText(/protected lunch period/i);

    // 9. Makes a valid lock change & saves
    await page.getByRole('button', { name: 'Cancel' }).click();
    await firstCard.click();
    await page.getByLabel(/Lock this class slot/i).check();
    await page.getByRole('button', { name: /Validate & Save/i }).click();
    await expect(page.getByText(/Allocation Saved/i).first()).toBeVisible();

    // 10. Confirms persistence after page reload
    await page.reload();
    await page.getByRole('button', { name: 'All Classes' }).click();
    const reloadedCard = page.locator(`[data-testid="alloc-${subCode}-s1"]`).first();
    await expect(reloadedCard).toBeVisible();
    await expect(reloadedCard.getByLabel('Locked')).toBeVisible();

    // 11. Exports the timetable (CSV + ICS)
    const [csvDownload] = await Promise.all([
      page.waitForEvent('download'),
      page.getByRole('button', { name: /Export CSV/i }).click(),
    ]);
    expect(csvDownload.suggestedFilename()).toContain('.csv');

    const [icsDownload] = await Promise.all([
      page.waitForEvent('download'),
      page.getByRole('button', { name: /Export ICS/i }).click(),
    ]);
    expect(icsDownload.suggestedFilename()).toContain('.ics');

    // 12. Verifies Admin Settings SQLite Integrity Check
    await page.getByRole('link', { name: 'Settings' }).click();
    await page.getByRole('button', { name: /Run Integrity Check/i }).click();
    await expect(page.getByText(/Integrity: OK/i).first()).toBeVisible();
  });
});
