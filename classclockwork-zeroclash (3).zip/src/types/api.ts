import type {
  CspTimeSlot,
  DayOfWeek,
  RoomType,
  UnscheduledMeeting,
  ValidationReport,
} from '../../shared/csp/types.ts';

export interface UserProfile {
  id: number;
  username: string;
  email: string;
  fullName: string;
  role: 'admin' | 'coordinator' | 'evaluator' | 'viewer';
}

export interface DepartmentDto {
  id: number;
  code: string;
  name: string;
  headName: string | null;
}

export interface FacultyDto {
  id: number;
  facultyCode: string;
  fullName: string;
  email: string;
  departmentId: number;
  departmentName: string;
  departmentCode: string;
  maxWeeklyHours: number;
  availableDays: DayOfWeek[];
  preferredHours: Array<{ day: DayOfWeek; periodNumber: number }>;
  unavailableSlots: Array<{ day: DayOfWeek; periodNumber: number }>;
  assignedSubjectCount: number;
  assignedWeeklyHours: number;
}

export interface BatchDto {
  id: number;
  batchCode: string;
  name: string;
  departmentId: number;
  departmentName: string;
  departmentCode: string;
  semester: number;
  studentStrength: number;
  subjectCount: number;
}

export interface RoomDto {
  id: number;
  roomCode: string;
  name: string;
  roomType: RoomType;
  capacity: number;
  equipment: string[];
  isAvailable: boolean;
}

export interface SubjectDto {
  id: number;
  subjectCode: string;
  name: string;
  departmentId: number;
  departmentName: string;
  departmentCode: string;
  semester: number;
  batchId: number;
  batchCode: string;
  batchName: string;
  facultyId: number | null;
  facultyName: string | null;
  weeklySessions: number;
  sessionDuration: number;
  studentCount: number;
  requiredRoomType: RoomType;
  requiredEquipment: string[];
  credits: number;
  colorHex: string;
}

export interface SchedulingRunDto {
  id: number;
  status: 'optimal' | 'feasible' | 'partial' | 'infeasible' | 'timeout' | 'cancelled' | 'manual';
  isPublished: boolean;
  totalMeetings: number;
  scheduledMeetings: number;
  unscheduledMeetings: number;
  hardConflictsCount: number;
  optimizationScore: number;
  nodesExplored: number;
  durationMs: number;
  config: Record<string, unknown>;
  unscheduledList: UnscheduledMeeting[];
  createdBy: number | null;
  createdAt: string;
}

export interface TimetableAllocationDto {
  id: number;
  runId: number;
  subjectId: number;
  facultyId: number;
  batchId: number;
  roomId: number;
  day: DayOfWeek;
  startPeriod: number;
  durationPeriods: number;
  sessionIndex: number;
  isLocked: boolean;
  subjectCode: string;
  subjectName: string;
  colorHex: string;
  requiredRoomType: RoomType;
  facultyName: string;
  facultyCode: string;
  batchCode: string;
  batchName: string;
  roomCode: string;
  roomName: string;
  departmentCode: string;
}

export interface TimetablePayloadDto {
  run: SchedulingRunDto | null;
  runsHistory: SchedulingRunDto[];
  timeSlots: CspTimeSlot[];
  allocations: TimetableAllocationDto[];
  allAllocationsCount: number;
  validation: ValidationReport;
  logs: Array<{ id: number; level: string; message: string; createdAt: string }>;
}

export interface DashboardStatsDto {
  counts: {
    departments: number;
    faculty: number;
    subjects: number;
    batches: number;
    rooms: number;
    classrooms: number;
    labs: number;
    scheduledClasses: number;
    unscheduledClasses: number;
    totalRequiredMeetings: number;
    detectedConflicts: number;
  };
  latestRun: {
    id: number;
    status: string;
    isPublished: boolean;
    optimizationScore: number;
    nodesExplored: number;
    durationMs: number;
    createdAt: string;
  } | null;
  facultyWorkload: Array<{
    id: number;
    facultyCode: string;
    fullName: string;
    departmentCode: string;
    scheduledHours: number;
    maxWeeklyHours: number;
    utilizationPct: number;
  }>;
  recentLogs: Array<{ id: number; level: string; message: string; createdAt: string }>;
}

export interface AcademicSettingsDto {
  academicTerm: {
    institutionName: string;
    academicYear: string;
    semesterLabel: string;
    workingDays: string[];
    defaultSolverMaxNodes: number;
    defaultSolverTimeoutMs: number;
  };
  timeSlots: CspTimeSlot[];
  departments: DepartmentDto[];
}

export interface AuditLogDto {
  id: number;
  actorUserId: number | null;
  actorUsername: string | null;
  action: string;
  entityType: string;
  entityId: string | null;
  status: 'success' | 'failure' | 'denied';
  details: Record<string, unknown> | null;
  ipAddress: string | null;
  createdAt: string;
}

export interface AuditLogsResponseDto {
  items: AuditLogDto[];
  total: number;
  page: number;
  limit: number;
}

export interface IntegrityReportDto {
  integrityOk: boolean;
  integrityMessages: string[];
  foreignKeyViolationsCount: number;
  journalMode: string;
  tableCounts: Record<string, number>;
  checkedAt: string;
}

export interface BackupResultDto {
  fileName: string;
  sizeBytes: number;
  integrityOk: boolean;
  createdAt: string;
}
