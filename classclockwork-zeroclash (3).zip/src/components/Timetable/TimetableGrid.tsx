import React, { useState } from 'react';
import { Lock, Unlock } from 'lucide-react';
import type { CspTimeSlot, DayOfWeek } from '../../../shared/csp/types.ts';
import { DAYS_OF_WEEK } from '../../../shared/csp/types.ts';
import type { TimetableAllocationDto } from '../../types/api.ts';

interface TimetableGridProps {
  allocations: TimetableAllocationDto[];
  timeSlots: CspTimeSlot[];
  onMoveAllocation: (allocationId: number, targetDay: DayOfWeek, targetPeriod: number) => Promise<void>;
  onSelectAllocation: (allocation: TimetableAllocationDto) => void;
  movingId?: number | null;
}

const DAY_LABELS: Record<DayOfWeek, string> = {
  Mon: 'Monday',
  Tue: 'Tuesday',
  Wed: 'Wednesday',
  Thu: 'Thursday',
  Fri: 'Friday',
};

export function TimetableGrid({
  allocations,
  timeSlots,
  onMoveAllocation,
  onSelectAllocation,
  movingId,
}: TimetableGridProps) {
  const [draggedId, setDraggedId] = useState<number | null>(null);
  const [dropTarget, setDropTarget] = useState<string | null>(null);

  const handleDragStart = (e: React.DragEvent, alloc: TimetableAllocationDto) => {
    setDraggedId(alloc.id);
    e.dataTransfer.setData('text/plain', String(alloc.id));
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragEnd = () => {
    setDraggedId(null);
    setDropTarget(null);
  };

  const handleDrop = async (e: React.DragEvent, day: DayOfWeek, periodNumber: number) => {
    e.preventDefault();
    setDropTarget(null);
    const rawId = e.dataTransfer.getData('text/plain');
    const id = Number(rawId || draggedId);
    setDraggedId(null);
    if (!Number.isInteger(id) || id <= 0) return;

    const current = allocations.find((a) => a.id === id);
    if (current && current.day === day && current.startPeriod === periodNumber) return;

    await onMoveAllocation(id, day, periodNumber);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full border-collapse min-w-[920px] table-fixed">
          <thead>
            <tr className="bg-slate-900 text-white">
              <th className="w-36 px-3 py-3 text-left text-xs font-semibold border-r border-slate-800">
                Period &amp; Time
              </th>
              {DAYS_OF_WEEK.map((day) => (
                <th
                  key={day}
                  className="px-3 py-3 text-left text-xs font-semibold border-r border-slate-800 last:border-r-0"
                >
                  {DAY_LABELS[day]}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {timeSlots.map((slot) => {
              if (slot.isLunchBreak) {
                return (
                  <tr key={slot.periodNumber} className="bg-amber-50/70">
                    <td className="px-3 py-2.5 border-r border-slate-200">
                      <div className="text-xs font-semibold text-amber-900">{slot.label}</div>
                      <div className="text-[11px] font-mono-tabular text-amber-700">
                        {slot.startTime}–{slot.endTime}
                      </div>
                    </td>
                    <td
                      colSpan={DAYS_OF_WEEK.length}
                      className="px-4 py-2.5 text-xs font-medium text-amber-800 text-center"
                    >
                      Protected Lunch Period — Scheduling Blocked by Hard Constraint
                    </td>
                  </tr>
                );
              }

              return (
                <tr key={slot.periodNumber} className="align-top">
                  <td className="px-3 py-3 bg-slate-50 border-r border-slate-200">
                    <div className="text-xs font-semibold text-slate-900">{slot.label}</div>
                    <div className="text-[11px] font-mono-tabular text-slate-500 mt-0.5">
                      {slot.startTime}–{slot.endTime}
                    </div>
                  </td>

                  {DAYS_OF_WEEK.map((day) => {
                    const cellKey = `${day}_${slot.periodNumber}`;
                    const isOver = dropTarget === cellKey;

                    const startingHere = allocations.filter(
                      (a) => a.day === day && a.startPeriod === slot.periodNumber
                    );
                    const continuingHere = allocations.filter(
                      (a) =>
                        a.day === day &&
                        slot.periodNumber > a.startPeriod &&
                        slot.periodNumber < a.startPeriod + a.durationPeriods
                    );

                    return (
                      <td
                        key={cellKey}
                        data-testid={`cell-${day}-P${slot.periodNumber}`}
                        onDragOver={(e) => {
                          e.preventDefault();
                          e.dataTransfer.dropEffect = 'move';
                          if (dropTarget !== cellKey) setDropTarget(cellKey);
                        }}
                        onDragLeave={() => {
                          if (dropTarget === cellKey) setDropTarget(null);
                        }}
                        onDrop={(e) => handleDrop(e, day, slot.periodNumber)}
                        className={`p-2 border-r border-slate-200 last:border-r-0 min-h-[84px] transition-colors ${
                          isOver ? 'bg-indigo-50 ring-2 ring-inset ring-indigo-500' : 'bg-white'
                        }`}
                      >
                        <div className="space-y-1.5">
                          {startingHere.map((alloc) => {
                            const isMoving = movingId === alloc.id;
                            return (
                              <div
                                key={alloc.id}
                                role="button"
                                tabIndex={0}
                                draggable
                                data-testid={`alloc-${alloc.subjectCode}-s${alloc.sessionIndex}`}
                                onDragStart={(e) => handleDragStart(e, alloc)}
                                onDragEnd={handleDragEnd}
                                onClick={() => onSelectAllocation(alloc)}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter' || e.key === ' ') {
                                    e.preventDefault();
                                    onSelectAllocation(alloc);
                                  }
                                }}
                                className={`group cursor-grab active:cursor-grabbing rounded-lg border border-slate-200 bg-slate-50/90 hover:bg-white hover:border-indigo-300 p-2.5 transition-all select-none ${
                                  draggedId === alloc.id || isMoving ? 'opacity-50' : 'opacity-100'
                                }`}
                              >
                                <div className="flex items-center justify-between gap-1.5">
                                  <div className="flex items-center gap-1.5 min-w-0">
                                    <span
                                      className="w-2.5 h-2.5 rounded-sm shrink-0"
                                      style={{ backgroundColor: alloc.colorHex }}
                                      aria-hidden="true"
                                    />
                                    <span className="text-xs font-semibold text-slate-900 truncate font-mono-tabular">
                                      {alloc.subjectCode}
                                    </span>
                                  </div>
                                  <span className="text-[11px] text-slate-500 shrink-0 flex items-center gap-1">
                                    {alloc.isLocked ? (
                                      <Lock className="w-3 h-3 text-indigo-600" aria-label="Locked" />
                                    ) : (
                                      <Unlock className="w-3 h-3 text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity" />
                                    )}
                                    {alloc.durationPeriods > 1 && (
                                      <span className="font-mono-tabular">
                                        {alloc.durationPeriods}h
                                      </span>
                                    )}
                                  </span>
                                </div>

                                <div className="text-xs font-medium text-slate-800 mt-1 line-clamp-1">
                                  {alloc.subjectName}
                                </div>

                                <div className="text-[11px] text-slate-500 mt-1 truncate">
                                  {alloc.batchCode} · {alloc.roomCode}
                                </div>
                                <div className="text-[11px] text-slate-500 truncate">
                                  {alloc.facultyName}
                                </div>
                              </div>
                            );
                          })}

                          {continuingHere.map((alloc) => (
                            <div
                              key={`${alloc.id}-cont`}
                              onClick={() => onSelectAllocation(alloc)}
                              className="cursor-pointer rounded-lg border border-dashed border-slate-300 bg-slate-50/60 px-2.5 py-2 text-[11px] text-slate-600"
                            >
                              <span className="font-mono-tabular font-medium text-slate-800">
                                {alloc.subjectCode}
                              </span>{' '}
                              · Cont. ({alloc.roomCode})
                            </div>
                          ))}
                        </div>
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
