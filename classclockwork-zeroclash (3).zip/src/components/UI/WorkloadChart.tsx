import React from 'react';

export interface BarDatum {
  label: string;
  sublabel?: string;
  value: number;
  maxValue: number;
  tone?: 'indigo' | 'emerald' | 'amber' | 'red' | 'slate';
}

const TONE_FILL: Record<NonNullable<BarDatum['tone']>, string> = {
  indigo: 'bg-indigo-600',
  emerald: 'bg-emerald-600',
  amber: 'bg-amber-600',
  red: 'bg-red-600',
  slate: 'bg-slate-600',
};

export function HorizontalBarList({
  items,
  unit = '',
}: {
  items: BarDatum[];
  unit?: string;
}) {
  if (items.length === 0) {
    return <p className="text-sm text-slate-500">No metrics available yet.</p>;
  }

  return (
    <div className="space-y-3">
      {items.map((item) => {
        const pct = item.maxValue > 0 ? Math.min(100, Math.round((item.value / item.maxValue) * 100)) : 0;
        const fill = TONE_FILL[item.tone ?? 'indigo'];
        return (
          <div key={item.label}>
            <div className="flex items-baseline justify-between gap-2 text-xs mb-1">
              <div className="min-w-0 truncate">
                <span className="font-medium text-slate-900">{item.label}</span>
                {item.sublabel && (
                  <span className="text-slate-500 ml-1.5">· {item.sublabel}</span>
                )}
              </div>
              <span className="font-mono-tabular text-slate-700 shrink-0">
                {item.value}
                {unit} / {item.maxValue}
                {unit} ({pct}%)
              </span>
            </div>
            <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
              <div
                className={`h-full ${fill} rounded-full transition-all duration-300`}
                style={{ width: `${pct}%` }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}

export function VerticalBarChart({
  items,
  height = 180,
}: {
  items: Array<{ label: string; value: number; secondaryLabel?: string }>;
  height?: number;
}) {
  const maxVal = Math.max(1, ...items.map((i) => i.value));

  return (
    <div className="w-full">
      <div
        className="flex items-end justify-between gap-3 pt-6 pb-2 border-b border-slate-200"
        style={{ height }}
      >
        {items.map((item) => {
          const barPct = Math.round((item.value / maxVal) * 100);
          return (
            <div key={item.label} className="flex-1 flex flex-col items-center h-full justify-end">
              <span className="text-xs font-mono-tabular text-slate-700 mb-1.5">{item.value}</span>
              <div className="w-full max-w-[44px] flex-1 flex items-end">
                <div
                  className="w-full bg-indigo-600 rounded-t-md transition-all duration-300"
                  style={{ height: `${Math.max(item.value > 0 ? 8 : 2, barPct)}%` }}
                  title={`${item.label}: ${item.value}`}
                />
              </div>
            </div>
          );
        })}
      </div>
      <div className="flex items-center justify-between gap-3 pt-2">
        {items.map((item) => (
          <div key={item.label} className="flex-1 text-center">
            <div className="text-xs font-medium text-slate-700">{item.label}</div>
            {item.secondaryLabel && (
              <div className="text-[11px] text-slate-500 font-mono-tabular">{item.secondaryLabel}</div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
