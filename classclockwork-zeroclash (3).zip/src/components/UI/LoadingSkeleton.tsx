import React from 'react';

export function TableSkeleton({ rows = 6 }: { rows?: number }) {
  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden" aria-busy="true">
      <div className="h-11 bg-slate-50 border-b border-slate-200 px-4 flex items-center gap-4">
        <div className="h-3 w-24 bg-slate-200 rounded animate-pulse" />
        <div className="h-3 w-36 bg-slate-200 rounded animate-pulse" />
        <div className="h-3 w-28 bg-slate-200 rounded animate-pulse" />
      </div>
      <div className="divide-y divide-slate-100">
        {Array.from({ length: rows }).map((_, i) => (
          <div key={i} className="h-12 px-4 flex items-center justify-between gap-4">
            <div className="flex items-center gap-4 flex-1">
              <div className="h-3.5 w-20 bg-slate-200 rounded animate-pulse" />
              <div className="h-3.5 w-44 bg-slate-100 rounded animate-pulse" />
              <div className="h-3.5 w-28 bg-slate-100 rounded animate-pulse hidden sm:block" />
            </div>
            <div className="h-3.5 w-16 bg-slate-200 rounded animate-pulse" />
          </div>
        ))}
      </div>
    </div>
  );
}

export function DashboardSkeleton() {
  return (
    <div className="space-y-6" aria-busy="true">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="bg-white border border-slate-200 rounded-xl p-5 h-28 animate-pulse">
            <div className="h-3 w-24 bg-slate-200 rounded" />
            <div className="h-7 w-16 bg-slate-200 rounded mt-4" />
          </div>
        ))}
      </div>
      <div className="bg-white border border-slate-200 rounded-xl p-6 h-72 animate-pulse" />
    </div>
  );
}
