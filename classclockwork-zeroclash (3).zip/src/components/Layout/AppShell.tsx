import React, { useState } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import {
  AlertOctagon,
  BarChart3,
  BookOpen,
  Building2,
  CalendarDays,
  Cpu,
  GraduationCap,
  LayoutDashboard,
  LogOut,
  Menu,
  Settings,
  Users,
  X,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';

interface NavItem {
  to: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

const NAV_ITEMS: NavItem[] = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/faculty', label: 'Faculty', icon: Users },
  { to: '/subjects', label: 'Subjects', icon: BookOpen },
  { to: '/batches', label: 'Student Batches', icon: GraduationCap },
  { to: '/rooms', label: 'Rooms & Labs', icon: Building2 },
  { to: '/generator', label: 'CSP Generator', icon: Cpu },
  { to: '/timetable', label: 'Weekly Timetable', icon: CalendarDays },
  { to: '/conflicts', label: 'Conflict Audit', icon: AlertOctagon },
  { to: '/analytics', label: 'Analytics', icon: BarChart3 },
  { to: '/settings', label: 'Settings', icon: Settings },
];

const PAGE_TITLES: Record<string, string> = {
  '/': 'Administrative Overview',
  '/faculty': 'Faculty Directory',
  '/subjects': 'Curriculum & Subjects',
  '/batches': 'Student Batches',
  '/rooms': 'Classrooms & Laboratories',
  '/generator': 'CSP Timetable Generator',
  '/timetable': 'Weekly Schedule Matrix',
  '/conflicts': 'Constraint & Conflict Audit',
  '/analytics': 'Workload & Utilization Analytics',
  '/settings': 'Academic Settings',
};

export function AppShell({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const pageTitle = PAGE_TITLES[location.pathname] ?? 'ClassClockwork ZeroClash';

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const SidebarContent = (
    <div className="flex flex-col h-full bg-slate-900 text-slate-100">
      <div className="px-5 py-5 border-b border-slate-800">
        <div className="text-base font-bold tracking-tight text-white whitespace-nowrap">
          ClassClockwork
        </div>
        <p className="text-xs text-slate-400 mt-0.5">ZeroClash Scheduler</p>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto" aria-label="Primary Navigation">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              onClick={() => setMobileOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
                  isActive
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`
              }
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span>{item.label}</span>
            </NavLink>
          );
        })}
      </nav>

      <div className="px-4 py-4 border-t border-slate-800">
        <div className="text-xs text-slate-300 font-medium truncate">{user?.fullName}</div>
        <div className="text-xs text-slate-400 mt-0.5 truncate">
          {user?.role === 'admin'
            ? 'Administrator'
            : user?.role === 'evaluator'
              ? 'Project Evaluator'
              : user?.role === 'viewer'
                ? 'Read-Only Viewer'
                : 'Academic Coordinator'}
        </div>
        <button
          type="button"
          onClick={handleLogout}
          className="mt-3 w-full inline-flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap"
        >
          <LogOut className="w-3.5 h-3.5" />
          Sign Out
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 border-r border-slate-200 sticky top-0 h-screen">
        {SidebarContent}
      </aside>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/50"
            onClick={() => setMobileOpen(false)}
            aria-hidden="true"
          />
          <aside className="relative z-50 w-64 max-w-[80vw] h-full shadow-xl">
            <button
              type="button"
              onClick={() => setMobileOpen(false)}
              aria-label="Close navigation menu"
              className="absolute top-4 right-3 p-1.5 text-slate-300 hover:text-white rounded"
            >
              <X className="w-5 h-5" />
            </button>
            {SidebarContent}
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="sticky top-0 z-20 bg-white border-b border-slate-200 px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              aria-label="Open navigation menu"
              className="lg:hidden p-2 -ml-2 text-slate-600 hover:text-slate-900 rounded-lg"
            >
              <Menu className="w-5 h-5" />
            </button>
            <h1 className="text-base sm:text-lg font-semibold text-slate-900 truncate">
              {pageTitle}
            </h1>
          </div>

          <div className="flex items-center gap-4 shrink-0">
            <span className="hidden sm:inline text-xs text-slate-500 whitespace-nowrap">
              {user?.email}
            </span>
            <button
              type="button"
              onClick={() => navigate('/generator')}
              className="px-3.5 py-2 text-xs sm:text-sm font-medium text-white bg-indigo-700 hover:bg-indigo-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              Run Scheduler
            </button>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-[1440px] w-full mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
