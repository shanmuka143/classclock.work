import React from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import { AppShell } from './components/Layout/AppShell.tsx';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { ToastProvider } from './context/ToastContext.tsx';
import { AnalyticsPage } from './pages/AnalyticsPage.tsx';
import { BatchesPage } from './pages/BatchesPage.tsx';
import { ConflictsPage } from './pages/ConflictsPage.tsx';
import { DashboardPage } from './pages/DashboardPage.tsx';
import { FacultyPage } from './pages/FacultyPage.tsx';
import { GeneratorPage } from './pages/GeneratorPage.tsx';
import { LoginPage } from './pages/LoginPage.tsx';
import { RoomsPage } from './pages/RoomsPage.tsx';
import { SettingsPage } from './pages/SettingsPage.tsx';
import { SubjectsPage } from './pages/SubjectsPage.tsx';
import { TimetablePage } from './pages/TimetablePage.tsx';

function ProtectedLayout({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center text-sm text-slate-600">
        Verifying session...
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return <AppShell>{children}</AppShell>;
}

export function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route
        path="/"
        element={
          <ProtectedLayout>
            <DashboardPage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/faculty"
        element={
          <ProtectedLayout>
            <FacultyPage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/subjects"
        element={
          <ProtectedLayout>
            <SubjectsPage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/batches"
        element={
          <ProtectedLayout>
            <BatchesPage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/rooms"
        element={
          <ProtectedLayout>
            <RoomsPage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/generator"
        element={
          <ProtectedLayout>
            <GeneratorPage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/timetable"
        element={
          <ProtectedLayout>
            <TimetablePage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/conflicts"
        element={
          <ProtectedLayout>
            <ConflictsPage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/analytics"
        element={
          <ProtectedLayout>
            <AnalyticsPage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/settings"
        element={
          <ProtectedLayout>
            <SettingsPage />
          </ProtectedLayout>
        }
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <AuthProvider>
          <ToastProvider>
            <AppRoutes />
          </ToastProvider>
        </AuthProvider>
      </BrowserRouter>
    </ErrorBoundary>
  );
}
