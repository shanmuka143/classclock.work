import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { BookOpen, Pencil, Plus, Search, Trash2 } from 'lucide-react';
import { ConfirmDialog } from '../components/UI/ConfirmDialog.tsx';
import { EmptyState } from '../components/UI/EmptyState.tsx';
import { TableSkeleton } from '../components/UI/LoadingSkeleton.tsx';
import { Modal } from '../components/UI/Modal.tsx';
import { useToast } from '../context/ToastContext.tsx';
import { apiClient, ApiClientError } from '../services/apiClient.ts';
import type {
  AcademicSettingsDto,
  BatchDto,
  DepartmentDto,
  FacultyDto,
  SubjectDto,
} from '../types/api.ts';
import type { RoomType } from '../../shared/csp/types.ts';

interface SubjectFormState {
  subjectCode: string;
  name: string;
  departmentId: number;
  semester: number;
  batchId: number;
  facultyId: number | null;
  weeklySessions: number;
  sessionDuration: number;
  studentCount: number;
  requiredRoomType: RoomType;
  requiredEquipmentText: string;
  credits: number;
  colorHex: string;
}

const COLOR_SWATCHES = ['#3730a3', '#0f766e', '#1d4ed8', '#be123c', '#b45309', '#6d28d9', '#047857', '#334155'];

export function SubjectsPage() {
  const { pushToast } = useToast();
  const [subjects, setSubjects] = useState<SubjectDto[]>([]);
  const [departments, setDepartments] = useState<DepartmentDto[]>([]);
  const [batches, setBatches] = useState<BatchDto[]>([]);
  const [faculty, setFaculty] = useState<FacultyDto[]>([]);
  const [loading, setLoading] = useState(true);

  const [search, setSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState('all');
  const [batchFilter, setBatchFilter] = useState('all');

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<SubjectDto | null>(null);
  const [form, setForm] = useState<SubjectFormState>({
    subjectCode: '',
    name: '',
    departmentId: 1,
    semester: 3,
    batchId: 1,
    facultyId: null,
    weeklySessions: 3,
    sessionDuration: 1,
    studentCount: 50,
    requiredRoomType: 'lecture',
    requiredEquipmentText: 'Projector',
    credits: 3,
    colorHex: '#3730a3',
  });
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<SubjectDto | null>(null);
  const [deleting, setDeleting] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [subList, batchList, facList, settings] = await Promise.all([
        apiClient.get<SubjectDto[]>('/subjects'),
        apiClient.get<BatchDto[]>('/batches'),
        apiClient.get<FacultyDto[]>('/faculty'),
        apiClient.get<AcademicSettingsDto>('/settings'),
      ]);
      setSubjects(subList);
      setBatches(batchList);
      setFaculty(facList);
      setDepartments(settings.departments);
    } catch (err) {
      pushToast('error', 'Load Failed', err instanceof ApiClientError ? err.message : 'Unable to fetch subjects.');
    } finally {
      setLoading(false);
    }
  }, [pushToast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const openCreate = () => {
    const defaultBatch = batches[0];
    setEditing(null);
    setForm({
      subjectCode: '',
      name: '',
      departmentId: departments[0]?.id ?? 1,
      semester: defaultBatch?.semester ?? 3,
      batchId: defaultBatch?.id ?? 1,
      facultyId: faculty[0]?.id ?? null,
      weeklySessions: 3,
      sessionDuration: 1,
      studentCount: defaultBatch?.studentStrength ?? 50,
      requiredRoomType: 'lecture',
      requiredEquipmentText: 'Projector',
      credits: 3,
      colorHex: COLOR_SWATCHES[subjects.length % COLOR_SWATCHES.length],
    });
    setFormError(null);
    setModalOpen(true);
  };

  const openEdit = (sub: SubjectDto) => {
    setEditing(sub);
    setForm({
      subjectCode: sub.subjectCode,
      name: sub.name,
      departmentId: sub.departmentId,
      semester: sub.semester,
      batchId: sub.batchId,
      facultyId: sub.facultyId,
      weeklySessions: sub.weeklySessions,
      sessionDuration: sub.sessionDuration,
      studentCount: sub.studentCount,
      requiredRoomType: sub.requiredRoomType,
      requiredEquipmentText: sub.requiredEquipment.join(', '),
      credits: sub.credits,
      colorHex: sub.colorHex,
    });
    setFormError(null);
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (!form.subjectCode.trim() || !form.name.trim()) {
      setFormError('Subject code and name are required.');
      return;
    }

    const payload = {
      subjectCode: form.subjectCode.trim(),
      name: form.name.trim(),
      departmentId: form.departmentId,
      semester: form.semester,
      batchId: form.batchId,
      facultyId: form.facultyId,
      weeklySessions: form.weeklySessions,
      sessionDuration: form.sessionDuration,
      studentCount: form.studentCount,
      requiredRoomType: form.requiredRoomType,
      requiredEquipment: form.requiredEquipmentText
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean),
      credits: form.credits,
      colorHex: form.colorHex,
    };

    setSaving(true);
    try {
      if (editing) {
        await apiClient.put(`/subjects/${editing.id}`, payload);
        pushToast('success', 'Subject Updated', `${payload.subjectCode} updated.`);
      } else {
        await apiClient.post('/subjects', payload);
        pushToast('success', 'Subject Created', `${payload.subjectCode} added.`);
      }
      setModalOpen(false);
      await loadData();
    } catch (err) {
      setFormError(err instanceof ApiClientError ? err.message : 'Unable to save subject.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await apiClient.delete(`/subjects/${deleteTarget.id}`);
      pushToast('success', 'Subject Deleted', `${deleteTarget.subjectCode} removed.`);
      setDeleteTarget(null);
      await loadData();
    } catch (err) {
      pushToast('error', 'Delete Failed', err instanceof ApiClientError ? err.message : 'Unable to delete subject.');
    } finally {
      setDeleting(false);
    }
  };

  const filtered = useMemo(() => {
    return subjects.filter((s) => {
      if (deptFilter !== 'all' && String(s.departmentId) !== deptFilter) return false;
      if (batchFilter !== 'all' && String(s.batchId) !== batchFilter) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        return (
          s.subjectCode.toLowerCase().includes(q) ||
          s.name.toLowerCase().includes(q) ||
          (s.facultyName && s.facultyName.toLowerCase().includes(q)) ||
          s.batchCode.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [subjects, deptFilter, batchFilter, search]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 flex-1">
          <div className="relative flex-1 min-w-[220px] max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              aria-label="Search subjects"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search code, title, faculty, or batch..."
              className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>
          <select
            value={deptFilter}
            onChange={(e) => setDeptFilter(e.target.value)}
            aria-label="Filter by department"
            className="px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
          >
            <option value="all">All Departments</option>
            {departments.map((d) => (
              <option key={d.id} value={d.id}>
                {d.code}
              </option>
            ))}
          </select>
          <select
            value={batchFilter}
            onChange={(e) => setBatchFilter(e.target.value)}
            aria-label="Filter by batch"
            className="px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
          >
            <option value="all">All Batches</option>
            {batches.map((b) => (
              <option key={b.id} value={b.id}>
                {b.batchCode}
              </option>
            ))}
          </select>
        </div>

        <button
          type="button"
          onClick={openCreate}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-indigo-700 hover:bg-indigo-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          Add Subject
        </button>
      </div>

      {loading ? (
        <TableSkeleton />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={BookOpen}
          title="No subjects found"
          description="Create courses with weekly session counts, room types, and faculty assignments."
          actionLabel="Add Subject"
          onAction={openCreate}
        />
      ) : (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                  <th className="px-4 py-3">Code</th>
                  <th className="px-4 py-3">Subject Name</th>
                  <th className="px-4 py-3">Batch &amp; Sem</th>
                  <th className="px-4 py-3">Assigned Faculty</th>
                  <th className="px-4 py-3">Room &amp; Equipment</th>
                  <th className="px-4 py-3 text-right">Weekly Load</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filtered.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50/70">
                    <td className="px-4 py-3 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <span
                          className="w-2.5 h-2.5 rounded-sm shrink-0"
                          style={{ backgroundColor: s.colorHex }}
                          aria-hidden="true"
                        />
                        <span className="font-mono-tabular text-xs font-semibold text-slate-900">
                          {s.subjectCode}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-medium text-slate-900">{s.name}</div>
                      <div className="text-xs text-slate-500">
                        {s.departmentCode} · {s.credits} credits · {s.studentCount} students
                      </div>
                    </td>
                    <td className="px-4 py-3 text-slate-700 whitespace-nowrap">
                      {s.batchCode} · Sem {s.semester}
                    </td>
                    <td className="px-4 py-3 text-slate-700 whitespace-nowrap">
                      {s.facultyName ?? <span className="text-amber-700 font-medium">Unassigned</span>}
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-600">
                      <div className="capitalize font-medium text-slate-800">{s.requiredRoomType}</div>
                      <div className="text-slate-500">
                        {s.requiredEquipment.length > 0 ? s.requiredEquipment.join(', ') : 'Standard'}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-right font-mono-tabular whitespace-nowrap text-slate-800">
                      {s.weeklySessions} × {s.sessionDuration}h
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => openEdit(s)}
                          aria-label={`Edit ${s.subjectCode}`}
                          className="p-1.5 text-slate-500 hover:text-indigo-700 rounded-lg"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeleteTarget(s)}
                          aria-label={`Delete ${s.subjectCode}`}
                          className="p-1.5 text-slate-500 hover:text-red-700 rounded-lg"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <Modal
        open={modalOpen}
        title={editing ? `Edit Subject — ${editing.subjectCode}` : 'Add Academic Subject'}
        subtitle="Specify room requirements, weekly meetings, batch, and faculty assignment."
        onClose={() => setModalOpen(false)}
        maxWidthClass="max-w-2xl"
      >
        <form onSubmit={handleSave} className="space-y-4">
          {formError && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-800">
              {formError}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="subject-code-input" className="block text-xs font-medium text-slate-700 mb-1">
                Subject Code
              </label>
              <input
                id="subject-code-input"
                type="text"
                required
                value={form.subjectCode}
                onChange={(e) => setForm({ ...form, subjectCode: e.target.value })}
                placeholder="CS405"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label htmlFor="subject-name-input" className="block text-xs font-medium text-slate-700 mb-1">
                Subject Name
              </label>
              <input
                id="subject-name-input"
                type="text"
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Distributed Systems"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label htmlFor="subject-dept-select" className="block text-xs font-medium text-slate-700 mb-1">
                Department
              </label>
              <select
                id="subject-dept-select"
                value={form.departmentId}
                onChange={(e) => setForm({ ...form, departmentId: Number(e.target.value) })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
              >
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.code} — {d.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="subject-batch-select" className="block text-xs font-medium text-slate-700 mb-1">
                Student Batch
              </label>
              <select
                id="subject-batch-select"
                value={form.batchId}
                onChange={(e) => {
                  const bId = Number(e.target.value);
                  const b = batches.find((x) => x.id === bId);
                  setForm({
                    ...form,
                    batchId: bId,
                    semester: b ? b.semester : form.semester,
                    studentCount: b ? b.studentStrength : form.studentCount,
                  });
                }}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
              >
                {batches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.batchCode} ({b.studentStrength} students)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="subject-faculty-select" className="block text-xs font-medium text-slate-700 mb-1">
                Assigned Faculty
              </label>
              <select
                id="subject-faculty-select"
                value={form.facultyId ?? ''}
                onChange={(e) =>
                  setForm({ ...form, facultyId: e.target.value ? Number(e.target.value) : null })
                }
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
              >
                <option value="">Unassigned</option>
                {faculty.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.facultyCode} — {f.fullName}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="subject-room-type-select" className="block text-xs font-medium text-slate-700 mb-1">
                Required Room Type
              </label>
              <select
                id="subject-room-type-select"
                value={form.requiredRoomType}
                onChange={(e) => setForm({ ...form, requiredRoomType: e.target.value as RoomType })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
              >
                <option value="lecture">Lecture Hall</option>
                <option value="lab">Laboratory</option>
                <option value="seminar">Seminar Room</option>
              </select>
            </div>

            <div>
              <label htmlFor="subject-sessions-input" className="block text-xs font-medium text-slate-700 mb-1">
                Weekly Sessions
              </label>
              <input
                id="subject-sessions-input"
                type="number"
                min={1}
                max={12}
                required
                value={form.weeklySessions}
                onChange={(e) => setForm({ ...form, weeklySessions: Number(e.target.value) })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg font-mono-tabular"
              />
            </div>

            <div>
              <label htmlFor="subject-duration-input" className="block text-xs font-medium text-slate-700 mb-1">
                Session Duration (Periods)
              </label>
              <input
                id="subject-duration-input"
                type="number"
                min={1}
                max={4}
                required
                value={form.sessionDuration}
                onChange={(e) => setForm({ ...form, sessionDuration: Number(e.target.value) })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg font-mono-tabular"
              />
            </div>

            <div>
              <label htmlFor="subject-students-input" className="block text-xs font-medium text-slate-700 mb-1">
                Student Count
              </label>
              <input
                id="subject-students-input"
                type="number"
                min={1}
                max={500}
                required
                value={form.studentCount}
                onChange={(e) => setForm({ ...form, studentCount: Number(e.target.value) })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg font-mono-tabular"
              />
            </div>

            <div>
              <label htmlFor="subject-credits-input" className="block text-xs font-medium text-slate-700 mb-1">
                Credits &amp; Semester
              </label>
              <div className="grid grid-cols-2 gap-2">
                <input
                  id="subject-credits-input"
                  type="number"
                  min={1}
                  max={10}
                  value={form.credits}
                  onChange={(e) => setForm({ ...form, credits: Number(e.target.value) })}
                  aria-label="Credits"
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg font-mono-tabular"
                />
                <input
                  type="number"
                  min={1}
                  max={10}
                  value={form.semester}
                  onChange={(e) => setForm({ ...form, semester: Number(e.target.value) })}
                  aria-label="Semester"
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg font-mono-tabular"
                />
              </div>
            </div>
          </div>

          <div>
            <label htmlFor="subject-equipment-input" className="block text-xs font-medium text-slate-700 mb-1">
              Required Equipment (comma-separated)
            </label>
            <input
              id="subject-equipment-input"
              type="text"
              value={form.requiredEquipmentText}
              onChange={(e) => setForm({ ...form, requiredEquipmentText: e.target.value })}
              placeholder="Projector, Workstations"
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">Subject Color Marker</label>
            <div className="flex items-center gap-2">
              {COLOR_SWATCHES.map((hex) => (
                <button
                  key={hex}
                  type="button"
                  onClick={() => setForm({ ...form, colorHex: hex })}
                  aria-label={`Select color ${hex}`}
                  className={`w-6 h-6 rounded-md border-2 ${
                    form.colorHex === hex ? 'border-slate-900 scale-110' : 'border-transparent'
                  }`}
                  style={{ backgroundColor: hex }}
                />
              ))}
            </div>
          </div>

          <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 text-sm font-medium text-white bg-indigo-700 hover:bg-indigo-800 rounded-lg disabled:opacity-50"
            >
              {saving ? 'Saving...' : editing ? 'Update Subject' : 'Create Subject'}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={deleteTarget !== null}
        title={`Delete ${deleteTarget?.subjectCode ?? 'Subject'}?`}
        description="Deleting this subject also removes its scheduled timetable allocations."
        confirmLabel="Delete Subject"
        busy={deleting}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
      />
    </div>
  );
}
