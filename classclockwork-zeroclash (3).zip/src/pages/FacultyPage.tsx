import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Pencil, Plus, Search, Trash2, Users } from 'lucide-react';
import { ConfirmDialog } from '../components/UI/ConfirmDialog.tsx';
import { EmptyState } from '../components/UI/EmptyState.tsx';
import { TableSkeleton } from '../components/UI/LoadingSkeleton.tsx';
import { Modal } from '../components/UI/Modal.tsx';
import { useToast } from '../context/ToastContext.tsx';
import { apiClient, ApiClientError } from '../services/apiClient.ts';
import type { AcademicSettingsDto, DepartmentDto, FacultyDto } from '../types/api.ts';
import type { DayOfWeek } from '../../shared/csp/types.ts';
import { DAYS_OF_WEEK } from '../../shared/csp/types.ts';

interface FacultyFormState {
  facultyCode: string;
  fullName: string;
  email: string;
  departmentId: number;
  maxWeeklyHours: number;
  availableDays: DayOfWeek[];
  preferredHours: Array<{ day: DayOfWeek; periodNumber: number }>;
  unavailableSlots: Array<{ day: DayOfWeek; periodNumber: number }>;
}

const EMPTY_FORM: FacultyFormState = {
  facultyCode: '',
  fullName: '',
  email: '',
  departmentId: 1,
  maxWeeklyHours: 16,
  availableDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
  preferredHours: [],
  unavailableSlots: [],
};

export function FacultyPage() {
  const { pushToast } = useToast();
  const [faculty, setFaculty] = useState<FacultyDto[]>([]);
  const [departments, setDepartments] = useState<DepartmentDto[]>([]);
  const [periods, setPeriods] = useState<number[]>([1, 2, 3, 5, 6, 7, 8]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState<string>('all');

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<FacultyDto | null>(null);
  const [form, setForm] = useState<FacultyFormState>(EMPTY_FORM);
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState<FacultyDto | null>(null);
  const [dependencyMsg, setDependencyMsg] = useState<string | null>(null);
  const [reassignToId, setReassignToId] = useState<string>('null');
  const [deleting, setDeleting] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [facList, settings] = await Promise.all([
        apiClient.get<FacultyDto[]>('/faculty'),
        apiClient.get<AcademicSettingsDto>('/settings'),
      ]);
      setFaculty(facList);
      setDepartments(settings.departments);
      setPeriods(settings.timeSlots.filter((s) => !s.isLunchBreak).map((s) => s.periodNumber));
    } catch (err) {
      pushToast('error', 'Load Failed', err instanceof ApiClientError ? err.message : 'Unable to fetch faculty.');
    } finally {
      setLoading(false);
    }
  }, [pushToast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const openCreate = () => {
    setEditing(null);
    setForm({
      ...EMPTY_FORM,
      departmentId: departments[0]?.id ?? 1,
    });
    setFormError(null);
    setModalOpen(true);
  };

  const openEdit = (item: FacultyDto) => {
    setEditing(item);
    setForm({
      facultyCode: item.facultyCode,
      fullName: item.fullName,
      email: item.email,
      departmentId: item.departmentId,
      maxWeeklyHours: item.maxWeeklyHours,
      availableDays: item.availableDays,
      preferredHours: item.preferredHours,
      unavailableSlots: item.unavailableSlots,
    });
    setFormError(null);
    setModalOpen(true);
  };

  const toggleDay = (day: DayOfWeek) => {
    setForm((prev) => {
      const exists = prev.availableDays.includes(day);
      const next = exists
        ? prev.availableDays.filter((d) => d !== day)
        : [...prev.availableDays, day];
      return { ...prev, availableDays: next };
    });
  };

  const cycleSlotStatus = (day: DayOfWeek, periodNumber: number) => {
    setForm((prev) => {
      const isPref = prev.preferredHours.some((s) => s.day === day && s.periodNumber === periodNumber);
      const isUnavail = prev.unavailableSlots.some((s) => s.day === day && s.periodNumber === periodNumber);
      const prefClean = prev.preferredHours.filter((s) => !(s.day === day && s.periodNumber === periodNumber));
      const unavailClean = prev.unavailableSlots.filter((s) => !(s.day === day && s.periodNumber === periodNumber));

      if (!isPref && !isUnavail) {
        return { ...prev, preferredHours: [...prefClean, { day, periodNumber }], unavailableSlots: unavailClean };
      }
      if (isPref) {
        return { ...prev, preferredHours: prefClean, unavailableSlots: [...unavailClean, { day, periodNumber }] };
      }
      return { ...prev, preferredHours: prefClean, unavailableSlots: unavailClean };
    });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!form.facultyCode.trim() || !form.fullName.trim() || !form.email.trim()) {
      setFormError('Faculty code, full name, and email are required.');
      return;
    }
    if (form.availableDays.length === 0) {
      setFormError('Select at least one available teaching day.');
      return;
    }

    setSaving(true);
    try {
      if (editing) {
        await apiClient.put(`/faculty/${editing.id}`, form);
        pushToast('success', 'Faculty Updated', `${form.fullName} saved to SQLite.`);
      } else {
        await apiClient.post('/faculty', form);
        pushToast('success', 'Faculty Added', `${form.fullName} created.`);
      }
      setModalOpen(false);
      await loadData();
    } catch (err) {
      setFormError(err instanceof ApiClientError ? err.message : 'Unable to save faculty member.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (withReassign = false) => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      const query = withReassign ? `?reassignTo=${reassignToId}` : '';
      await apiClient.delete(`/faculty/${deleteTarget.id}${query}`);
      pushToast('success', 'Faculty Removed', `${deleteTarget.fullName} deleted.`);
      setDeleteTarget(null);
      setDependencyMsg(null);
      await loadData();
    } catch (err) {
      if (err instanceof ApiClientError && err.status === 409 && err.code === 'FACULTY_HAS_DEPENDENCIES') {
        setDependencyMsg(err.message);
      } else {
        pushToast('error', 'Delete Failed', err instanceof ApiClientError ? err.message : 'Error deleting faculty.');
        setDeleteTarget(null);
      }
    } finally {
      setDeleting(false);
    }
  };

  const filtered = useMemo(() => {
    return faculty.filter((f) => {
      if (deptFilter !== 'all' && String(f.departmentId) !== deptFilter) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        return (
          f.fullName.toLowerCase().includes(q) ||
          f.facultyCode.toLowerCase().includes(q) ||
          f.email.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [faculty, deptFilter, search]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 flex-1">
          <div className="relative flex-1 min-w-[220px] max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              aria-label="Search faculty"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search faculty name, code, or email..."
              className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>
          <select
            value={deptFilter}
            onChange={(e) => setDeptFilter(e.target.value)}
            aria-label="Filter by department"
            className="px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600"
          >
            <option value="all">All Departments</option>
            {departments.map((d) => (
              <option key={d.id} value={d.id}>
                {d.code} — {d.name}
              </option>
            ))}
          </select>
        </div>

        <button
          type="button"
          onClick={openCreate}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-indigo-700 hover:bg-indigo-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          Add Faculty
        </button>
      </div>

      {loading ? (
        <TableSkeleton />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Users}
          title="No faculty records match your filters"
          description="Add faculty members with weekly workload limits and slot preferences to enable CSP scheduling."
          actionLabel="Add Faculty Member"
          onAction={openCreate}
        />
      ) : (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                  <th className="px-4 py-3">Code</th>
                  <th className="px-4 py-3">Faculty Member</th>
                  <th className="px-4 py-3">Department</th>
                  <th className="px-4 py-3">Available Days</th>
                  <th className="px-4 py-3 text-right">Assigned / Cap</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filtered.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/70">
                    <td className="px-4 py-3 font-mono-tabular text-xs font-semibold text-slate-800 whitespace-nowrap">
                      {item.facultyCode}
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-medium text-slate-900">{item.fullName}</div>
                      <div className="text-xs text-slate-500">{item.email}</div>
                    </td>
                    <td className="px-4 py-3 text-slate-700 whitespace-nowrap">
                      {item.departmentCode} · {item.departmentName}
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-600">
                      {item.availableDays.join(', ')}
                      {(item.preferredHours.length > 0 || item.unavailableSlots.length > 0) && (
                        <div className="text-[11px] text-slate-500 mt-0.5">
                          {item.preferredHours.length} preferred · {item.unavailableSlots.length} blocked
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right font-mono-tabular whitespace-nowrap">
                      <span
                        className={
                          item.assignedWeeklyHours > item.maxWeeklyHours
                            ? 'text-red-700 font-semibold'
                            : 'text-slate-900'
                        }
                      >
                        {item.assignedWeeklyHours}h
                      </span>{' '}
                      <span className="text-slate-400">/ {item.maxWeeklyHours}h</span>
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => openEdit(item)}
                          aria-label={`Edit ${item.fullName}`}
                          className="p-1.5 text-slate-500 hover:text-indigo-700 rounded-lg"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setDependencyMsg(null);
                            setReassignToId('null');
                            setDeleteTarget(item);
                          }}
                          aria-label={`Delete ${item.fullName}`}
                          className="p-1.5 text-slate-500 hover:text-red-700 rounded-lg"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <Modal
        open={modalOpen}
        title={editing ? `Edit Faculty — ${editing.facultyCode}` : 'Add Faculty Member'}
        subtitle="Configure department assignment, weekly hour limits, and slot availability."
        onClose={() => setModalOpen(false)}
        maxWidthClass="max-w-2xl"
      >
        <form onSubmit={handleSave} className="space-y-4">
          {formError && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-800">
              {formError}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="faculty-code-input" className="block text-xs font-medium text-slate-700 mb-1">
                Faculty Code
              </label>
              <input
                id="faculty-code-input"
                type="text"
                required
                value={form.facultyCode}
                onChange={(e) => setForm({ ...form, facultyCode: e.target.value })}
                placeholder="FAC-112"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label htmlFor="faculty-name-input" className="block text-xs font-medium text-slate-700 mb-1">
                Full Name
              </label>
              <input
                id="faculty-name-input"
                type="text"
                required
                value={form.fullName}
                onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                placeholder="Dr. Grace Hopper"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label htmlFor="faculty-email-input" className="block text-xs font-medium text-slate-700 mb-1">
                Email
              </label>
              <input
                id="faculty-email-input"
                type="email"
                required
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="g.hopper@classclockwork.edu"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label htmlFor="faculty-dept-select" className="block text-xs font-medium text-slate-700 mb-1">
                Department
              </label>
              <select
                id="faculty-dept-select"
                value={form.departmentId}
                onChange={(e) => setForm({ ...form, departmentId: Number(e.target.value) })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
              >
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.code} — {d.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="faculty-max-hours-input" className="block text-xs font-medium text-slate-700 mb-1">
                Max Weekly Teaching Hours
              </label>
              <input
                id="faculty-max-hours-input"
                type="number"
                min={1}
                max={45}
                required
                value={form.maxWeeklyHours}
                onChange={(e) => setForm({ ...form, maxWeeklyHours: Number(e.target.value) })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg font-mono-tabular"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Available Days</label>
              <div className="flex flex-wrap gap-1.5 pt-1">
                {DAYS_OF_WEEK.map((day) => {
                  const active = form.availableDays.includes(day);
                  return (
                    <button
                      key={day}
                      type="button"
                      onClick={() => toggleDay(day)}
                      className={`px-2.5 py-1 text-xs font-medium rounded-md border transition-colors ${
                        active
                          ? 'bg-indigo-700 text-white border-indigo-700'
                          : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'
                      }`}
                    >
                      {day}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-medium text-slate-700">
                Slot Preferences &amp; Unavailability Matrix
              </label>
              <span className="text-[11px] text-slate-500">
                Click cell: Neutral → Preferred (Green) → Blocked (Red)
              </span>
            </div>
            <div className="border border-slate-200 rounded-lg overflow-x-auto">
              <table className="w-full text-center text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    <th className="px-2 py-1.5 text-left text-slate-600">Day</th>
                    {periods.map((p) => (
                      <th key={p} className="px-2 py-1.5 font-mono-tabular text-slate-600">
                        P{p}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {DAYS_OF_WEEK.map((day) => (
                    <tr key={day}>
                      <td className="px-2 py-1.5 text-left font-medium text-slate-700">{day}</td>
                      {periods.map((p) => {
                        const isPref = form.preferredHours.some((s) => s.day === day && s.periodNumber === p);
                        const isUnavail = form.unavailableSlots.some((s) => s.day === day && s.periodNumber === p);
                        return (
                          <td key={p} className="p-1">
                            <button
                              type="button"
                              onClick={() => cycleSlotStatus(day, p)}
                              className={`w-full py-1 rounded text-[11px] font-medium border transition-colors ${
                                isPref
                                  ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                                  : isUnavail
                                    ? 'bg-red-50 text-red-800 border-red-300'
                                    : 'bg-white text-slate-400 border-slate-200 hover:bg-slate-50'
                              }`}
                            >
                              {isPref ? 'Pref' : isUnavail ? 'Off' : '·'}
                            </button>
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 text-sm font-medium text-white bg-indigo-700 hover:bg-indigo-800 rounded-lg disabled:opacity-50"
            >
              {saving ? 'Saving...' : editing ? 'Update Faculty' : 'Create Faculty'}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={deleteTarget !== null}
        title={`Delete ${deleteTarget?.fullName ?? 'Faculty'}?`}
        description={
          dependencyMsg
            ? dependencyMsg
            : 'This permanently removes the faculty member from the SQLite database.'
        }
        confirmLabel={dependencyMsg ? 'Reassign & Delete' : 'Delete Faculty'}
        busy={deleting}
        onCancel={() => {
          setDeleteTarget(null);
          setDependencyMsg(null);
        }}
        onConfirm={() => handleDelete(Boolean(dependencyMsg))}
      >
        {dependencyMsg && (
          <div className="space-y-2">
            <label className="block text-xs font-medium text-slate-700">
              Reassign dependent subjects &amp; classes to:
            </label>
            <select
              value={reassignToId}
              onChange={(e) => setReassignToId(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
            >
              <option value="null">Unassign subjects (set faculty to unassigned)</option>
              {faculty
                .filter((f) => f.id !== deleteTarget?.id)
                .map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.facultyCode} — {f.fullName}
                  </option>
                ))}
            </select>
          </div>
        )}
      </ConfirmDialog>
    </div>
  );
}
