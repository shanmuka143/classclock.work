import React, { useCallback, useEffect, useState } from 'react';
import { CheckCircle2, AlertTriangle } from 'lucide-react';
import { DashboardSkeleton } from '../components/UI/LoadingSkeleton.tsx';
import { HorizontalBarList, VerticalBarChart } from '../components/UI/WorkloadChart.tsx';
import { useToast } from '../context/ToastContext.tsx';
import { apiClient, ApiClientError } from '../services/apiClient.ts';
import type { SchedulingRunDto } from '../types/api.ts';
import type { ValidationReport } from '../../shared/csp/types.ts';

interface WorkloadAnalytics {
  fairnessScore: number;
  avgUtilization: number;
  distribution: Array<{
    facultyId: number;
    facultyCode: string;
    fullName: string;
    departmentCode: string;
    assignedHours: number;
    maxWeeklyHours: number;
    sessions: number;
    utilizationRate: number;
    status: string;
  }>;
}

interface RoomAnalytics {
  totalWeeklyAvailablePeriods: number;
  rooms: Array<{
    roomId: number;
    roomCode: string;
    name: string;
    roomType: string;
    capacity: number;
    isAvailable: boolean;
    usedPeriods: number;
    availablePeriods: number;
    sessionsCount: number;
    utilizationPct: number;
  }>;
}

interface SchedulingAnalytics {
  latestRun: SchedulingRunDto | null;
  runsHistory: SchedulingRunDto[];
  validationSummary: {
    isHardValid: boolean;
    hardViolationsCount: number;
    softMetrics: ValidationReport['softMetrics'];
  };
  dailyDistribution: Array<{ day: string; meetings: number; periods: number; labs: number }>;
  departmentStats: Array<{
    departmentId: number;
    code: string;
    name: string;
    subjectCount: number;
    requiredMeetings: number;
    scheduledMeetings: number;
    completionPct: number;
  }>;
}

export function AnalyticsPage() {
  const { pushToast } = useToast();
  const [workload, setWorkload] = useState<WorkloadAnalytics | null>(null);
  const [rooms, setRooms] = useState<RoomAnalytics | null>(null);
  const [scheduling, setScheduling] = useState<SchedulingAnalytics | null>(null);
  const [loading, setLoading] = useState(true);

  const loadAnalytics = useCallback(async () => {
    setLoading(true);
    try {
      const [w, r, s] = await Promise.all([
        apiClient.get<WorkloadAnalytics>('/analytics/workload'),
        apiClient.get<RoomAnalytics>('/analytics/room-utilization'),
        apiClient.get<SchedulingAnalytics>('/analytics/scheduling'),
      ]);
      setWorkload(w);
      setRooms(r);
      setScheduling(s);
    } catch (err) {
      pushToast('error', 'Analytics Error', err instanceof ApiClientError ? err.message : 'Unable to fetch analytics.');
    } finally {
      setLoading(false);
    }
  }, [pushToast]);

  useEffect(() => {
    loadAnalytics();
  }, [loadAnalytics]);

  if (loading || !workload || !rooms || !scheduling) return <DashboardSkeleton />;

  const { validationSummary, latestRun, dailyDistribution, departmentStats, runsHistory } = scheduling;

  return (
    <div className="space-y-6">
      {/* Distinction Banner: Hard Validity vs Soft Optimization */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Hard-Constraint Validity</div>
          <div className="mt-2 flex items-center gap-2">
            {validationSummary.isHardValid ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-red-600" />
            )}
            <span
              className={`text-lg font-bold ${
                validationSummary.isHardValid ? 'text-emerald-700' : 'text-red-700'
              }`}
            >
              {validationSummary.isHardValid
                ? 'Valid (0 Clashes)'
                : `${validationSummary.hardViolationsCount} Violations`}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">Mandatory feasibility gate</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Soft Optimization Quality</div>
          <div className="text-2xl font-bold text-slate-900 font-mono-tabular mt-2">
            {validationSummary.softMetrics.overallScore} <span className="text-sm font-normal text-slate-500">/ 100</span>
          </div>
          <p className="text-xs text-slate-500 mt-1">Preferences, spread &amp; balance</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Workload Fairness Score</div>
          <div className="text-2xl font-bold text-slate-900 font-mono-tabular mt-2">
            {workload.fairnessScore}%
          </div>
          <p className="text-xs text-slate-500 mt-1">Avg utilization {workload.avgUtilization}%</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Latest Solver Performance</div>
          <div className="text-2xl font-bold text-slate-900 font-mono-tabular mt-2">
            {latestRun ? `${latestRun.durationMs} ms` : '—'}
          </div>
          <p className="text-xs text-slate-500 mt-1 font-mono-tabular">
            {latestRun ? `${latestRun.nodesExplored.toLocaleString()} nodes explored` : 'No runs recorded'}
          </p>
        </div>
      </div>

      {/* Daily Class Distribution + Soft Metrics Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white border border-slate-200 rounded-xl p-6">
          <h3 className="text-base font-semibold text-slate-900">Daily Academic Period Distribution</h3>
          <p className="text-xs text-slate-500 mt-0.5 mb-4">
            Total scheduled teaching hours across Monday through Friday.
          </p>
          <VerticalBarChart
            items={dailyDistribution.map((d) => ({
              label: d.day,
              value: d.periods,
              secondaryLabel: `${d.meetings} cls · ${d.labs} lab`,
            }))}
          />
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-6">
          <h3 className="text-base font-semibold text-slate-900">Department-Wise Completion</h3>
          <p className="text-xs text-slate-500 mt-0.5 mb-4">
            Scheduled meetings compared against total curriculum demand per department.
          </p>
          <HorizontalBarList
            items={departmentStats.map((d) => ({
              label: `${d.code} — ${d.name}`,
              sublabel: `${d.subjectCount} subjects`,
              value: d.scheduledMeetings,
              maxValue: d.requiredMeetings,
              tone: d.completionPct >= 100 ? 'emerald' : 'amber',
            }))}
          />

          <div className="mt-6 pt-4 border-t border-slate-200 grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
            <div>
              <div className="text-slate-500">Pref. Match</div>
              <div className="font-mono-tabular font-semibold text-slate-900 mt-0.5">
                {validationSummary.softMetrics.preferenceMatchRate}%
              </div>
            </div>
            <div>
              <div className="text-slate-500">Day Spread</div>
              <div className="font-mono-tabular font-semibold text-slate-900 mt-0.5">
                {validationSummary.softMetrics.subjectSpreadRate}%
              </div>
            </div>
            <div>
              <div className="text-slate-500">Room Fit</div>
              <div className="font-mono-tabular font-semibold text-slate-900 mt-0.5">
                {validationSummary.softMetrics.roomFitScore ?? 100}%
              </div>
            </div>
            <div>
              <div className="text-slate-500">Consec. Penalty</div>
              <div className="font-mono-tabular font-semibold text-slate-900 mt-0.5">
                {validationSummary.softMetrics.consecutivePenaltyCount}
              </div>
            </div>
            <div>
              <div className="text-slate-500">Batch Idle Gaps</div>
              <div className="font-mono-tabular font-semibold text-slate-900 mt-0.5">
                {validationSummary.softMetrics.batchGapCount}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Faculty Workload + Room Utilization */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white border border-slate-200 rounded-xl p-6">
          <h3 className="text-base font-semibold text-slate-900">Faculty Workload Distribution</h3>
          <p className="text-xs text-slate-500 mt-0.5 mb-4">
            Actual scheduled weekly hours against contractual maximums.
          </p>
          <HorizontalBarList
            unit="h"
            items={workload.distribution.map((w) => ({
              label: w.fullName,
              sublabel: `${w.departmentCode} · ${w.sessions} sessions`,
              value: w.assignedHours,
              maxValue: w.maxWeeklyHours,
              tone:
                w.status === 'overloaded'
                  ? 'red'
                  : w.status === 'high'
                    ? 'amber'
                    : 'indigo',
            }))}
          />
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-6">
          <h3 className="text-base font-semibold text-slate-900">Classroom &amp; Laboratory Utilization</h3>
          <p className="text-xs text-slate-500 mt-0.5 mb-4">
            Weekly occupied periods out of {rooms.totalWeeklyAvailablePeriods} teachable periods per room.
          </p>
          <HorizontalBarList
            unit="p"
            items={rooms.rooms.map((r) => ({
              label: `${r.roomCode} — ${r.name}`,
              sublabel: `${r.roomType} · ${r.capacity} cap`,
              value: r.usedPeriods,
              maxValue: r.availablePeriods,
              tone: r.roomType === 'lab' ? 'emerald' : 'slate',
            }))}
          />
        </div>
      </div>

      {/* Recent Solver Execution History */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200">
          <h3 className="text-base font-semibold text-slate-900">Solver Execution History</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                <th className="px-4 py-3">Run</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 text-right">Scheduled</th>
                <th className="px-4 py-3 text-right">Hard Clashes</th>
                <th className="px-4 py-3 text-right">Opt. Score</th>
                <th className="px-4 py-3 text-right">Nodes</th>
                <th className="px-4 py-3 text-right">Runtime</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {runsHistory.map((r) => (
                <tr key={r.id}>
                  <td className="px-4 py-3 font-mono-tabular text-xs font-semibold text-slate-900">
                    #{r.id} {r.isPublished ? '(Published)' : ''}
                  </td>
                  <td className="px-4 py-3 capitalize text-slate-700">{r.status}</td>
                  <td className="px-4 py-3 text-right font-mono-tabular">
                    {r.scheduledMeetings} / {r.totalMeetings}
                  </td>
                  <td className="px-4 py-3 text-right font-mono-tabular">
                    <span className={r.hardConflictsCount === 0 ? 'text-emerald-700' : 'text-red-700'}>
                      {r.hardConflictsCount}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right font-mono-tabular">{r.optimizationScore}</td>
                  <td className="px-4 py-3 text-right font-mono-tabular">
                    {r.nodesExplored.toLocaleString()}
                  </td>
                  <td className="px-4 py-3 text-right font-mono-tabular">{r.durationMs} ms</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
