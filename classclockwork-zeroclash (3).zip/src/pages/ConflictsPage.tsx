import React, { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertOctagon, CheckCircle2, RefreshCw } from 'lucide-react';
import { TableSkeleton } from '../components/UI/LoadingSkeleton.tsx';
import { useToast } from '../context/ToastContext.tsx';
import { apiClient, ApiClientError } from '../services/apiClient.ts';
import type { TimetablePayloadDto } from '../types/api.ts';
import type { ValidationReport } from '../../shared/csp/types.ts';

export function ConflictsPage() {
  const { pushToast } = useToast();
  const navigate = useNavigate();
  const [data, setData] = useState<TimetablePayloadDto | null>(null);
  const [loading, setLoading] = useState(true);
  const [verifying, setVerifying] = useState(false);

  const loadAudit = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiClient.get<TimetablePayloadDto>('/timetable');
      setData(res);
    } catch (err) {
      pushToast('error', 'Audit Failed', err instanceof ApiClientError ? err.message : 'Unable to load validation report.');
    } finally {
      setLoading(false);
    }
  }, [pushToast]);

  useEffect(() => {
    loadAudit();
  }, [loadAudit]);

  const handleIndependentVerify = async () => {
    if (!data?.run) return;
    setVerifying(true);
    try {
      const report = await apiClient.post<ValidationReport>('/timetable/validate', {
        runId: data.run.id,
      });
      setData((prev) => (prev ? { ...prev, validation: report } : prev));
      pushToast(
        report.isValid ? 'success' : 'error',
        'Independent Validation Complete',
        report.isValid
          ? 'Zero hard constraint violations confirmed across all scheduled meetings.'
          : `${report.hardViolations.length} hard violation(s) detected.`
      );
    } catch (err) {
      pushToast('error', 'Validation Failed', err instanceof ApiClientError ? err.message : 'Validation request error.');
    } finally {
      setVerifying(false);
    }
  };

  if (loading) return <TableSkeleton rows={6} />;

  const validation = data?.validation;
  const unscheduled = data?.run?.unscheduledList ?? [];

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="text-xs text-slate-500">
            Independent Hard &amp; Soft Constraint Verification Engine
            {data?.run ? ` · Active Run #${data.run.id}` : ''}
            {validation ? ` · Soft Score ${validation.softMetrics.overallScore}/100` : ''}
          </div>
          <div className="mt-1.5 flex items-center gap-2.5">
            {validation?.isValid ? (
              <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
            ) : (
              <AlertOctagon className="w-6 h-6 text-red-600 shrink-0" />
            )}
            <h2 className="text-lg font-bold text-slate-900">
              {validation?.isValid
                ? 'All Hard Constraints Satisfied (Zero Clashes)'
                : `${validation?.hardViolations.length ?? 0} Hard Constraint Violation(s) Detected`}
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={handleIndependentVerify}
            disabled={verifying || !data?.run}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-indigo-700 hover:bg-indigo-800 rounded-lg disabled:opacity-50 whitespace-nowrap"
          >
            <RefreshCw className={`w-4 h-4 ${verifying ? 'animate-spin' : ''}`} />
            {verifying ? 'Verifying...' : 'Re-Run Independent Validator'}
          </button>
        </div>
      </div>

      {/* Hard Constraint Checks Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="text-base font-semibold text-slate-900">Hard Constraint Violation Log</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Verifies faculty double-booking, room clashes, batch overlaps, capacity, room type, equipment, lunch periods, availability, weekly hour caps, faculty assignment, and duplicate sessions.
            </p>
          </div>
          <button
            type="button"
            onClick={() => navigate('/timetable')}
            className="text-xs font-medium text-indigo-700 hover:text-indigo-900 whitespace-nowrap"
          >
            Edit in Timetable
          </button>
        </div>

        {!validation || validation.hardViolations.length === 0 ? (
          <div className="p-8 text-center">
            <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-900">Zero Hard Constraint Violations</p>
            <p className="text-xs text-slate-500 mt-1">
              Every scheduled meeting satisfies room capacity, equipment, faculty availability, lunch protection, and collision rules.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {validation.hardViolations.map((v, idx) => (
              <div key={idx} className="px-6 py-4 flex items-start justify-between gap-4">
                <div>
                  <div className="text-xs font-mono-tabular font-semibold text-red-700">
                    {v.type}
                    {v.day ? ` · ${v.day}` : ''}
                    {v.periodNumber ? ` P${v.periodNumber}` : ''}
                  </div>
                  <p className="text-sm text-slate-900 mt-1">{v.message}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Unscheduled Meetings Diagnostics */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="text-base font-semibold text-slate-900">
              Unscheduled Class Meetings ({unscheduled.length})
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Meetings that could not be placed without violating a hard constraint during the latest solver run.
            </p>
          </div>
          <button
            type="button"
            onClick={() => navigate('/generator')}
            className="text-xs font-medium text-indigo-700 hover:text-indigo-900 whitespace-nowrap"
          >
            Adjust &amp; Regenerate
          </button>
        </div>

        {unscheduled.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-600">
            100% of required weekly curriculum meetings were placed in the active run.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {unscheduled.map((u) => (
              <div key={u.variableId} className="px-6 py-4">
                <div className="text-sm font-semibold text-slate-900">
                  {u.subjectCode} — {u.subjectName} (Session #{u.sessionIndex}, {u.duration}h)
                </div>
                <p className="text-xs text-amber-800 mt-1">{u.reason}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
