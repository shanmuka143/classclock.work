import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { GraduationCap, Pencil, Plus, Search, Trash2 } from 'lucide-react';
import { ConfirmDialog } from '../components/UI/ConfirmDialog.tsx';
import { EmptyState } from '../components/UI/EmptyState.tsx';
import { TableSkeleton } from '../components/UI/LoadingSkeleton.tsx';
import { Modal } from '../components/UI/Modal.tsx';
import { useToast } from '../context/ToastContext.tsx';
import { apiClient, ApiClientError } from '../services/apiClient.ts';
import type { AcademicSettingsDto, BatchDto, DepartmentDto } from '../types/api.ts';

interface BatchFormState {
  batchCode: string;
  name: string;
  departmentId: number;
  semester: number;
  studentStrength: number;
}

export function BatchesPage() {
  const { pushToast } = useToast();
  const [batches, setBatches] = useState<BatchDto[]>([]);
  const [departments, setDepartments] = useState<DepartmentDto[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState('all');

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<BatchDto | null>(null);
  const [form, setForm] = useState<BatchFormState>({
    batchCode: '',
    name: '',
    departmentId: 1,
    semester: 3,
    studentStrength: 55,
  });
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<BatchDto | null>(null);
  const [deleting, setDeleting] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [batchList, settings] = await Promise.all([
        apiClient.get<BatchDto[]>('/batches'),
        apiClient.get<AcademicSettingsDto>('/settings'),
      ]);
      setBatches(batchList);
      setDepartments(settings.departments);
    } catch (err) {
      pushToast('error', 'Load Failed', err instanceof ApiClientError ? err.message : 'Unable to fetch batches.');
    } finally {
      setLoading(false);
    }
  }, [pushToast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const openCreate = () => {
    setEditing(null);
    setForm({
      batchCode: '',
      name: '',
      departmentId: departments[0]?.id ?? 1,
      semester: 3,
      studentStrength: 55,
    });
    setFormError(null);
    setModalOpen(true);
  };

  const openEdit = (b: BatchDto) => {
    setEditing(b);
    setForm({
      batchCode: b.batchCode,
      name: b.name,
      departmentId: b.departmentId,
      semester: b.semester,
      studentStrength: b.studentStrength,
    });
    setFormError(null);
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (!form.batchCode.trim() || !form.name.trim()) {
      setFormError('Batch code and batch name are required.');
      return;
    }

    setSaving(true);
    try {
      if (editing) {
        await apiClient.put(`/batches/${editing.id}`, form);
        pushToast('success', 'Batch Updated', `${form.batchCode} saved.`);
      } else {
        await apiClient.post('/batches', form);
        pushToast('success', 'Batch Created', `${form.batchCode} added.`);
      }
      setModalOpen(false);
      await loadData();
    } catch (err) {
      setFormError(err instanceof ApiClientError ? err.message : 'Unable to save batch.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await apiClient.delete(`/batches/${deleteTarget.id}`);
      pushToast('success', 'Batch Removed', `${deleteTarget.batchCode} deleted.`);
      setDeleteTarget(null);
      await loadData();
    } catch (err) {
      pushToast('error', 'Cannot Delete Batch', err instanceof ApiClientError ? err.message : 'Delete failed.');
      setDeleteTarget(null);
    } finally {
      setDeleting(false);
    }
  };

  const filtered = useMemo(() => {
    return batches.filter((b) => {
      if (deptFilter !== 'all' && String(b.departmentId) !== deptFilter) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        return (
          b.batchCode.toLowerCase().includes(q) ||
          b.name.toLowerCase().includes(q) ||
          b.departmentName.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [batches, deptFilter, search]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 flex-1">
          <div className="relative flex-1 min-w-[220px] max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              aria-label="Search batches"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search batch code or name..."
              className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>
          <select
            value={deptFilter}
            onChange={(e) => setDeptFilter(e.target.value)}
            aria-label="Filter by department"
            className="px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
          >
            <option value="all">All Departments</option>
            {departments.map((d) => (
              <option key={d.id} value={d.id}>
                {d.code} — {d.name}
              </option>
            ))}
          </select>
        </div>

        <button
          type="button"
          onClick={openCreate}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-indigo-700 hover:bg-indigo-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          Add Batch
        </button>
      </div>

      {loading ? (
        <TableSkeleton />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={GraduationCap}
          title="No student batches found"
          description="Register student cohorts with semester and enrollment strength for room capacity checks."
          actionLabel="Add Student Batch"
          onAction={openCreate}
        />
      ) : (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                  <th className="px-4 py-3">Batch Code</th>
                  <th className="px-4 py-3">Cohort Name</th>
                  <th className="px-4 py-3">Department</th>
                  <th className="px-4 py-3 text-right">Semester</th>
                  <th className="px-4 py-3 text-right">Student Strength</th>
                  <th className="px-4 py-3 text-right">Subjects</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filtered.map((b) => (
                  <tr key={b.id} className="hover:bg-slate-50/70">
                    <td className="px-4 py-3 font-mono-tabular text-xs font-semibold text-slate-900">
                      {b.batchCode}
                    </td>
                    <td className="px-4 py-3 font-medium text-slate-900">{b.name}</td>
                    <td className="px-4 py-3 text-slate-700">
                      {b.departmentCode} · {b.departmentName}
                    </td>
                    <td className="px-4 py-3 text-right font-mono-tabular text-slate-700">
                      Sem {b.semester}
                    </td>
                    <td className="px-4 py-3 text-right font-mono-tabular text-slate-900">
                      {b.studentStrength}
                    </td>
                    <td className="px-4 py-3 text-right font-mono-tabular text-slate-700">
                      {b.subjectCount}
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => openEdit(b)}
                          aria-label={`Edit ${b.batchCode}`}
                          className="p-1.5 text-slate-500 hover:text-indigo-700 rounded-lg"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeleteTarget(b)}
                          aria-label={`Delete ${b.batchCode}`}
                          className="p-1.5 text-slate-500 hover:text-red-700 rounded-lg"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <Modal
        open={modalOpen}
        title={editing ? `Edit Batch — ${editing.batchCode}` : 'Add Student Batch'}
        onClose={() => setModalOpen(false)}
        maxWidthClass="max-w-lg"
      >
        <form onSubmit={handleSave} className="space-y-4">
          {formError && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-800">
              {formError}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="batch-code-input" className="block text-xs font-medium text-slate-700 mb-1">
                Batch Code
              </label>
              <input
                id="batch-code-input"
                type="text"
                required
                value={form.batchCode}
                onChange={(e) => setForm({ ...form, batchCode: e.target.value })}
                placeholder="CSE-7A"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label htmlFor="batch-name-input" className="block text-xs font-medium text-slate-700 mb-1">
                Batch Name
              </label>
              <input
                id="batch-name-input"
                type="text"
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="CSE Year 4 · Section A"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label htmlFor="batch-dept-select" className="block text-xs font-medium text-slate-700 mb-1">
                Department
              </label>
              <select
                id="batch-dept-select"
                value={form.departmentId}
                onChange={(e) => setForm({ ...form, departmentId: Number(e.target.value) })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
              >
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.code} — {d.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="batch-semester-input" className="block text-xs font-medium text-slate-700 mb-1">
                Semester
              </label>
              <input
                id="batch-semester-input"
                type="number"
                min={1}
                max={10}
                required
                value={form.semester}
                onChange={(e) => setForm({ ...form, semester: Number(e.target.value) })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg font-mono-tabular"
              />
            </div>
            <div className="sm:col-span-2">
              <label htmlFor="batch-strength-input" className="block text-xs font-medium text-slate-700 mb-1">
                Student Strength (Enrollment Count)
              </label>
              <input
                id="batch-strength-input"
                type="number"
                min={1}
                max={500}
                required
                value={form.studentStrength}
                onChange={(e) => setForm({ ...form, studentStrength: Number(e.target.value) })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg font-mono-tabular"
              />
            </div>
          </div>

          <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 text-sm font-medium text-white bg-indigo-700 hover:bg-indigo-800 rounded-lg disabled:opacity-50"
            >
              {saving ? 'Saving...' : editing ? 'Update Batch' : 'Create Batch'}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={deleteTarget !== null}
        title={`Delete ${deleteTarget?.batchCode ?? 'Batch'}?`}
        description="Batches with assigned subjects cannot be deleted until those subjects are reassigned or removed."
        confirmLabel="Delete Batch"
        busy={deleting}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
      />
    </div>
  );
}
