import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Building2, Pencil, Plus, Search, Trash2 } from 'lucide-react';
import { ConfirmDialog } from '../components/UI/ConfirmDialog.tsx';
import { EmptyState } from '../components/UI/EmptyState.tsx';
import { TableSkeleton } from '../components/UI/LoadingSkeleton.tsx';
import { Modal } from '../components/UI/Modal.tsx';
import { useToast } from '../context/ToastContext.tsx';
import { apiClient, ApiClientError } from '../services/apiClient.ts';
import type { RoomDto } from '../types/api.ts';
import type { RoomType } from '../../shared/csp/types.ts';

interface RoomFormState {
  roomCode: string;
  name: string;
  roomType: RoomType;
  capacity: number;
  equipmentText: string;
  isAvailable: boolean;
}

export function RoomsPage() {
  const { pushToast } = useToast();
  const [rooms, setRooms] = useState<RoomDto[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<RoomDto | null>(null);
  const [form, setForm] = useState<RoomFormState>({
    roomCode: '',
    name: '',
    roomType: 'lecture',
    capacity: 65,
    equipmentText: 'Projector, Whiteboard',
    isAvailable: true,
  });
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<RoomDto | null>(null);
  const [deleting, setDeleting] = useState(false);

  const loadRooms = useCallback(async () => {
    setLoading(true);
    try {
      const list = await apiClient.get<RoomDto[]>('/rooms');
      setRooms(list);
    } catch (err) {
      pushToast('error', 'Load Failed', err instanceof ApiClientError ? err.message : 'Unable to load rooms.');
    } finally {
      setLoading(false);
    }
  }, [pushToast]);

  useEffect(() => {
    loadRooms();
  }, [loadRooms]);

  const openCreate = () => {
    setEditing(null);
    setForm({
      roomCode: '',
      name: '',
      roomType: 'lecture',
      capacity: 65,
      equipmentText: 'Projector, Whiteboard',
      isAvailable: true,
    });
    setFormError(null);
    setModalOpen(true);
  };

  const openEdit = (r: RoomDto) => {
    setEditing(r);
    setForm({
      roomCode: r.roomCode,
      name: r.name,
      roomType: r.roomType,
      capacity: r.capacity,
      equipmentText: r.equipment.join(', '),
      isAvailable: r.isAvailable,
    });
    setFormError(null);
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (!form.roomCode.trim() || !form.name.trim()) {
      setFormError('Room code and room name are required.');
      return;
    }

    const payload = {
      roomCode: form.roomCode.trim(),
      name: form.name.trim(),
      roomType: form.roomType,
      capacity: form.capacity,
      equipment: form.equipmentText
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean),
      isAvailable: form.isAvailable,
    };

    setSaving(true);
    try {
      if (editing) {
        await apiClient.put(`/rooms/${editing.id}`, payload);
        pushToast('success', 'Room Updated', `${payload.roomCode} updated.`);
      } else {
        await apiClient.post('/rooms', payload);
        pushToast('success', 'Room Added', `${payload.roomCode} created.`);
      }
      setModalOpen(false);
      await loadRooms();
    } catch (err) {
      setFormError(err instanceof ApiClientError ? err.message : 'Unable to save room.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await apiClient.delete(`/rooms/${deleteTarget.id}`);
      pushToast('success', 'Room Deleted', `${deleteTarget.roomCode} removed.`);
      setDeleteTarget(null);
      await loadRooms();
    } catch (err) {
      pushToast('error', 'Cannot Delete Room', err instanceof ApiClientError ? err.message : 'Delete failed.');
      setDeleteTarget(null);
    } finally {
      setDeleting(false);
    }
  };

  const filtered = useMemo(() => {
    return rooms.filter((r) => {
      if (typeFilter !== 'all' && r.roomType !== typeFilter) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        return (
          r.roomCode.toLowerCase().includes(q) ||
          r.name.toLowerCase().includes(q) ||
          r.equipment.some((e) => e.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [rooms, typeFilter, search]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 flex-1">
          <div className="relative flex-1 min-w-[220px] max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              aria-label="Search rooms"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search room code, name, or equipment..."
              className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-200/70 rounded-lg">
            {(['all', 'lecture', 'lab', 'seminar'] as const).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTypeFilter(t)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md capitalize transition-colors whitespace-nowrap ${
                  typeFilter === t
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {t === 'all' ? 'All Types' : t}
              </button>
            ))}
          </div>
        </div>

        <button
          type="button"
          onClick={openCreate}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-indigo-700 hover:bg-indigo-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          Add Room
        </button>
      </div>

      {loading ? (
        <TableSkeleton />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Building2}
          title="No classrooms or labs found"
          description="Add rooms with capacity and equipment specifications so the CSP engine can allocate classes."
          actionLabel="Add Room"
          onAction={openCreate}
        />
      ) : (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                  <th className="px-4 py-3">Code</th>
                  <th className="px-4 py-3">Room Name</th>
                  <th className="px-4 py-3">Type</th>
                  <th className="px-4 py-3">Equipment</th>
                  <th className="px-4 py-3 text-right">Capacity</th>
                  <th className="px-4 py-3">Availability</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filtered.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50/70">
                    <td className="px-4 py-3 font-mono-tabular text-xs font-semibold text-slate-900">
                      {r.roomCode}
                    </td>
                    <td className="px-4 py-3 font-medium text-slate-900">{r.name}</td>
                    <td className="px-4 py-3 capitalize text-slate-700">{r.roomType}</td>
                    <td className="px-4 py-3 text-xs text-slate-600">
                      {r.equipment.length > 0 ? r.equipment.join(', ') : 'None'}
                    </td>
                    <td className="px-4 py-3 text-right font-mono-tabular text-slate-900">
                      {r.capacity} seats
                    </td>
                    <td className="px-4 py-3 text-xs font-medium">
                      <span className={r.isAvailable ? 'text-emerald-700' : 'text-red-700'}>
                        {r.isAvailable ? 'Available' : 'Unavailable'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => openEdit(r)}
                          aria-label={`Edit ${r.roomCode}`}
                          className="p-1.5 text-slate-500 hover:text-indigo-700 rounded-lg"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeleteTarget(r)}
                          aria-label={`Delete ${r.roomCode}`}
                          className="p-1.5 text-slate-500 hover:text-red-700 rounded-lg"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <Modal
        open={modalOpen}
        title={editing ? `Edit Room — ${editing.roomCode}` : 'Add Classroom or Laboratory'}
        onClose={() => setModalOpen(false)}
        maxWidthClass="max-w-lg"
      >
        <form onSubmit={handleSave} className="space-y-4">
          {formError && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-800">
              {formError}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="room-code-input" className="block text-xs font-medium text-slate-700 mb-1">
                Room Code
              </label>
              <input
                id="room-code-input"
                type="text"
                required
                value={form.roomCode}
                onChange={(e) => setForm({ ...form, roomCode: e.target.value })}
                placeholder="LH-305"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label htmlFor="room-name-input" className="block text-xs font-medium text-slate-700 mb-1">
                Room Name
              </label>
              <input
                id="room-name-input"
                type="text"
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="South Lecture Hall 305"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label htmlFor="room-type-select" className="block text-xs font-medium text-slate-700 mb-1">
                Room Type
              </label>
              <select
                id="room-type-select"
                value={form.roomType}
                onChange={(e) => setForm({ ...form, roomType: e.target.value as RoomType })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
              >
                <option value="lecture">Lecture Hall</option>
                <option value="lab">Laboratory</option>
                <option value="seminar">Seminar Room</option>
              </select>
            </div>
            <div>
              <label htmlFor="room-capacity-input" className="block text-xs font-medium text-slate-700 mb-1">
                Seating Capacity
              </label>
              <input
                id="room-capacity-input"
                type="number"
                min={1}
                max={600}
                required
                value={form.capacity}
                onChange={(e) => setForm({ ...form, capacity: Number(e.target.value) })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg font-mono-tabular"
              />
            </div>
          </div>

          <div>
            <label htmlFor="room-equipment-input" className="block text-xs font-medium text-slate-700 mb-1">
              Available Equipment (comma-separated)
            </label>
            <input
              id="room-equipment-input"
              type="text"
              value={form.equipmentText}
              onChange={(e) => setForm({ ...form, equipmentText: e.target.value })}
              placeholder="Projector, Workstations, Smartboard"
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
            />
          </div>

          <label className="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={form.isAvailable}
              onChange={(e) => setForm({ ...form, isAvailable: e.target.checked })}
              className="rounded border-slate-300 text-indigo-700 focus:ring-indigo-600"
            />
            Room is active and available for scheduling
          </label>

          <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 text-sm font-medium text-white bg-indigo-700 hover:bg-indigo-800 rounded-lg disabled:opacity-50"
            >
              {saving ? 'Saving...' : editing ? 'Update Room' : 'Create Room'}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={deleteTarget !== null}
        title={`Delete ${deleteTarget?.roomCode ?? 'Room'}?`}
        description="Rooms referenced by active timetable allocations cannot be deleted until classes are reassigned."
        confirmLabel="Delete Room"
        busy={deleting}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
      />
    </div>
  );
}
