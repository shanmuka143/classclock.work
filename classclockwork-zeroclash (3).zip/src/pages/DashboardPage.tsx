import React, { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Cpu,
  RefreshCw,
} from 'lucide-react';
import { DashboardSkeleton } from '../components/UI/LoadingSkeleton.tsx';
import { HorizontalBarList } from '../components/UI/WorkloadChart.tsx';
import { apiClient, ApiClientError } from '../services/apiClient.ts';
import type { DashboardStatsDto } from '../types/api.ts';

export function DashboardPage() {
  const navigate = useNavigate();
  const [stats, setStats] = useState<DashboardStatsDto | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadStats = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await apiClient.get<DashboardStatsDto>('/dashboard/stats');
      setStats(data);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'Failed to load dashboard statistics.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadStats();
  }, [loadStats]);

  if (loading) return <DashboardSkeleton />;

  if (error || !stats) {
    return (
      <div className="bg-white border border-red-200 rounded-xl p-6">
        <p className="text-sm text-red-700 font-medium">{error ?? 'Unable to load dashboard.'}</p>
        <button
          type="button"
          onClick={loadStats}
          className="mt-3 px-4 py-2 text-xs font-medium text-white bg-indigo-700 hover:bg-indigo-800 rounded-lg"
        >
          Retry
        </button>
      </div>
    );
  }

  const { counts, latestRun, facultyWorkload, recentLogs } = stats;

  return (
    <div className="space-y-6">
      {/* Top Action / Status Banner */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span>Academic Scheduling Overview</span>
            <span aria-hidden="true">·</span>
            <span>{counts.departments} Departments</span>
            <span aria-hidden="true">·</span>
            <span>
              {latestRun ? `Run #${latestRun.id} (${latestRun.status})` : 'No schedule generated'}
            </span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 mt-1">
            {counts.detectedConflicts === 0 && counts.scheduledClasses > 0
              ? 'Current Timetable is Hard-Constraint Valid'
              : counts.detectedConflicts > 0
                ? `${counts.detectedConflicts} Hard Constraint Violation(s) Detected`
                : 'Ready to Generate Academic Timetable'}
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            {counts.scheduledClasses} of {counts.totalRequiredMeetings} weekly class meetings scheduled
            {latestRun ? ` · Soft Optimization Score: ${latestRun.optimizationScore}/100` : ''}.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={loadStats}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap"
          >
            <RefreshCw className="w-4 h-4" />
            Refresh
          </button>
          <button
            type="button"
            onClick={() => navigate('/timetable')}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-indigo-700 hover:bg-indigo-800 rounded-lg transition-colors whitespace-nowrap"
          >
            View Timetable
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* KPI Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Departments &amp; Batches</div>
          <div className="text-2xl font-bold text-slate-900 font-mono-tabular mt-2">
            {counts.departments} <span className="text-sm font-normal text-slate-500">/ {counts.batches} batches</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Faculty &amp; Subjects</div>
          <div className="text-2xl font-bold text-slate-900 font-mono-tabular mt-2">
            {counts.faculty} <span className="text-sm font-normal text-slate-500">/ {counts.subjects} subjects</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Classrooms &amp; Labs</div>
          <div className="text-2xl font-bold text-slate-900 font-mono-tabular mt-2">
            {counts.rooms} <span className="text-sm font-normal text-slate-500">({counts.classrooms} hall · {counts.labs} lab)</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Conflict Verification</div>
          <div className="mt-2 flex items-center gap-2">
            {counts.detectedConflicts === 0 ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-red-600 shrink-0" />
            )}
            <span
              className={`text-2xl font-bold font-mono-tabular ${
                counts.detectedConflicts === 0 ? 'text-emerald-700' : 'text-red-700'
              }`}
            >
              {counts.detectedConflicts}
            </span>
            <span className="text-xs text-slate-500">hard clashes</span>
          </div>
        </div>
      </div>

      {/* Scheduled vs Unscheduled + Solver Run Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-6">
          <div className="flex items-center justify-between gap-4 mb-5">
            <div>
              <h3 className="text-base font-semibold text-slate-900">Faculty Teaching Workload</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Scheduled weekly hours compared to each faculty member&apos;s maximum teaching cap.
              </p>
            </div>
            <button
              type="button"
              onClick={() => navigate('/analytics')}
              className="text-xs font-medium text-indigo-700 hover:text-indigo-900 whitespace-nowrap"
            >
              Full Analytics
            </button>
          </div>

          <HorizontalBarList
            unit="h"
            items={facultyWorkload.map((fw) => ({
              label: fw.fullName,
              sublabel: fw.departmentCode,
              value: fw.scheduledHours,
              maxValue: fw.maxWeeklyHours,
              tone:
                fw.scheduledHours > fw.maxWeeklyHours
                  ? 'red'
                  : fw.utilizationPct >= 85
                    ? 'amber'
                    : 'indigo',
            }))}
          />
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between">
          <div>
            <h3 className="text-base font-semibold text-slate-900">Timetable Generation Status</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Latest CSP backtracking solver execution metrics from SQLite.
            </p>

            <dl className="mt-5 divide-y divide-slate-100 text-sm">
              <div className="py-2.5 flex items-center justify-between">
                <dt className="text-slate-600">Scheduled Meetings</dt>
                <dd className="font-mono-tabular font-semibold text-slate-900">
                  {counts.scheduledClasses}
                </dd>
              </div>
              <div className="py-2.5 flex items-center justify-between">
                <dt className="text-slate-600">Unscheduled Meetings</dt>
                <dd
                  className={`font-mono-tabular font-semibold ${
                    counts.unscheduledClasses === 0 ? 'text-emerald-700' : 'text-amber-700'
                  }`}
                >
                  {counts.unscheduledClasses}
                </dd>
              </div>
              <div className="py-2.5 flex items-center justify-between">
                <dt className="text-slate-600">Optimization Score</dt>
                <dd className="font-mono-tabular font-semibold text-slate-900">
                  {latestRun ? `${latestRun.optimizationScore} / 100` : '—'}
                </dd>
              </div>
              <div className="py-2.5 flex items-center justify-between">
                <dt className="text-slate-600">Search Nodes Explored</dt>
                <dd className="font-mono-tabular text-slate-800">
                  {latestRun ? latestRun.nodesExplored.toLocaleString() : '—'}
                </dd>
              </div>
              <div className="py-2.5 flex items-center justify-between">
                <dt className="text-slate-600">Solver Runtime</dt>
                <dd className="font-mono-tabular text-slate-800">
                  {latestRun ? `${latestRun.durationMs} ms` : '—'}
                </dd>
              </div>
            </dl>

            {recentLogs.length > 0 && (
              <div className="mt-5 pt-4 border-t border-slate-200">
                <div className="text-xs font-medium text-slate-700 mb-2">Latest Solver Log</div>
                <p className="text-xs text-slate-600 leading-relaxed">{recentLogs[0].message}</p>
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={() => navigate('/generator')}
            className="mt-6 w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
          >
            <Cpu className="w-4 h-4" />
            Open CSP Generator
          </button>
        </div>
      </div>
    </div>
  );
}
