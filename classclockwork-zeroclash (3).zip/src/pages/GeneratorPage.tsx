import React, { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Cpu,
  Play,
  Square,
} from 'lucide-react';
import { useToast } from '../context/ToastContext.tsx';
import { apiClient, ApiClientError } from '../services/apiClient.ts';
import type { SchedulingRunDto } from '../types/api.ts';
import type {
  CspAllocation,
  CspBatch,
  CspFaculty,
  CspProgress,
  CspRoom,
  CspSolverResult,
  CspSubject,
  CspTimeSlot,
} from '../../shared/csp/types.ts';
import type { WorkerOutboundMessage } from '../workers/scheduler.worker.ts';

interface SolverPayloadResponse {
  subjects: CspSubject[];
  faculty: CspFaculty[];
  batches: CspBatch[];
  rooms: CspRoom[];
  timeSlots: CspTimeSlot[];
  lockedAllocations: CspAllocation[];
}

export function GeneratorPage() {
  const { pushToast } = useToast();
  const navigate = useNavigate();
  const workerRef = useRef<Worker | null>(null);
  const watchdogRef = useRef<number | null>(null);
  const isMountedRef = useRef(true);

  const [maxNodes, setMaxNodes] = useState(150000);
  const [timeoutMs, setTimeoutMs] = useState(12000);
  const [enableMrv, setEnableMrv] = useState(true);
  const [enableLcv, setEnableLcv] = useState(true);
  const [enableForwardChecking, setEnableForwardChecking] = useState(true);
  const [allowPartialFallback, setAllowPartialFallback] = useState(true);
  const [preserveLocked, setPreserveLocked] = useState(false);
  const [publishImmediately, setPublishImmediately] = useState(true);

  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState<CspProgress | null>(null);
  const [lastResult, setLastResult] = useState<CspSolverResult | null>(null);
  const [savedRun, setSavedRun] = useState<SchedulingRunDto | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const clearWatchdog = () => {
    if (watchdogRef.current !== null) {
      window.clearTimeout(watchdogRef.current);
      watchdogRef.current = null;
    }
  };

  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
      clearWatchdog();
      if (workerRef.current) {
        workerRef.current.terminate();
        workerRef.current = null;
      }
    };
  }, []);

  const persistWorkerResult = async (result: CspSolverResult) => {
    try {
      const saved = await apiClient.post<{ run: SchedulingRunDto }>('/timetable/save-generated', {
        status: result.status,
        totalMeetings: result.totalMeetings,
        scheduledMeetings: result.scheduledMeetings,
        unscheduledMeetings: result.unscheduledMeetings,
        nodesExplored: result.nodesExplored,
        durationMs: result.durationMs,
        publishImmediately,
        config: {
          maxNodes,
          timeoutMs,
          enableMrv,
          enableLcv,
          enableForwardChecking,
          allowPartialFallback,
          preserveLocked,
        },
        allocations: result.allocations,
      });
      if (!isMountedRef.current) return;
      setSavedRun(saved.run);
      pushToast(
        result.unscheduledMeetings.length === 0 ? 'success' : 'info',
        'Schedule Persisted to SQLite',
        `${result.scheduledMeetings}/${result.totalMeetings} meetings saved (Run #${saved.run.id}).`
      );
    } catch (err) {
      if (!isMountedRef.current) return;
      const msg = err instanceof ApiClientError ? err.message : 'Failed to persist generated timetable.';
      setErrorMsg(msg);
      pushToast('error', 'Persistence Failed', msg);
    }
  };

  const handleRunInWorker = async () => {
    setErrorMsg(null);
    setSavedRun(null);
    setLastResult(null);
    setRunning(true);
    setProgress({
      nodesExplored: 0,
      assignedCount: 0,
      totalVariables: 0,
      bestAssignedCount: 0,
      elapsedMs: 0,
      phase: 'initializing',
    });

    try {
      const solverPayload = await apiClient.get<SolverPayloadResponse>(
        `/timetable/solver-payload?preserveLocked=${preserveLocked}`
      );
      if (!isMountedRef.current) return;

      if (typeof Worker === 'undefined') {
        const outcome = await apiClient.post<{ run: SchedulingRunDto; result: CspSolverResult }>(
          '/timetable/generate',
          {
            maxNodes,
            timeoutMs,
            enableMrv,
            enableLcv,
            enableForwardChecking,
            allowPartialFallback,
            publishImmediately,
            preserveLocked,
          }
        );
        if (!isMountedRef.current) return;
        setLastResult(outcome.result);
        setSavedRun(outcome.run);
        setRunning(false);
        return;
      }

      const worker = new Worker(new URL('../workers/scheduler.worker.ts', import.meta.url), {
        type: 'module',
      });
      workerRef.current = worker;

      clearWatchdog();
      watchdogRef.current = window.setTimeout(() => {
        if (workerRef.current) {
          workerRef.current.terminate();
          workerRef.current = null;
        }
        if (isMountedRef.current) {
          setErrorMsg('Solver Web Worker exceeded maximum watchdog timeout and was terminated cleanly.');
          setRunning(false);
        }
      }, timeoutMs + 5000);

      worker.onmessage = async (event: MessageEvent<WorkerOutboundMessage>) => {
        const msg = event.data;
        if (msg.type === 'PROGRESS') {
          if (isMountedRef.current) {
            setProgress(msg.payload);
          }
        } else if (msg.type === 'COMPLETE') {
          clearWatchdog();
          worker.terminate();
          workerRef.current = null;
          if (!isMountedRef.current) return;
          setLastResult(msg.payload);
          await persistWorkerResult(msg.payload);
          if (isMountedRef.current) {
            setRunning(false);
          }
        } else if (msg.type === 'ERROR') {
          clearWatchdog();
          worker.terminate();
          workerRef.current = null;
          if (!isMountedRef.current) return;
          setErrorMsg(msg.message);
          setRunning(false);
        }
      };

      worker.onerror = (err) => {
        clearWatchdog();
        worker.terminate();
        workerRef.current = null;
        if (!isMountedRef.current) return;
        setErrorMsg(err.message || 'Web Worker execution error.');
        setRunning(false);
      };

      worker.postMessage({
        type: 'START',
        payload: {
          ...solverPayload,
          options: {
            maxNodes,
            timeoutMs,
            enableMrv,
            enableLcv,
            enableForwardChecking,
            allowPartialFallback,
          },
        },
      });
    } catch (err) {
      clearWatchdog();
      if (!isMountedRef.current) return;
      setErrorMsg(err instanceof ApiClientError ? err.message : 'Unable to initialize solver.');
      setRunning(false);
    }
  };

  const handleCancel = () => {
    if (workerRef.current) {
      workerRef.current.postMessage({ type: 'CANCEL' });
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Configuration Panel */}
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
          <div>
            <h2 className="text-base font-semibold text-slate-900">CSP Solver Configuration</h2>
            <p className="text-xs text-slate-500 mt-1">
              Executes backtracking search inside an isolated Web Worker thread, then verifies all hard constraints server-side.
            </p>
          </div>

          <div className="space-y-3 pt-2 border-t border-slate-100">
            <label className="flex items-start gap-2.5 text-sm text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={enableMrv}
                onChange={(e) => setEnableMrv(e.target.checked)}
                disabled={running}
                className="mt-1 rounded border-slate-300 text-indigo-700"
              />
              <div>
                <div className="font-medium text-slate-900">Minimum Remaining Values (MRV)</div>
                <div className="text-xs text-slate-500">Selects the most constrained class variable first with degree tie-breaking.</div>
              </div>
            </label>

            <label className="flex items-start gap-2.5 text-sm text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={enableLcv}
                onChange={(e) => setEnableLcv(e.target.checked)}
                disabled={running}
                className="mt-1 rounded border-slate-300 text-indigo-700"
              />
              <div>
                <div className="font-medium text-slate-900">Least Constraining Value (LCV)</div>
                <div className="text-xs text-slate-500">Orders slot-room candidates to preserve neighbor options and room fit.</div>
              </div>
            </label>

            <label className="flex items-start gap-2.5 text-sm text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={enableForwardChecking}
                onChange={(e) => setEnableForwardChecking(e.target.checked)}
                disabled={running}
                className="mt-1 rounded border-slate-300 text-indigo-700"
              />
              <div>
                <div className="font-medium text-slate-900">Forward Checking &amp; AC-3 Propagation</div>
                <div className="text-xs text-slate-500">Prunes dead-end branches immediately via singleton arc propagation.</div>
              </div>
            </label>

            <label className="flex items-start gap-2.5 text-sm text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={allowPartialFallback}
                onChange={(e) => setAllowPartialFallback(e.target.checked)}
                disabled={running}
                className="mt-1 rounded border-slate-300 text-indigo-700"
              />
              <div>
                <div className="font-medium text-slate-900">Best Partial Schedule Fallback</div>
                <div className="text-xs text-slate-500">Returns the largest valid subset if full satisfaction is impossible.</div>
              </div>
            </label>

            <label className="flex items-start gap-2.5 text-sm text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={preserveLocked}
                onChange={(e) => setPreserveLocked(e.target.checked)}
                disabled={running}
                className="mt-1 rounded border-slate-300 text-indigo-700"
              />
              <div>
                <div className="font-medium text-slate-900">Preserve Locked Allocations</div>
                <div className="text-xs text-slate-500">Keeps manually pinned slots fixed while solving the rest.</div>
              </div>
            </label>

            <label className="flex items-start gap-2.5 text-sm text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={publishImmediately}
                onChange={(e) => setPublishImmediately(e.target.checked)}
                disabled={running}
                className="mt-1 rounded border-slate-300 text-indigo-700"
              />
              <div>
                <div className="font-medium text-slate-900">Publish Immediately</div>
                <div className="text-xs text-slate-500">Sets the generated run as the active university timetable.</div>
              </div>
            </label>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-100">
            <div>
              <label htmlFor="solver-max-nodes" className="block text-xs font-medium text-slate-700 mb-1">
                Max Search Nodes
              </label>
              <input
                id="solver-max-nodes"
                type="number"
                min={500}
                max={500000}
                step={5000}
                disabled={running}
                value={maxNodes}
                onChange={(e) => setMaxNodes(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg font-mono-tabular"
              />
            </div>
            <div>
              <label htmlFor="solver-timeout-ms" className="block text-xs font-medium text-slate-700 mb-1">
                Timeout (ms)
              </label>
              <input
                id="solver-timeout-ms"
                type="number"
                min={1000}
                max={60000}
                step={1000}
                disabled={running}
                value={timeoutMs}
                onChange={(e) => setTimeoutMs(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg font-mono-tabular"
              />
            </div>
          </div>

          <div className="pt-2 flex items-center gap-3">
            {!running ? (
              <button
                type="button"
                onClick={handleRunInWorker}
                className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-indigo-700 hover:bg-indigo-800 rounded-lg transition-colors whitespace-nowrap"
              >
                <Play className="w-4 h-4" />
                Generate Timetable
              </button>
            ) : (
              <button
                type="button"
                onClick={handleCancel}
                className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors whitespace-nowrap"
              >
                <Square className="w-4 h-4" />
                Cancel Search
              </button>
            )}
          </div>
        </div>

        {/* Live Progress & Results Panel */}
        <div className="lg:col-span-2 space-y-6">
          {errorMsg && (
            <div
              role="alert"
              className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3 text-sm text-red-800"
            >
              <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
              <div>
                <div className="font-semibold">Scheduling Error</div>
                <p className="mt-0.5">{errorMsg}</p>
              </div>
            </div>
          )}

          {/* Worker Progress Card */}
          <div className="bg-white border border-slate-200 rounded-xl p-6">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2.5">
                <Cpu className="w-5 h-5 text-indigo-700" />
                <h3 className="text-base font-semibold text-slate-900">
                  {running
                    ? 'Background Web Worker Searching...'
                    : lastResult
                      ? `Generation Complete — ${lastResult.status.toUpperCase()}`
                      : 'Solver Execution Monitor'}
                </h3>
              </div>
              {savedRun && (
                <button
                  type="button"
                  onClick={() => navigate('/timetable')}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg whitespace-nowrap"
                >
                  Open Timetable
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {!running && !lastResult && !progress && (
              <p className="text-sm text-slate-500 mt-4">
                Configure search heuristics on the left and click <strong>Generate Timetable</strong> to run the Constraint Satisfaction solver without freezing the interface.
              </p>
            )}

            {(running || progress) && !lastResult && progress && (
              <div className="mt-5 space-y-4">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
                    <div className="text-xs text-slate-500">Phase</div>
                    <div className="text-sm font-semibold text-slate-900 capitalize mt-1">
                      {progress.phase}
                    </div>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
                    <div className="text-xs text-slate-500">Assigned</div>
                    <div className="text-sm font-semibold text-slate-900 font-mono-tabular mt-1">
                      {progress.bestAssignedCount} / {progress.totalVariables || '—'}
                    </div>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
                    <div className="text-xs text-slate-500">Nodes Explored</div>
                    <div className="text-sm font-semibold text-slate-900 font-mono-tabular mt-1">
                      {progress.nodesExplored.toLocaleString()}
                    </div>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
                    <div className="text-xs text-slate-500">Elapsed</div>
                    <div className="text-sm font-semibold text-slate-900 font-mono-tabular mt-1">
                      {progress.elapsedMs} ms
                    </div>
                  </div>
                </div>
                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-indigo-600 transition-all duration-150"
                    style={{
                      width: `${
                        progress.totalVariables > 0
                          ? Math.round((progress.bestAssignedCount / progress.totalVariables) * 100)
                          : 15
                      }%`,
                    }}
                  />
                </div>
              </div>
            )}

            {lastResult && (
              <div className="mt-5 space-y-5">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                    <div className="text-xs text-slate-500">Scheduled Meetings</div>
                    <div className="text-lg font-bold text-slate-900 font-mono-tabular mt-1">
                      {lastResult.scheduledMeetings} / {lastResult.totalMeetings}
                    </div>
                  </div>
                  <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                    <div className="text-xs text-slate-500">Hard Validation</div>
                    <div className="mt-1 flex items-center gap-1.5">
                      {lastResult.validation.isValid ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <AlertTriangle className="w-4 h-4 text-red-600" />
                      )}
                      <span
                        className={`text-sm font-semibold ${
                          lastResult.validation.isValid ? 'text-emerald-700' : 'text-red-700'
                        }`}
                      >
                        {lastResult.validation.isValid
                          ? '0 Violations'
                          : `${lastResult.validation.hardViolations.length} Clashes`}
                      </span>
                    </div>
                  </div>
                  <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                    <div className="text-xs text-slate-500">Optimization Score</div>
                    <div className="text-lg font-bold text-slate-900 font-mono-tabular mt-1">
                      {lastResult.optimizationScore} / 100
                    </div>
                  </div>
                  <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                    <div className="text-xs text-slate-500">Nodes · Backtracks · Time</div>
                    <div className="text-sm font-semibold text-slate-900 font-mono-tabular mt-1.5">
                      {lastResult.nodesExplored.toLocaleString()} · {(lastResult.backtracksCount ?? 0).toLocaleString()} · {lastResult.durationMs}ms
                    </div>
                  </div>
                </div>

                {/* Soft constraint summary */}
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-4 border-t border-slate-200 text-xs">
                  <div>
                    <span className="text-slate-500">Preference Match</span>
                    <div className="font-mono-tabular font-semibold text-slate-900 mt-0.5">
                      {lastResult.validation.softMetrics.preferenceMatchRate}%
                    </div>
                  </div>
                  <div>
                    <span className="text-slate-500">Subject Day Spread</span>
                    <div className="font-mono-tabular font-semibold text-slate-900 mt-0.5">
                      {lastResult.validation.softMetrics.subjectSpreadRate}%
                    </div>
                  </div>
                  <div>
                    <span className="text-slate-500">Daily Load Balance</span>
                    <div className="font-mono-tabular font-semibold text-slate-900 mt-0.5">
                      {lastResult.validation.softMetrics.dailyBalanceScore}%
                    </div>
                  </div>
                  <div>
                    <span className="text-slate-500">Room Capacity Fit</span>
                    <div className="font-mono-tabular font-semibold text-slate-900 mt-0.5">
                      {lastResult.validation.softMetrics.roomFitScore ?? 100}%
                    </div>
                  </div>
                  <div>
                    <span className="text-slate-500">Batch Idle Gaps</span>
                    <div className="font-mono-tabular font-semibold text-slate-900 mt-0.5">
                      {lastResult.validation.softMetrics.batchGapCount}
                    </div>
                  </div>
                </div>

                {/* Unscheduled Meetings Diagnostics */}
                {lastResult.unscheduledMeetings.length > 0 && (
                  <div className="pt-4 border-t border-slate-200">
                    <h4 className="text-sm font-semibold text-amber-800 mb-2">
                      Unscheduled Meetings ({lastResult.unscheduledMeetings.length})
                    </h4>
                    <div className="divide-y divide-slate-100 border border-amber-200 rounded-lg bg-amber-50/40">
                      {lastResult.unscheduledMeetings.map((u) => (
                        <div key={u.variableId} className="p-3 text-xs">
                          <div className="font-semibold text-slate-900">
                            {u.subjectCode} — {u.subjectName} (Session #{u.sessionIndex}, {u.duration}h)
                          </div>
                          <div className="text-amber-900 mt-0.5">{u.reason}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
