import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  CalendarDays,
  CheckCircle2,
  Download,
  FileSpreadsheet,
  FileText,
  Search,
  Trash2,
} from 'lucide-react';
import { TimetableGrid } from '../components/Timetable/TimetableGrid.tsx';
import { EmptyState } from '../components/UI/EmptyState.tsx';
import { TableSkeleton } from '../components/UI/LoadingSkeleton.tsx';
import { Modal } from '../components/UI/Modal.tsx';
import { useToast } from '../context/ToastContext.tsx';
import { apiClient, ApiClientError } from '../services/apiClient.ts';
import {
  exportTimetableCsv,
  exportTimetableIcs,
  exportTimetablePdf,
} from '../services/exportService.ts';
import type {
  BatchDto,
  FacultyDto,
  RoomDto,
  SubjectDto,
  TimetableAllocationDto,
  TimetablePayloadDto,
} from '../types/api.ts';
import type { DayOfWeek } from '../../shared/csp/types.ts';
import { DAYS_OF_WEEK } from '../../shared/csp/types.ts';

type ViewMode = 'batch' | 'faculty' | 'room' | 'all';

export function TimetablePage() {
  const { pushToast } = useToast();
  const [data, setData] = useState<TimetablePayloadDto | null>(null);
  const [batches, setBatches] = useState<BatchDto[]>([]);
  const [faculty, setFaculty] = useState<FacultyDto[]>([]);
  const [rooms, setRooms] = useState<RoomDto[]>([]);
  const [subjects, setSubjects] = useState<SubjectDto[]>([]);
  const [loading, setLoading] = useState(true);

  const [selectedRunId, setSelectedRunId] = useState<string>('');
  const [viewMode, setViewMode] = useState<ViewMode>('batch');
  const [selectedEntityId, setSelectedEntityId] = useState<string>('');
  const [subjectFilter, setSubjectFilter] = useState<string>('all');
  const [search, setSearch] = useState('');

  const [movingId, setMovingId] = useState<number | null>(null);
  const [conflictBanner, setConflictBanner] = useState<string | null>(null);

  const [selectedAlloc, setSelectedAlloc] = useState<TimetableAllocationDto | null>(null);
  const [editDay, setEditDay] = useState<DayOfWeek>('Mon');
  const [editPeriod, setEditPeriod] = useState<number>(1);
  const [editRoomId, setEditRoomId] = useState<number>(1);
  const [editLocked, setEditLocked] = useState<boolean>(false);
  const [editError, setEditError] = useState<string | null>(null);
  const [savingEdit, setSavingEdit] = useState(false);

  const loadMetadataAndTimetable = useCallback(async () => {
    setLoading(true);
    try {
      const runQuery = selectedRunId ? `?runId=${selectedRunId}` : '';
      const [tt, batchList, facList, roomList, subList] = await Promise.all([
        apiClient.get<TimetablePayloadDto>(`/timetable${runQuery}`),
        apiClient.get<BatchDto[]>('/batches'),
        apiClient.get<FacultyDto[]>('/faculty'),
        apiClient.get<RoomDto[]>('/rooms'),
        apiClient.get<SubjectDto[]>('/subjects'),
      ]);
      setData(tt);
      setBatches(batchList);
      setFaculty(facList);
      setRooms(roomList);
      setSubjects(subList);
      if (!selectedRunId && tt.run) {
        setSelectedRunId(String(tt.run.id));
      }
      if (!selectedEntityId && batchList.length > 0) {
        setSelectedEntityId(String(batchList[0].id));
      }
    } catch (err) {
      pushToast('error', 'Load Failed', err instanceof ApiClientError ? err.message : 'Unable to fetch timetable.');
    } finally {
      setLoading(false);
    }
  }, [pushToast, selectedRunId, selectedEntityId]);

  useEffect(() => {
    loadMetadataAndTimetable();
  }, [loadMetadataAndTimetable]);

  const handleViewModeChange = (mode: ViewMode) => {
    setViewMode(mode);
    if (mode === 'batch' && batches.length > 0) setSelectedEntityId(String(batches[0].id));
    else if (mode === 'faculty' && faculty.length > 0) setSelectedEntityId(String(faculty[0].id));
    else if (mode === 'room' && rooms.length > 0) setSelectedEntityId(String(rooms[0].id));
    else setSelectedEntityId('');
  };

  const refreshTimetableOnly = async () => {
    const runQuery = selectedRunId ? `?runId=${selectedRunId}` : '';
    const tt = await apiClient.get<TimetablePayloadDto>(`/timetable${runQuery}`);
    setData(tt);
  };

  const handleMoveAllocation = async (
    allocationId: number,
    targetDay: DayOfWeek,
    targetPeriod: number
  ) => {
    setConflictBanner(null);
    setMovingId(allocationId);
    try {
      await apiClient.put(`/timetable/${allocationId}`, {
        day: targetDay,
        startPeriod: targetPeriod,
      });
      await refreshTimetableOnly();
      pushToast('success', 'Schedule Updated', `Moved class to ${targetDay} Period ${targetPeriod}.`);
    } catch (err) {
      const message =
        err instanceof ApiClientError
          ? err.message
          : 'Schedule move rejected due to constraint conflict.';
      setConflictBanner(message);
      pushToast('error', 'Schedule Conflict Rejected', message);
    } finally {
      setMovingId(null);
    }
  };

  const openAllocModal = (alloc: TimetableAllocationDto) => {
    setSelectedAlloc(alloc);
    setEditDay(alloc.day);
    setEditPeriod(alloc.startPeriod);
    setEditRoomId(alloc.roomId);
    setEditLocked(alloc.isLocked);
    setEditError(null);
  };

  const handleSaveManualEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAlloc) return;
    setEditError(null);
    setSavingEdit(true);
    try {
      await apiClient.put(`/timetable/${selectedAlloc.id}`, {
        day: editDay,
        startPeriod: editPeriod,
        roomId: editRoomId,
        isLocked: editLocked,
      });
      await refreshTimetableOnly();
      setSelectedAlloc(null);
      setConflictBanner(null);
      pushToast('success', 'Allocation Saved', `${selectedAlloc.subjectCode} updated in SQLite.`);
    } catch (err) {
      const message = err instanceof ApiClientError ? err.message : 'Change violates hard constraints.';
      setEditError(message);
    } finally {
      setSavingEdit(false);
    }
  };

  const handleDeleteAllocation = async () => {
    if (!selectedAlloc) return;
    setSavingEdit(true);
    try {
      await apiClient.delete(`/timetable/${selectedAlloc.id}`);
      await refreshTimetableOnly();
      setSelectedAlloc(null);
      pushToast('success', 'Allocation Removed', 'Class removed from schedule.');
    } catch (err) {
      setEditError(err instanceof ApiClientError ? err.message : 'Failed to remove allocation.');
    } finally {
      setSavingEdit(false);
    }
  };

  const handlePublish = async () => {
    if (!data?.run) return;
    try {
      await apiClient.post('/timetable/publish', { runId: data.run.id });
      await refreshTimetableOnly();
      pushToast('success', 'Timetable Published', `Run #${data.run.id} is now the active published schedule.`);
    } catch (err) {
      pushToast('error', 'Publish Failed', err instanceof ApiClientError ? err.message : 'Error publishing run.');
    }
  };

  const visibleAllocations = useMemo(() => {
    return (data?.allocations ?? []).filter((a) => {
      if (viewMode === 'batch' && selectedEntityId && String(a.batchId) !== selectedEntityId) return false;
      if (viewMode === 'faculty' && selectedEntityId && String(a.facultyId) !== selectedEntityId) return false;
      if (viewMode === 'room' && selectedEntityId && String(a.roomId) !== selectedEntityId) return false;
      if (subjectFilter !== 'all' && String(a.subjectId) !== subjectFilter) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        return (
          a.subjectCode.toLowerCase().includes(q) ||
          a.subjectName.toLowerCase().includes(q) ||
          a.facultyName.toLowerCase().includes(q) ||
          a.roomCode.toLowerCase().includes(q) ||
          a.batchCode.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [data?.allocations, viewMode, selectedEntityId, subjectFilter, search]);

  const currentScopeLabel = (() => {
    if (viewMode === 'batch') {
      const b = batches.find((x) => String(x.id) === selectedEntityId);
      return b ? `${b.batchCode} (${b.name})` : 'Batch Schedule';
    }
    if (viewMode === 'faculty') {
      const f = faculty.find((x) => String(x.id) === selectedEntityId);
      return f ? `${f.fullName} (${f.facultyCode})` : 'Faculty Schedule';
    }
    if (viewMode === 'room') {
      const r = rooms.find((x) => String(x.id) === selectedEntityId);
      return r ? `${r.roomCode} (${r.name})` : 'Room Schedule';
    }
    return 'All Scheduled Classes';
  })();

  if (loading && !data) return <TableSkeleton rows={8} />;

  return (
    <div className="space-y-5">
      {/* Toolbar: View Mode + Entity Picker + Exports */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
              {(
                [
                  ['batch', 'Batch-wise'],
                  ['faculty', 'Faculty-wise'],
                  ['room', 'Room-wise'],
                  ['all', 'All Classes'],
                ] as const
              ).map(([mode, label]) => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => handleViewModeChange(mode)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    viewMode === mode
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            {viewMode === 'batch' && (
              <select
                value={selectedEntityId}
                onChange={(e) => setSelectedEntityId(e.target.value)}
                aria-label="Select batch"
                className="px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
              >
                {batches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.batchCode} — {b.name}
                  </option>
                ))}
              </select>
            )}

            {viewMode === 'faculty' && (
              <select
                value={selectedEntityId}
                onChange={(e) => setSelectedEntityId(e.target.value)}
                aria-label="Select faculty"
                className="px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
              >
                {faculty.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.facultyCode} — {f.fullName}
                  </option>
                ))}
              </select>
            )}

            {viewMode === 'room' && (
              <select
                value={selectedEntityId}
                onChange={(e) => setSelectedEntityId(e.target.value)}
                aria-label="Select room"
                className="px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
              >
                {rooms.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.roomCode} — {r.name}
                  </option>
                ))}
              </select>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              disabled={visibleAllocations.length === 0}
              onClick={() => {
                if (exportTimetableCsv(visibleAllocations, data?.timeSlots ?? [], currentScopeLabel)) {
                  pushToast('success', 'CSV Exported', `Exported ${visibleAllocations.length} allocations.`);
                }
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg disabled:opacity-40 whitespace-nowrap"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              Export CSV
            </button>
            <button
              type="button"
              disabled={visibleAllocations.length === 0}
              onClick={() => {
                if (exportTimetablePdf(visibleAllocations, data?.timeSlots ?? [], currentScopeLabel)) {
                  pushToast('success', 'PDF Exported', `Generated weekly matrix PDF for ${currentScopeLabel}.`);
                }
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg disabled:opacity-40 whitespace-nowrap"
            >
              <FileText className="w-3.5 h-3.5" />
              Export PDF
            </button>
            <button
              type="button"
              disabled={visibleAllocations.length === 0}
              onClick={() => {
                if (exportTimetableIcs(visibleAllocations, data?.timeSlots ?? [], currentScopeLabel)) {
                  pushToast('success', 'ICS Exported', `Exported calendar events for ${currentScopeLabel}.`);
                }
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg disabled:opacity-40 whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              Export ICS
            </button>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100">
          <div className="flex flex-wrap items-center gap-3 flex-1">
            <div className="relative min-w-[200px] max-w-xs flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                aria-label="Filter visible classes"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Filter visible classes..."
                className="w-full pl-9 pr-3 py-1.5 text-sm bg-white border border-slate-300 rounded-lg"
              />
            </div>

            <select
              value={subjectFilter}
              onChange={(e) => setSubjectFilter(e.target.value)}
              aria-label="Filter by subject"
              className="px-3 py-1.5 text-sm bg-white border border-slate-300 rounded-lg"
            >
              <option value="all">All Subjects</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.subjectCode} — {s.name}
                </option>
              ))}
            </select>

            {data && data.runsHistory.length > 0 && (
              <select
                value={selectedRunId}
                onChange={(e) => setSelectedRunId(e.target.value)}
                aria-label="Select scheduling run"
                className="px-3 py-1.5 text-sm bg-white border border-slate-300 rounded-lg font-mono-tabular"
              >
                {data.runsHistory.map((r) => (
                  <option key={r.id} value={r.id}>
                    Run #{r.id} ({r.status}{r.isPublished ? ' · Published' : ''})
                  </option>
                ))}
              </select>
            )}
          </div>

          {data?.run && (
            <div className="flex items-center gap-3 text-xs">
              <span className="flex items-center gap-1.5 font-medium text-slate-700">
                {data.validation.isValid ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-red-600" />
                )}
                {data.validation.isValid
                  ? '0 Hard Conflicts'
                  : `${data.validation.hardViolations.length} Conflict(s)`}
              </span>
              {!data.run.isPublished && (
                <button
                  type="button"
                  onClick={handlePublish}
                  className="px-3 py-1.5 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg whitespace-nowrap"
                >
                  Publish Run
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {conflictBanner && (
        <div
          role="alert"
          className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start justify-between gap-3 text-sm text-red-900"
        >
          <div className="flex items-start gap-2.5">
            <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold">Manual Change Rejected — Previous Schedule Preserved</div>
              <p className="text-xs text-red-800 mt-0.5">{conflictBanner}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setConflictBanner(null)}
            className="text-xs font-medium text-red-700 hover:underline shrink-0"
          >
            Dismiss
          </button>
        </div>
      )}

      {!data || data.allAllocationsCount === 0 ? (
        <EmptyState
          icon={CalendarDays}
          title="No timetable allocations generated yet"
          description="Run the CSP Timetable Generator to produce a conflict-free weekly academic schedule."
        />
      ) : (
        <TimetableGrid
          allocations={visibleAllocations}
          timeSlots={data.timeSlots}
          onMoveAllocation={handleMoveAllocation}
          onSelectAllocation={openAllocModal}
          movingId={movingId}
        />
      )}

      {/* Manual Edit & Validation Modal */}
      <Modal
        open={selectedAlloc !== null}
        title={
          selectedAlloc
            ? `${selectedAlloc.subjectCode} — ${selectedAlloc.subjectName}`
            : 'Edit Allocation'
        }
        subtitle={
          selectedAlloc
            ? `${selectedAlloc.batchCode} · ${selectedAlloc.facultyName} · ${selectedAlloc.durationPeriods}h session`
            : undefined
        }
        onClose={() => setSelectedAlloc(null)}
        maxWidthClass="max-w-lg"
      >
        {selectedAlloc && (
          <form onSubmit={handleSaveManualEdit} className="space-y-4">
            {editError && (
              <div
                role="alert"
                className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-800"
              >
                {editError}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="edit-day-select" className="block text-xs font-medium text-slate-700 mb-1">Day of Week</label>
                <select
                  id="edit-day-select"
                  value={editDay}
                  onChange={(e) => setEditDay(e.target.value as DayOfWeek)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
                >
                  {DAYS_OF_WEEK.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="edit-period-select" className="block text-xs font-medium text-slate-700 mb-1">Start Period</label>
                <select
                  id="edit-period-select"
                  value={editPeriod}
                  onChange={(e) => setEditPeriod(Number(e.target.value))}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white font-mono-tabular"
                >
                  {(data?.timeSlots ?? []).map((slot) => (
                    <option key={slot.periodNumber} value={slot.periodNumber}>
                      P{slot.periodNumber} · {slot.label} ({slot.startTime})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label htmlFor="edit-room-select" className="block text-xs font-medium text-slate-700 mb-1">Assigned Room</label>
              <select
                id="edit-room-select"
                value={editRoomId}
                onChange={(e) => setEditRoomId(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
              >
                {rooms.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.roomCode} — {r.name} ({r.roomType}, {r.capacity} seats)
                  </option>
                ))}
              </select>
            </div>

            <label className="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={editLocked}
                onChange={(e) => setEditLocked(e.target.checked)}
                className="rounded border-slate-300 text-indigo-700"
              />
              Lock this class slot (preserved when regenerating with &quot;Preserve Locked&quot;)
            </label>

            <div className="pt-3 flex items-center justify-between gap-3 border-t border-slate-200">
              <button
                type="button"
                onClick={handleDeleteAllocation}
                disabled={savingEdit}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-red-700 hover:bg-red-50 rounded-lg border border-red-200"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Remove Slot
              </button>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedAlloc(null)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingEdit}
                  className="px-4 py-2 text-sm font-medium text-white bg-indigo-700 hover:bg-indigo-800 rounded-lg disabled:opacity-50"
                >
                  {savingEdit ? 'Validating...' : 'Validate & Save'}
                </button>
              </div>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
}
