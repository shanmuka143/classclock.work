import React, { useCallback, useEffect, useState } from 'react';
import {
  CheckCircle2,
  Database,
  Download,
  Lock,
  Plus,
  RefreshCw,
  Save,
  Shield,
} from 'lucide-react';
import { TableSkeleton } from '../components/UI/LoadingSkeleton.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { useToast } from '../context/ToastContext.tsx';
import { apiClient, ApiClientError } from '../services/apiClient.ts';
import type {
  AcademicSettingsDto,
  AuditLogsResponseDto,
  BackupResultDto,
  IntegrityReportDto,
} from '../types/api.ts';
import type { CspTimeSlot } from '../../shared/csp/types.ts';

export function SettingsPage() {
  const { user } = useAuth();
  const { pushToast } = useToast();
  const isAdmin = user?.role === 'admin';

  const [settings, setSettings] = useState<AcademicSettingsDto | null>(null);
  const [loading, setLoading] = useState(true);

  const [institutionName, setInstitutionName] = useState('');
  const [academicYear, setAcademicYear] = useState('');
  const [semesterLabel, setSemesterLabel] = useState('');
  const [slots, setSlots] = useState<CspTimeSlot[]>([]);

  const [deptCode, setDeptCode] = useState('');
  const [deptName, setDeptName] = useState('');
  const [deptHead, setDeptHead] = useState('');

  const [savingTerm, setSavingTerm] = useState(false);
  const [savingSlots, setSavingSlots] = useState(false);
  const [addingDept, setAddingDept] = useState(false);

  // Admin-only system integrity, backup & audit logs
  const [integrityReport, setIntegrityReport] = useState<IntegrityReportDto | null>(null);
  const [checkingIntegrity, setCheckingIntegrity] = useState(false);
  const [backupResult, setBackupResult] = useState<BackupResultDto | null>(null);
  const [creatingBackup, setCreatingBackup] = useState(false);

  const [auditLogs, setAuditLogs] = useState<AuditLogsResponseDto | null>(null);
  const [loadingAudit, setLoadingAudit] = useState(false);
  const [auditActionFilter, setAuditActionFilter] = useState('');
  const [auditStatusFilter, setAuditStatusFilter] = useState('all');
  const [auditPage, setAuditPage] = useState(1);

  const loadSettings = useCallback(async () => {
    setLoading(true);
    try {
      const data = await apiClient.get<AcademicSettingsDto>('/settings');
      setSettings(data);
      setInstitutionName(data.academicTerm.institutionName);
      setAcademicYear(data.academicTerm.academicYear);
      setSemesterLabel(data.academicTerm.semesterLabel);
      setSlots(data.timeSlots);
    } catch (err) {
      pushToast('error', 'Load Failed', err instanceof ApiClientError ? err.message : 'Unable to load settings.');
    } finally {
      setLoading(false);
    }
  }, [pushToast]);

  const loadAuditLogs = useCallback(async () => {
    if (!isAdmin) return;
    setLoadingAudit(true);
    try {
      const params = new URLSearchParams({
        page: String(auditPage),
        limit: '10',
      });
      if (auditActionFilter.trim()) {
        params.set('action', auditActionFilter.trim());
      }
      if (auditStatusFilter !== 'all') {
        params.set('status', auditStatusFilter);
      }
      const data = await apiClient.get<AuditLogsResponseDto>(`/audit-logs?${params.toString()}`);
      setAuditLogs(data);
    } catch (err) {
      pushToast('error', 'Audit Load Failed', err instanceof ApiClientError ? err.message : 'Unable to fetch audit logs.');
    } finally {
      setLoadingAudit(false);
    }
  }, [isAdmin, auditPage, auditActionFilter, auditStatusFilter, pushToast]);

  useEffect(() => {
    loadSettings();
  }, [loadSettings]);

  useEffect(() => {
    loadAuditLogs();
  }, [loadAuditLogs]);

  const handleSaveTerm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    setSavingTerm(true);
    try {
      await apiClient.put('/settings', { institutionName, academicYear, semesterLabel });
      pushToast('success', 'Settings Saved', 'Academic term preferences updated.');
      await loadSettings();
      await loadAuditLogs();
    } catch (err) {
      pushToast('error', 'Save Failed', err instanceof ApiClientError ? err.message : 'Unable to update settings.');
    } finally {
      setSavingTerm(false);
    }
  };

  const handleSaveSlots = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    setSavingSlots(true);
    try {
      await apiClient.put('/settings/time-slots', { slots });
      pushToast('success', 'Periods Saved', 'Time slot configuration updated.');
      await loadSettings();
      await loadAuditLogs();
    } catch (err) {
      pushToast('error', 'Save Failed', err instanceof ApiClientError ? err.message : 'Unable to update periods.');
    } finally {
      setSavingSlots(false);
    }
  };

  const handleAddDepartment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin || !deptCode.trim() || !deptName.trim()) return;
    setAddingDept(true);
    try {
      await apiClient.post('/departments', {
        code: deptCode.trim(),
        name: deptName.trim(),
        headName: deptHead.trim() || null,
      });
      setDeptCode('');
      setDeptName('');
      setDeptHead('');
      pushToast('success', 'Department Added', `${deptCode.toUpperCase()} created.`);
      await loadSettings();
      await loadAuditLogs();
    } catch (err) {
      pushToast('error', 'Error', err instanceof ApiClientError ? err.message : 'Unable to add department.');
    } finally {
      setAddingDept(false);
    }
  };

  const handleCheckIntegrity = async () => {
    if (!isAdmin) return;
    setCheckingIntegrity(true);
    try {
      const report = await apiClient.get<IntegrityReportDto>('/system/integrity');
      setIntegrityReport(report);
      pushToast(
        report.integrityOk ? 'success' : 'error',
        'SQLite Integrity Check',
        report.integrityOk ? 'Database integrity & foreign keys verified OK.' : 'Integrity anomalies detected.'
      );
      await loadAuditLogs();
    } catch (err) {
      pushToast('error', 'Integrity Check Failed', err instanceof ApiClientError ? err.message : 'Unable to run check.');
    } finally {
      setCheckingIntegrity(false);
    }
  };

  const handleCreateBackup = async () => {
    if (!isAdmin) return;
    setCreatingBackup(true);
    try {
      const result = await apiClient.post<BackupResultDto>('/system/backup');
      setBackupResult(result);
      pushToast('success', 'Database Backup Verified', `${result.fileName} (${Math.round(result.sizeBytes / 1024)} KB)`);
      await loadAuditLogs();
    } catch (err) {
      pushToast('error', 'Backup Failed', err instanceof ApiClientError ? err.message : 'Unable to create backup.');
    } finally {
      setCreatingBackup(false);
    }
  };

  if (loading || !settings) return <TableSkeleton rows={6} />;

  const totalAuditPages = auditLogs ? Math.max(1, Math.ceil(auditLogs.total / auditLogs.limit)) : 1;

  return (
    <div className="space-y-6">
      {!isAdmin && (
        <div
          role="status"
          className="bg-slate-100 border border-slate-300 rounded-xl p-4 flex items-start gap-3 text-sm text-slate-800"
        >
          <Lock className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold">Administrator-Only Configuration:</span> Viewing academic term and period configuration in read-only mode. Modifying institutional settings, adding departments, viewing security audit logs, and running database backups require the <code className="font-mono-tabular">admin</code> role.
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Institution & Term */}
        <form onSubmit={handleSaveTerm} className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <h2 className="text-base font-semibold text-slate-900">Academic Term Configuration</h2>
          <div>
            <label htmlFor="settings-institution-name" className="block text-xs font-medium text-slate-700 mb-1">
              Institution Name
            </label>
            <input
              id="settings-institution-name"
              type="text"
              required
              disabled={!isAdmin}
              value={institutionName}
              onChange={(e) => setInstitutionName(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg disabled:bg-slate-50"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label htmlFor="settings-academic-year" className="block text-xs font-medium text-slate-700 mb-1">
                Academic Year
              </label>
              <input
                id="settings-academic-year"
                type="text"
                required
                disabled={!isAdmin}
                value={academicYear}
                onChange={(e) => setAcademicYear(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg font-mono-tabular disabled:bg-slate-50"
              />
            </div>
            <div>
              <label htmlFor="settings-semester-label" className="block text-xs font-medium text-slate-700 mb-1">
                Semester Label
              </label>
              <input
                id="settings-semester-label"
                type="text"
                required
                disabled={!isAdmin}
                value={semesterLabel}
                onChange={(e) => setSemesterLabel(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg disabled:bg-slate-50"
              />
            </div>
          </div>
          {isAdmin && (
            <div className="pt-2">
              <button
                type="submit"
                disabled={savingTerm}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-indigo-700 hover:bg-indigo-800 rounded-lg disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                {savingTerm ? 'Saving...' : 'Save Term Settings'}
              </button>
            </div>
          )}
        </form>

        {/* Departments */}
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <h2 className="text-base font-semibold text-slate-900">
            Academic Departments ({settings.departments.length})
          </h2>
          <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg max-h-48 overflow-y-auto">
            {settings.departments.map((d) => (
              <div key={d.id} className="px-3.5 py-2.5 flex items-center justify-between text-sm">
                <div>
                  <span className="font-mono-tabular font-semibold text-slate-900">{d.code}</span>
                  <span className="text-slate-600 ml-2">{d.name}</span>
                </div>
                <span className="text-xs text-slate-500">{d.headName ?? '—'}</span>
              </div>
            ))}
          </div>

          {isAdmin && (
            <form onSubmit={handleAddDepartment} className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2">
              <input
                type="text"
                required
                aria-label="Department Code"
                placeholder="Code (e.g. BIO)"
                value={deptCode}
                onChange={(e) => setDeptCode(e.target.value)}
                className="px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
              <input
                type="text"
                required
                aria-label="Department Name"
                placeholder="Department Name"
                value={deptName}
                onChange={(e) => setDeptName(e.target.value)}
                className="px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
              <button
                type="submit"
                disabled={addingDept}
                className="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50 whitespace-nowrap"
              >
                <Plus className="w-4 h-4" />
                Add Dept
              </button>
            </form>
          )}
        </div>
      </div>

      {/* Period & Protected Lunch Break Configuration */}
      <form onSubmit={handleSaveSlots} className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-base font-semibold text-slate-900">Academic Periods &amp; Lunch Protection</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Periods marked as Lunch Break are strictly protected against class allocation by both the CSP engine and independent validator.
            </p>
          </div>
          {isAdmin && (
            <button
              type="submit"
              disabled={savingSlots}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-indigo-700 hover:bg-indigo-800 rounded-lg disabled:opacity-50 shrink-0"
            >
              <Save className="w-4 h-4" />
              {savingSlots ? 'Saving...' : 'Save Time Slots'}
            </button>
          )}
        </div>

        <div className="overflow-x-auto border border-slate-200 rounded-lg">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                <th className="px-3 py-2.5">Period</th>
                <th className="px-3 py-2.5">Label</th>
                <th className="px-3 py-2.5">Start Time</th>
                <th className="px-3 py-2.5">End Time</th>
                <th className="px-3 py-2.5">Protected Lunch Break</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {slots.map((slot, idx) => (
                <tr key={slot.periodNumber}>
                  <td className="px-3 py-2 font-mono-tabular font-semibold text-slate-900">
                    P{slot.periodNumber}
                  </td>
                  <td className="px-3 py-2">
                    <input
                      type="text"
                      aria-label={`Period ${slot.periodNumber} label`}
                      disabled={!isAdmin}
                      value={slot.label}
                      onChange={(e) => {
                        const next = [...slots];
                        next[idx] = { ...slot, label: e.target.value };
                        setSlots(next);
                      }}
                      className="px-2.5 py-1.5 text-sm border border-slate-300 rounded-md w-full max-w-[180px] disabled:bg-slate-50"
                    />
                  </td>
                  <td className="px-3 py-2">
                    <input
                      type="text"
                      aria-label={`Period ${slot.periodNumber} start time`}
                      disabled={!isAdmin}
                      value={slot.startTime}
                      onChange={(e) => {
                        const next = [...slots];
                        next[idx] = { ...slot, startTime: e.target.value };
                        setSlots(next);
                      }}
                      className="px-2.5 py-1.5 text-sm border border-slate-300 rounded-md font-mono-tabular w-24 disabled:bg-slate-50"
                    />
                  </td>
                  <td className="px-3 py-2">
                    <input
                      type="text"
                      aria-label={`Period ${slot.periodNumber} end time`}
                      disabled={!isAdmin}
                      value={slot.endTime}
                      onChange={(e) => {
                        const next = [...slots];
                        next[idx] = { ...slot, endTime: e.target.value };
                        setSlots(next);
                      }}
                      className="px-2.5 py-1.5 text-sm border border-slate-300 rounded-md font-mono-tabular w-24 disabled:bg-slate-50"
                    />
                  </td>
                  <td className="px-3 py-2">
                    <label className="inline-flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        disabled={!isAdmin}
                        checked={slot.isLunchBreak}
                        onChange={(e) => {
                          const next = [...slots];
                          next[idx] = { ...slot, isLunchBreak: e.target.checked };
                          setSlots(next);
                        }}
                        className="rounded border-slate-300 text-amber-600"
                      />
                      {slot.isLunchBreak ? 'Protected Break' : 'Teachable Period'}
                    </label>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </form>

      {isAdmin && (
        <div className="space-y-6">
          {/* SQLite Integrity & Backup */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <Database className="w-5 h-5 text-indigo-700 shrink-0 mt-0.5" />
                <div>
                  <h2 className="text-base font-semibold text-slate-900">SQLite Reliability &amp; Verified Backup</h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Execute PRAGMA integrity &amp; foreign-key checks or generate an online backup verified with read-only integrity validation.
                  </p>
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={handleCheckIntegrity}
                  disabled={checkingIntegrity}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${checkingIntegrity ? 'animate-spin' : ''}`} />
                  {checkingIntegrity ? 'Checking...' : 'Run Integrity Check'}
                </button>
                <button
                  type="button"
                  onClick={handleCreateBackup}
                  disabled={creatingBackup}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50"
                >
                  <Download className="w-3.5 h-3.5" />
                  {creatingBackup ? 'Backing Up...' : 'Create Verified Backup'}
                </button>
              </div>
            </div>

            {integrityReport && (
              <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 space-y-3 text-xs">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2 font-semibold text-slate-900">
                    <CheckCircle2
                      className={`w-4 h-4 ${integrityReport.integrityOk ? 'text-emerald-600' : 'text-red-600'}`}
                    />
                    <span>
                      Integrity: {integrityReport.integrityOk ? 'OK' : 'FAILED'} · Journal Mode:{' '}
                      <span className="font-mono-tabular uppercase">{integrityReport.journalMode}</span> · FK Violations:{' '}
                      <span className="font-mono-tabular">{integrityReport.foreignKeyViolationsCount}</span>
                    </span>
                  </div>
                  <span className="text-slate-500 font-mono-tabular">{integrityReport.checkedAt}</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2">
                  {Object.entries(integrityReport.tableCounts).map(([tbl, count]) => (
                    <div key={tbl} className="bg-white border border-slate-200 rounded px-2.5 py-1.5">
                      <div className="text-[11px] text-slate-500 truncate">{tbl}</div>
                      <div className="font-mono-tabular font-semibold text-slate-900">{count}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {backupResult && (
              <div className="p-3.5 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <span className="font-semibold">Backup Created &amp; Verified:</span>{' '}
                  <code className="font-mono-tabular">{backupResult.fileName}</code>
                </div>
                <div className="font-mono-tabular">
                  {Math.round(backupResult.sizeBytes / 1024)} KB · Integrity{' '}
                  {backupResult.integrityOk ? 'OK' : 'Failed'}
                </div>
              </div>
            )}
          </div>

          {/* Security Audit Logs */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <Shield className="w-5 h-5 text-indigo-700 shrink-0 mt-0.5" />
                <div>
                  <h2 className="text-base font-semibold text-slate-900">Security &amp; Mutation Audit Logs</h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Immutable database trail of authentication events, authorization denials, resource edits, and scheduling runs.
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <input
                  type="text"
                  value={auditActionFilter}
                  onChange={(e) => {
                    setAuditPage(1);
                    setAuditActionFilter(e.target.value);
                  }}
                  aria-label="Filter audit action"
                  placeholder="Filter action (e.g. AUTH)..."
                  className="px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                />
                <select
                  value={auditStatusFilter}
                  onChange={(e) => {
                    setAuditPage(1);
                    setAuditStatusFilter(e.target.value);
                  }}
                  aria-label="Filter audit status"
                  className="px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                >
                  <option value="all">All Statuses</option>
                  <option value="success">Success</option>
                  <option value="failure">Failure</option>
                  <option value="denied">Denied</option>
                </select>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 font-semibold text-slate-600">
                    <th className="px-4 py-2.5">Timestamp</th>
                    <th className="px-4 py-2.5">Actor</th>
                    <th className="px-4 py-2.5">Action</th>
                    <th className="px-4 py-2.5">Entity</th>
                    <th className="px-4 py-2.5">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {loadingAudit ? (
                    <tr>
                      <td colSpan={5} className="px-4 py-6 text-center text-slate-500">
                        Loading audit logs...
                      </td>
                    </tr>
                  ) : !auditLogs || auditLogs.items.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-4 py-6 text-center text-slate-500">
                        No matching audit events recorded.
                      </td>
                    </tr>
                  ) : (
                    auditLogs.items.map((log) => (
                      <tr key={log.id} className="hover:bg-slate-50/70">
                        <td className="px-4 py-2.5 font-mono-tabular text-slate-500 whitespace-nowrap">
                          {log.createdAt}
                        </td>
                        <td className="px-4 py-2.5 font-medium text-slate-800 whitespace-nowrap">
                          {log.actorUsername ?? 'anonymous'}
                        </td>
                        <td className="px-4 py-2.5 font-mono-tabular font-semibold text-slate-900">
                          {log.action}
                        </td>
                        <td className="px-4 py-2.5 text-slate-600">
                          {log.entityType}
                          {log.entityId ? ` #${log.entityId}` : ''}
                        </td>
                        <td className="px-4 py-2.5 font-medium">
                          <span
                            className={
                              log.status === 'success'
                                ? 'text-emerald-700'
                                : log.status === 'denied'
                                  ? 'text-amber-700'
                                  : 'text-red-700'
                            }
                          >
                            {log.status}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {auditLogs && (
              <div className="px-6 py-3 border-t border-slate-200 flex items-center justify-between text-xs text-slate-600">
                <span className="font-mono-tabular">
                  Page {auditLogs.page} of {totalAuditPages} ({auditLogs.total} total events)
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    disabled={auditPage <= 1}
                    onClick={() => setAuditPage((p) => Math.max(1, p - 1))}
                    className="px-3 py-1 border border-slate-300 rounded-md hover:bg-slate-50 disabled:opacity-40"
                  >
                    Previous
                  </button>
                  <button
                    type="button"
                    disabled={auditPage >= totalAuditPages}
                    onClick={() => setAuditPage((p) => p + 1)}
                    className="px-3 py-1 border border-slate-300 rounded-md hover:bg-slate-50 disabled:opacity-40"
                  >
                    Next
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
