import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { CspTimeSlot, DayOfWeek } from '../../shared/csp/types.ts';
import { DAYS_OF_WEEK } from '../../shared/csp/types.ts';
import type { TimetableAllocationDto } from '../types/api.ts';

function triggerDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function escapeCsvCell(value: string | number): string {
  const str = String(value);
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

export function buildCsvContent(
  allocations: TimetableAllocationDto[],
  timeSlots: CspTimeSlot[]
): string {
  const slotMap = new Map<number, CspTimeSlot>(timeSlots.map((s) => [s.periodNumber, s]));
  const headers = [
    'Day',
    'Start Period',
    'Duration (Periods)',
    'Time Window',
    'Subject Code',
    'Subject Name',
    'Batch Code',
    'Batch Name',
    'Faculty',
    'Room Code',
    'Room Name',
    'Room Type',
  ];

  const rows = [...allocations]
    .sort((a, b) => {
      const da = DAYS_OF_WEEK.indexOf(a.day);
      const db = DAYS_OF_WEEK.indexOf(b.day);
      if (da !== db) return da - db;
      return a.startPeriod - b.startPeriod;
    })
    .map((a) => {
      const startSlot = slotMap.get(a.startPeriod);
      const endSlot = slotMap.get(a.startPeriod + a.durationPeriods - 1);
      const windowLabel =
        startSlot && endSlot ? `${startSlot.startTime} - ${endSlot.endTime}` : `P${a.startPeriod}`;
      return [
        a.day,
        a.startPeriod,
        a.durationPeriods,
        windowLabel,
        a.subjectCode,
        a.subjectName,
        a.batchCode,
        a.batchName,
        a.facultyName,
        a.roomCode,
        a.roomName,
        a.requiredRoomType,
      ]
        .map(escapeCsvCell)
        .join(',');
    });

  return [headers.join(','), ...rows].join('\n');
}

export function exportTimetableCsv(
  allocations: TimetableAllocationDto[],
  timeSlots: CspTimeSlot[],
  scopeLabel: string
): boolean {
  if (allocations.length === 0) return false;
  const csv = buildCsvContent(allocations, timeSlots);
  const safeName = scopeLabel.toLowerCase().replace(/[^a-z0-9]+/g, '-');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  triggerDownload(blob, `classclockwork-timetable-${safeName}.csv`);
  return true;
}

export function exportTimetablePdf(
  allocations: TimetableAllocationDto[],
  timeSlots: CspTimeSlot[],
  scopeTitle: string,
  institutionName = 'ClassClockwork ZeroClash'
): boolean {
  if (allocations.length === 0) return false;

  const doc = new jsPDF({ orientation: 'landscape', unit: 'pt', format: 'a4' });
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.text(`${institutionName} — Weekly Timetable`, 40, 42);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(71, 85, 105);
  doc.text(`Schedule Scope: ${scopeTitle}  |  Generated: ${new Date().toLocaleDateString()}`, 40, 60);

  const teachableSlots = timeSlots.filter((s) => !s.isLunchBreak);
  const head = [['Period / Time', ...DAYS_OF_WEEK]];

  const body = teachableSlots.map((slot) => {
    const row: string[] = [`${slot.label}\n${slot.startTime}–${slot.endTime}`];
    for (const day of DAYS_OF_WEEK) {
      const matches = allocations.filter(
        (a) =>
          a.day === day &&
          slot.periodNumber >= a.startPeriod &&
          slot.periodNumber < a.startPeriod + a.durationPeriods
      );
      if (matches.length === 0) {
        row.push('—');
      } else {
        row.push(
          matches
            .map(
              (m) =>
                `${m.subjectCode} (${m.batchCode})\n${m.facultyName}\nRoom ${m.roomCode}`
            )
            .join('\n---\n')
        );
      }
    }
    return row;
  });

  autoTable(doc, {
    startY: 76,
    head,
    body,
    theme: 'grid',
    styles: {
      fontSize: 8,
      cellPadding: 6,
      valign: 'top',
      textColor: [15, 23, 42],
      lineColor: [203, 213, 225],
      lineWidth: 0.5,
    },
    headStyles: {
      fillColor: [15, 23, 42],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
    },
    columnStyles: {
      0: { cellWidth: 95, fontStyle: 'bold', fillColor: [248, 250, 252] },
    },
  });

  const safeName = scopeTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-');
  doc.save(`classclockwork-timetable-${safeName}.pdf`);
  return true;
}

const DAY_TO_ICAL_OFFSET: Record<DayOfWeek, number> = {
  Mon: 0,
  Tue: 1,
  Wed: 2,
  Thu: 3,
  Fri: 4,
};

const DAY_TO_BYDAY: Record<DayOfWeek, string> = {
  Mon: 'MO',
  Tue: 'TU',
  Wed: 'WE',
  Thu: 'TH',
  Fri: 'FR',
};

function getNextMondayDate(): Date {
  const now = new Date();
  const day = now.getDay();
  const diffToMon = (8 - day) % 7 || 7;
  const mon = new Date(now.getFullYear(), now.getMonth(), now.getDate() + diffToMon);
  return mon;
}

function formatIcalLocalDateTime(baseMonday: Date, dayOffset: number, timeHHMM: string): string {
  const d = new Date(baseMonday);
  d.setDate(d.getDate() + dayOffset);
  const [hh, mm] = timeHHMM.split(':').map(Number);
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}T${pad(hh)}${pad(mm)}00`;
}

export function buildIcsContent(
  allocations: TimetableAllocationDto[],
  timeSlots: CspTimeSlot[],
  calendarTitle: string
): string {
  const slotMap = new Map<number, CspTimeSlot>(timeSlots.map((s) => [s.periodNumber, s]));
  const monday = getNextMondayDate();
  const stamp = new Date().toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';

  const lines: string[] = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//ClassClockwork ZeroClash//Academic Scheduler//EN',
    `X-WR-CALNAME:${calendarTitle}`,
    'CALSCALE:GREGORIAN',
  ];

  for (const a of allocations) {
    const startSlot = slotMap.get(a.startPeriod);
    const endSlot = slotMap.get(a.startPeriod + a.durationPeriods - 1);
    const startTime = startSlot?.startTime ?? '09:00';
    const endTime = endSlot?.endTime ?? '10:00';
    const offset = DAY_TO_ICAL_OFFSET[a.day];

    lines.push('BEGIN:VEVENT');
    lines.push(`UID:cc-${a.id}-${a.subjectCode}-${a.day}-${a.startPeriod}@classclockwork.edu`);
    lines.push(`DTSTAMP:${stamp}`);
    lines.push(`DTSTART:${formatIcalLocalDateTime(monday, offset, startTime)}`);
    lines.push(`DTEND:${formatIcalLocalDateTime(monday, offset, endTime)}`);
    lines.push(`RRULE:FREQ=WEEKLY;COUNT=15;BYDAY=${DAY_TO_BYDAY[a.day]}`);
    lines.push(`SUMMARY:${a.subjectCode} — ${a.subjectName} (${a.batchCode})`);
    lines.push(`LOCATION:${a.roomName} (${a.roomCode})`);
    lines.push(
      `DESCRIPTION:Instructor: ${a.facultyName}\\nBatch: ${a.batchName}\\nSession ${a.sessionIndex}`
    );
    lines.push('END:VEVENT');
  }

  lines.push('END:VCALENDAR');
  return lines.join('\r\n');
}

export function exportTimetableIcs(
  allocations: TimetableAllocationDto[],
  timeSlots: CspTimeSlot[],
  scopeLabel: string
): boolean {
  if (allocations.length === 0) return false;
  const ics = buildIcsContent(allocations, timeSlots, `ClassClockwork — ${scopeLabel}`);
  const safeName = scopeLabel.toLowerCase().replace(/[^a-z0-9]+/g, '-');
  const blob = new Blob([ics], { type: 'text/calendar;charset=utf-8;' });
  triggerDownload(blob, `classclockwork-timetable-${safeName}.ics`);
  return true;
}
