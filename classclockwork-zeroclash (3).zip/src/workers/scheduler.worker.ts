import { solveTimetableCsp } from '../../shared/csp/cspSolver.ts';
import type { CspProgress, CspSolverInput, CspSolverResult } from '../../shared/csp/types.ts';

export type WorkerInboundMessage =
  | { type: 'START'; payload: CspSolverInput }
  | { type: 'CANCEL' };

export type WorkerOutboundMessage =
  | { type: 'PROGRESS'; payload: CspProgress }
  | { type: 'COMPLETE'; payload: CspSolverResult }
  | { type: 'ERROR'; message: string };

let cancelled = false;

self.onmessage = (event: MessageEvent<WorkerInboundMessage>) => {
  const msg = event.data;
  if (msg.type === 'CANCEL') {
    cancelled = true;
    return;
  }

  if (msg.type === 'START') {
    cancelled = false;
    try {
      const result = solveTimetableCsp(msg.payload, {
        onProgress(progress) {
          const out: WorkerOutboundMessage = { type: 'PROGRESS', payload: progress };
          self.postMessage(out);
        },
        shouldCancel() {
          return cancelled;
        },
      });
      const done: WorkerOutboundMessage = { type: 'COMPLETE', payload: result };
      self.postMessage(done);
    } catch (err) {
      const fail: WorkerOutboundMessage = {
        type: 'ERROR',
        message: err instanceof Error ? err.message : 'Worker CSP solver failed unexpectedly.',
      };
      self.postMessage(fail);
    }
  }
};
